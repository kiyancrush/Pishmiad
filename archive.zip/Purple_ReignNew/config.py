
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

BOT_TOKEN = "8352805321:AAGIitokuzzFVCw_TiKDPNlGx0YsKQngf2o"  # توکن ربات خود را اینجا قرار دهید
ADMIN_ID = 7363381443  # آیدی عددی ادمین اصلی را اینجا قرار دهید

# Group management settings
MAX_WARNINGS = 3

# Subscription settings
SUBSCRIPTION_CONTACT_ID = int(os.getenv("SUBSCRIPTION_CONTACT_ID", "7363381443"))  # آیدی عددی خریدار اشتراک
SUBSCRIPTION_CONTACT_USERNAME = os.getenv("SUBSCRIPTION_CONTACT_USERNAME", "admin_username")  # نام کاربری برای نمایش

# Premium subscription plans (in Toman)
SUBSCRIPTION_PLANS = {
    "monthly": {"name": "ماهانه", "days": 30, "price": 50000},
    "quarterly": {"name": "سه ماهه", "days": 90, "price": 120000},
    "semi_annual": {"name": "شش ماهه", "days": 180, "price": 200000},
    "annual": {"name": "سالانه", "days": 365, "price": 350000}
}

# Commands that require premium subscription
PREMIUM_REQUIRED_COMMANDS = [
    "warn", "unwarn", "admin", "locktime", "unlocktime", "forcejoin", "unforcejoin"
]

# Features that require premium subscription
PREMIUM_FEATURES = {
    "welcome_message": True,     # پیام خوش‌آمدگویی
    "anti_link": True,           # ضد لینک
    "anti_profanity": True,      # ضد فحش
    "warning_system": True,      # سیستم اخطار
    "force_join": True,          # جوین اجباری
    "time_lock": True,           # قفل زمانی
    "broadcast": True            # ارسال پیام همگانی
}

# Time lock settings
TIME_LOCK_DURATIONS = {
    "5m": 300,      # 5 minutes
    "10m": 600,     # 10 minutes
    "30m": 1800,    # 30 minutes
    "1h": 3600,     # 1 hour
    "2h": 7200,     # 2 hours
    "6h": 21600,    # 6 hours
    "12h": 43200,   # 12 hours
    "24h": 86400    # 24 hours
}

# Database Configuration
DATABASE_NAME = "group_manager.db"

# Bot Settings
WELCOME_MESSAGE = "به گروه خوش آمدید! 👋"

