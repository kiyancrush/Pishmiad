import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from database.database import Database
from config import ADMIN_ID
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)
db = Database("group_manager.db")

async def group_activity_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Generate activity report for a group"""
    try:
        if update.effective_chat.type == "private" and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("این دستور فقط برای ادمین اصلی قابل استفاده است.")
            return
            
        # Get group ID from args or current chat
        group_id = None
        if context.args and update.effective_user.id == ADMIN_ID:
            try:
                group_id = int(context.args[0])
            except ValueError:
                await update.message.reply_text("فرمت آیدی گروه نامعتبر است.")
                return
        else:
            group_id = update.effective_chat.id
            
        # Generate report
        today = datetime.now()
        week_ago = today - timedelta(days=7)
        
        # Get statistics from database
        conn = db.get_connection()
        cursor = conn.cursor()
        
        # Get message count for last week
        cursor.execute("""
            SELECT COUNT(*) FROM messages 
            WHERE group_id = ? AND timestamp > ?
        """, (group_id, week_ago.strftime("%Y-%m-%d %H:%M:%S")))
        message_count = cursor.fetchone()[0]
        
        # Get active users count
        cursor.execute("""
            SELECT COUNT(DISTINCT user_id) FROM messages 
            WHERE group_id = ? AND timestamp > ?
        """, (group_id, week_ago.strftime("%Y-%m-%d %H:%M:%S")))
        active_users = cursor.fetchone()[0]
        
        # Get warning count
        cursor.execute("""
            SELECT COUNT(*) FROM warnings 
            WHERE group_id = ? AND timestamp > ?
        """, (group_id, week_ago.strftime("%Y-%m-%d %H:%M:%S")))
        warning_count = cursor.fetchone()[0]
        
        conn.close()
        
        # Create report message
        report = f"📊 گزارش فعالیت گروه (۷ روز گذشته):\n\n"
        report += f"🔢 آیدی گروه: {group_id}\n"
        report += f"📝 تعداد پیام‌ها: {message_count}\n"
        report += f"👥 کاربران فعال: {active_users}\n"
        report += f"⚠️ اخطارهای صادر شده: {warning_count}\n"
        
        # Add buttons for more detailed reports
        keyboard = [
            [InlineKeyboardButton("📈 نمودار فعالیت", callback_data=f'activity_chart_{group_id}')],
            [InlineKeyboardButton("👤 کاربران فعال", callback_data=f'active_users_{group_id}')],
            [InlineKeyboardButton("⚠️ جزئیات اخطارها", callback_data=f'warning_details_{group_id}')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(report, reply_markup=reply_markup)
        
    except Exception as e:
        logger.error(f"Error in group_activity_report: {str(e)}")
        await update.message.reply_text(f"خطا در تهیه گزارش: {str(e)}")


async def reports_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle callbacks for reports buttons"""
    query = update.callback_query
    await query.answer()
    
    try:
        # Extract group_id from callback data
        if query.data.startswith('weekly_report_'):
            group_id = int(query.data.split('_')[-1])
            await handle_weekly_report(query, context, group_id)
            
        elif query.data.startswith('active_users_'):
            group_id = int(query.data.split('_')[-1])
            await handle_active_users(query, context, group_id)
            
        elif query.data.startswith('warning_details_'):
            group_id = int(query.data.split('_')[-1])
            await handle_warning_details(query, context, group_id)
            
        elif query.data.startswith('activity_chart_'):
            group_id = int(query.data.split('_')[-1])
            await handle_activity_chart(query, context, group_id)
            
    except Exception as e:
        logger.error(f"Error in reports_callback_handler: {str(e)}")
        await query.message.edit_text(f"خطایی رخ داد: {str(e)}")

async def handle_weekly_report(query, context, group_id):
    """Handle weekly report button"""
    try:
        # Get statistics from database for the last week
        today = datetime.now()
        week_ago = today - timedelta(days=7)
        
        conn = db.get_connection()
        cursor = conn.cursor()
        
        # Get daily message counts for the last 7 days
        daily_messages = []
        for i in range(7):
            day = today - timedelta(days=i)
            day_start = day.replace(hour=0, minute=0, second=0, microsecond=0)
            day_end = day.replace(hour=23, minute=59, second=59, microsecond=999999)
            
            cursor.execute("""
                SELECT COUNT(*) FROM messages 
                WHERE group_id = ? AND timestamp BETWEEN ? AND ?
            """, (group_id, day_start.strftime("%Y-%m-%d %H:%M:%S"), day_end.strftime("%Y-%m-%d %H:%M:%S")))
            count = cursor.fetchone()[0]
            daily_messages.append((day.strftime("%Y-%m-%d"), count))
        
        # Get top 5 active users
        cursor.execute("""
            SELECT user_id, COUNT(*) as msg_count FROM messages 
            WHERE group_id = ? AND timestamp > ?
            GROUP BY user_id ORDER BY msg_count DESC LIMIT 5
        """, (group_id, week_ago.strftime("%Y-%m-%d %H:%M:%S")))
        top_users = cursor.fetchall()
        
        # Get usernames for top users
        top_users_info = []
        for user_id, msg_count in top_users:
            cursor.execute("SELECT username FROM users WHERE user_id = ?", (user_id,))
            result = cursor.fetchone()
            username = result[0] if result and result[0] else f"کاربر {user_id}"
            top_users_info.append((username, msg_count))
        
        conn.close()
        
        # Create report message
        report = f"📊 گزارش هفتگی گروه:\n\n"
        
        # Add daily message counts
        report += "📝 تعداد پیام‌ها در ۷ روز گذشته:\n"
        for date, count in reversed(daily_messages):
            report += f"{date}: {count} پیام\n"
        
        report += "\n👥 کاربران فعال برتر:\n"
        for i, (username, count) in enumerate(top_users_info, 1):
            report += f"{i}. {username}: {count} پیام\n"
        
        # Add back button
        keyboard = [
            [InlineKeyboardButton("🔙 بازگشت", callback_data=f'stats_{group_id}')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.message.edit_text(report, reply_markup=reply_markup)
        
    except Exception as e:
        logger.error(f"Error in handle_weekly_report: {str(e)}")
        await query.message.edit_text(f"خطا در تهیه گزارش هفتگی: {str(e)}")

async def handle_active_users(query, context, group_id):
    """Handle active users button"""
    try:
        # Get active users from the last week
        today = datetime.now()
        week_ago = today - timedelta(days=7)
        
        conn = db.get_connection()
        cursor = conn.cursor()
        
        # Get all users who sent messages in the last week
        cursor.execute("""
            SELECT u.user_id, u.username, u.first_name, COUNT(m.id) as msg_count 
            FROM users u JOIN messages m ON u.user_id = m.user_id
            WHERE m.group_id = ? AND m.timestamp > ?
            GROUP BY u.user_id ORDER BY msg_count DESC
        """, (group_id, week_ago.strftime("%Y-%m-%d %H:%M:%S")))
        active_users = cursor.fetchall()
        
        conn.close()
        
        # Create report message
        if not active_users:
            report = "👥 هیچ کاربر فعالی در هفته گذشته وجود نداشته است."
        else:
            report = f"👥 کاربران فعال در ۷ روز گذشته ({len(active_users)} کاربر):\n\n"
            
            for i, (user_id, username, first_name, msg_count) in enumerate(active_users, 1):
                display_name = username or first_name or f"کاربر {user_id}"
                report += f"{i}. {display_name}: {msg_count} پیام\n"
                
                # Add page break if list is too long
                if i % 20 == 0 and i < len(active_users):
                    report += "\n... ادامه دارد ...\n\n"
        
        # Add back button
        keyboard = [
            [InlineKeyboardButton("🔙 بازگشت", callback_data=f'stats_{group_id}')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.message.edit_text(report, reply_markup=reply_markup)
        
    except Exception as e:
        logger.error(f"Error in handle_active_users: {str(e)}")
        await query.message.edit_text(f"خطا در نمایش کاربران فعال: {str(e)}")

async def handle_warning_details(query, context, group_id):
    """Handle warning details button"""
    try:
        # Get warnings from the last week
        today = datetime.now()
        week_ago = today - timedelta(days=7)
        
        conn = db.get_connection()
        cursor = conn.cursor()
        
        # Get all warnings in the last week
        cursor.execute("""
            SELECT w.user_id, u.username, u.first_name, w.reason, w.timestamp, w.admin_id, a.username as admin_username
            FROM warnings w 
            JOIN users u ON w.user_id = u.user_id
            LEFT JOIN users a ON w.admin_id = a.user_id
            WHERE w.group_id = ? AND w.timestamp > ?
            ORDER BY w.timestamp DESC
        """, (group_id, week_ago.strftime("%Y-%m-%d %H:%M:%S")))
        warnings = cursor.fetchall()
        
        conn.close()
        
        # Create report message
        if not warnings:
            report = "⚠️ هیچ اخطاری در هفته گذشته ثبت نشده است."
        else:
            report = f"⚠️ اخطارهای ثبت شده در ۷ روز گذشته ({len(warnings)} اخطار):\n\n"
            
            for i, (user_id, username, first_name, reason, timestamp, admin_id, admin_username) in enumerate(warnings, 1):
                user_display = username or first_name or f"کاربر {user_id}"
                admin_display = admin_username or f"ادمین {admin_id}"
                report += f"{i}. کاربر: {user_display}\n"
                report += f"   دلیل: {reason or 'بدون دلیل'}\n"
                report += f"   زمان: {timestamp}\n"
                report += f"   توسط: {admin_display}\n\n"
                
                # Add page break if list is too long
                if i % 5 == 0 and i < len(warnings):
                    report += "... ادامه دارد ...\n\n"
        
        # Add back button
        keyboard = [
            [InlineKeyboardButton("🔙 بازگشت", callback_data=f'stats_{group_id}')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.message.edit_text(report, reply_markup=reply_markup)
        
    except Exception as e:
        logger.error(f"Error in handle_warning_details: {str(e)}")
        await query.message.edit_text(f"خطا در نمایش جزئیات اخطارها: {str(e)}")

async def handle_activity_chart(query, context, group_id):
    """Handle activity chart button"""
    try:
        # Get message counts by hour for the last week
        today = datetime.now()
        week_ago = today - timedelta(days=7)
        
        conn = db.get_connection()
        cursor = conn.cursor()
        
        # Get message counts by hour
        cursor.execute("""
            SELECT strftime('%H', timestamp) as hour, COUNT(*) as count
            FROM messages 
            WHERE group_id = ? AND timestamp > ?
            GROUP BY hour
            ORDER BY hour
        """, (group_id, week_ago.strftime("%Y-%m-%d %H:%M:%S")))
        hourly_counts = cursor.fetchall()
        
        conn.close()
        
        # Create ASCII chart
        hours = [int(h) for h, _ in hourly_counts]
        counts = [c for _, c in hourly_counts]
        
        # Fill missing hours with zero
        full_hours = []
        full_counts = []
        for h in range(24):
            if h in hours:
                idx = hours.index(h)
                full_hours.append(h)
                full_counts.append(counts[idx])
            else:
                full_hours.append(h)
                full_counts.append(0)
        
        # Find max count for scaling
        max_count = max(full_counts) if full_counts else 0
        scale_factor = 10 / max_count if max_count > 0 else 0
        
        # Create chart
        chart = "📈 نمودار فعالیت گروه بر اساس ساعت (۷ روز گذشته):\n\n"
        
        for h, c in zip(full_hours, full_counts):
            bar_length = int(c * scale_factor)
            bar = "█" * bar_length
            chart += f"{h:02d}:00 | {bar} {c}\n"
        
        # Add back button
        keyboard = [
            [InlineKeyboardButton("🔙 بازگشت", callback_data=f'stats_{group_id}')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await query.message.edit_text(chart, reply_markup=reply_markup)
        
    except Exception as e:
        logger.error(f"Error in handle_activity_chart: {str(e)}")
        await query.message.edit_text(f"خطا در نمایش نمودار فعالیت: {str(e)}")