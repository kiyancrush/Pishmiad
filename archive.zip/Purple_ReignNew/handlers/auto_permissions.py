import logging
from telegram import Update, ChatMember
from telegram.ext import ContextTypes
from telegram.error import TelegramError, BadRequest, Forbidden
from config import ADMIN_ID
from database.premium import PremiumManager

logger = logging.getLogger(__name__)

class AutoPermissionManager:
    def __init__(self, premium_manager: PremiumManager):
        self.premium_manager = premium_manager

    async def grant_premium_admin_access(self, context: ContextTypes.DEFAULT_TYPE, group_id: int):
        """Grant full admin access to group admins and creator when group becomes premium"""
        try:
            logger.info(f"Starting admin access grant process for group {group_id}")
            
            # Get all current administrators
            administrators = await context.bot.get_chat_administrators(group_id)
            
            granted_permissions = []
            failed_permissions = []
            
            for admin in administrators:
                try:
                    # Skip if it's the bot itself
                    if admin.user.id == context.bot.id:
                        logger.info(f"Skipping bot itself in group {group_id}")
                        continue
                        
                    # Skip if user is already creator (has all permissions)
                    if admin.status == 'creator':
                        granted_permissions.append({
                            'user_id': admin.user.id,
                            'username': admin.user.username or 'بدون نام کاربری',
                            'first_name': admin.user.first_name or 'نام نامشخص',
                            'status': 'سازنده گروه (دارای تمام دسترسی‌ها)'
                        })
                        logger.info(f"User {admin.user.id} is creator in group {group_id}")
                        continue
                        
                    # Check current permissions
                    current_permissions = {
                        'can_delete_messages': getattr(admin, 'can_delete_messages', False),
                        'can_restrict_members': getattr(admin, 'can_restrict_members', False),
                        'can_promote_members': getattr(admin, 'can_promote_members', False),
                        'can_change_info': getattr(admin, 'can_change_info', False),
                        'can_invite_users': getattr(admin, 'can_invite_users', False),
                        'can_pin_messages': getattr(admin, 'can_pin_messages', False),
                        'can_manage_topics': getattr(admin, 'can_manage_topics', False),
                        'can_manage_video_chats': getattr(admin, 'can_manage_video_chats', False)
                    }
                    
                    # Check if user already has all permissions
                    if all(current_permissions.values()):
                        granted_permissions.append({
                            'user_id': admin.user.id,
                            'username': admin.user.username or 'بدون نام کاربری',
                            'first_name': admin.user.first_name or 'نام نامشخص',
                            'status': 'دارای تمام دسترسی‌ها'
                        })
                        logger.info(f"User {admin.user.id} already has full permissions in group {group_id}")
                        continue
                        
                    # Grant full admin permissions
                    await context.bot.promote_chat_member(
                        chat_id=group_id,
                        user_id=admin.user.id,
                        can_delete_messages=True,
                        can_restrict_members=True,
                        can_promote_members=True,
                        can_change_info=True,
                        can_invite_users=True,
                        can_pin_messages=True,
                        can_manage_topics=True,
                        can_manage_video_chats=True
                    )
                    
                    granted_permissions.append({
                        'user_id': admin.user.id,
                        'username': admin.user.username or 'بدون نام کاربری',
                        'first_name': admin.user.first_name or 'نام نامشخص',
                        'status': 'ارتقا به ادمین کامل'
                    })
                    
                    logger.info(f"Successfully granted full admin access to user {admin.user.id} in group {group_id}")
                    
                except BadRequest as e:
                    error_msg = str(e)
                    if "not enough rights" in error_msg.lower():
                        error_msg = "ربات دسترسی کافی برای ارتقا ندارد"
                    elif "user_not_mutual_contact" in error_msg.lower():
                        error_msg = "کاربر با ربات در تماس نیست"
                        
                    failed_permissions.append({
                        'user_id': admin.user.id,
                        'username': admin.user.username or 'بدون نام کاربری',
                        'first_name': admin.user.first_name or 'نام نامشخص',
                        'error': error_msg
                    })
                    logger.error(f"BadRequest error granting admin access to user {admin.user.id} in group {group_id}: {error_msg}")
                    
                except Forbidden as e:
                    failed_permissions.append({
                        'user_id': admin.user.id,
                        'username': admin.user.username or 'بدون نام کاربری',
                        'first_name': admin.user.first_name or 'نام نامشخص',
                        'error': "ربات مسدود شده یا دسترسی ندارد"
                    })
                    logger.error(f"Forbidden error granting admin access to user {admin.user.id} in group {group_id}: {str(e)}")
                    
                except TelegramError as e:
                    failed_permissions.append({
                        'user_id': admin.user.id,
                        'username': admin.user.username or 'بدون نام کاربری',
                        'first_name': admin.user.first_name or 'نام نامشخص',
                        'error': f"خطای تلگرام: {str(e)}"
                    })
                    logger.error(f"Telegram error granting admin access to user {admin.user.id} in group {group_id}: {str(e)}")
                    
                except Exception as e:
                    failed_permissions.append({
                        'user_id': admin.user.id,
                        'username': admin.user.username or 'بدون نام کاربری',
                        'first_name': admin.user.first_name or 'نام نامشخص',
                        'error': f"خطای غیرمنتظره: {str(e)}"
                    })
                    logger.error(f"Unexpected error granting admin access to user {admin.user.id} in group {group_id}: {str(e)}")
            
            logger.info(f"Admin access grant process completed for group {group_id}. Granted: {len(granted_permissions)}, Failed: {len(failed_permissions)}")
            
            return {
                'success': True,
                'granted': granted_permissions,
                'failed': failed_permissions
            }
            
        except Exception as e:
            logger.error(f"Critical error in grant_premium_admin_access for group {group_id}: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'granted': [],
                'failed': []
            }

    async def notify_admin_access_granted(self, context: ContextTypes.DEFAULT_TYPE, group_id: int, result: dict):
        """Send notification about admin access changes"""
        try:
            if not result['success']:
                message = f"❌ خطا در اعطای دسترسی‌های ادمینی:\\n{result.get('error', 'خطای نامشخص')}"
            else:
                message = "🎉 گروه شما پرمیوم شد!\\n\\n"
                message += "✅ دسترسی‌های ادمینی به‌روزرسانی شد:\\n\\n"
                
                if result['granted']:
                    message += "👥 کاربران با دسترسی کامل:\\n"
                    for user in result['granted']:
                        name = user['first_name']
                        username = f"@{user['username']}" if user['username'] != 'بدون نام کاربری' else ""
                        message += f"• {name} {username}\\n  └ {user['status']}\\n"
                
                if result['failed']:
                    message += "\n⚠️ خطا در اعطای دسترسی:\\n"
                    for user in result['failed']:
                        name = user['first_name']
                        username = f"@{user['username']}" if user['username'] != 'بدون نام کاربری' else ""
                        message += f"• {name} {username}\\n  └ {user['error']}\\n"
                
                message += "\n💎 امکانات پرمیوم فعال شد:\\n"
                message += "• سیستم اخطار خودکار ✅\\n"
                message += "• ضد لینک و ضد فحش ✅\\n"
                message += "• خوش‌آمدگویی خودکار ✅\\n"
                message += "• قفل تایم‌دار پیام همگانی ✅\\n"
                message += "• جوین اجباری چنل ✅\\n"
                message += "• مدیریت کامل گروه ✅\\n"
                message += "• پشتیبانی ۲۴ ساعته ✅"
            
            # Split message if too long
            if len(message) > 4000:
                parts = [message[i:i+4000] for i in range(0, len(message), 4000)]
                for part in parts:
                    await context.bot.send_message(chat_id=group_id, text=part)
            else:
                await context.bot.send_message(chat_id=group_id, text=message)
            
            logger.info(f"Successfully sent admin access notification to group {group_id}")
            
        except Exception as e:
            logger.error(f"Error sending admin access notification to group {group_id}: {str(e)}")

    async def check_bot_permissions(self, context: ContextTypes.DEFAULT_TYPE, group_id: int):
        """Check if bot has necessary permissions to promote users"""
        try:
            bot_member = await context.bot.get_chat_member(group_id, context.bot.id)
            
            if bot_member.status not in ['administrator', 'creator']:
                return False, "ربات ادمین گروه نیست"
            
            if not getattr(bot_member, 'can_promote_members', False):
                return False, "ربات دسترسی ارتقا کاربران ندارد"
            
            return True, "دسترسی‌های ربات کافی است"
            
        except Exception as e:
            logger.error(f"Error checking bot permissions in group {group_id}: {str(e)}")
            return False, f"خطا در بررسی دسترسی‌ها: {str(e)}"

# Global instance
auto_permission_manager = None

def get_auto_permission_manager(premium_manager: PremiumManager = None):
    """Get or create auto permission manager instance"""
    global auto_permission_manager
    if auto_permission_manager is None and premium_manager is not None:
        auto_permission_manager = AutoPermissionManager(premium_manager)
    return auto_permission_manager
