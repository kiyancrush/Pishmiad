import logging
import asyncio
import time
import uuid
import base64
import json
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InputMediaPhoto
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from config import ADMIN_ID
import sqlite3
import io
from PIL import Image, ImageDraw, ImageFont
import random

# تنظیم لاگر
logger = logging.getLogger(__name__)

# پایگاه داده لینک‌های شیشه‌ای
class GlassLinksDB:
    def __init__(self, db_path="glass_links.db"):
        self.db_path = db_path
        self.init_db()
    
    def init_db(self):
        """مقداردهی اولیه پایگاه داده"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS glass_links (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                link_id TEXT UNIQUE NOT NULL,
                creator_id INTEGER NOT NULL,
                creator_username TEXT,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                content_type TEXT NOT NULL,
                expiry_type TEXT NOT NULL,
                expiry_value INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP,
                max_views INTEGER DEFAULT 1,
                current_views INTEGER DEFAULT 0,
                is_active BOOLEAN DEFAULT 1,
                background_style TEXT DEFAULT 'gradient',
                text_color TEXT DEFAULT 'white',
                is_private BOOLEAN DEFAULT 0
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS glass_link_views (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                link_id TEXT NOT NULL,
                viewer_id INTEGER,
                viewer_username TEXT,
                viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                ip_hash TEXT
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def create_link(self, creator_id, creator_username, title, content, content_type, 
                   expiry_type, expiry_value, max_views=1, background_style='gradient', 
                   text_color='white', is_private=False):
        """ایجاد لینک شیشه‌ای جدید"""
        link_id = str(uuid.uuid4())[:8]
        
        # محاسبه زمان انقضا
        expires_at = None
        if expiry_type == 'time':
            expires_at = datetime.now() + timedelta(hours=expiry_value)
        elif expiry_type == 'days':
            expires_at = datetime.now() + timedelta(days=expiry_value)
        elif expiry_type == 'weeks':
            expires_at = datetime.now() + timedelta(weeks=expiry_value)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO glass_links 
            (link_id, creator_id, creator_username, title, content, content_type, 
             expiry_type, expiry_value, expires_at, max_views, background_style, 
             text_color, is_private)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (link_id, creator_id, creator_username, title, content, content_type,
              expiry_type, expiry_value, expires_at, max_views, background_style,
              text_color, is_private))
        
        conn.commit()
        conn.close()
        
        return link_id
    
    def get_link(self, link_id):
        """دریافت اطلاعات لینک"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM glass_links WHERE link_id = ?', (link_id,))
        result = cursor.fetchone()
        
        conn.close()
        return result
    
    def add_view(self, link_id, viewer_id=None, viewer_username=None, ip_hash=None):
        """اضافه کردن بازدید"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # اضافه کردن بازدید
        cursor.execute('''
            INSERT INTO glass_link_views (link_id, viewer_id, viewer_username, ip_hash)
            VALUES (?, ?, ?, ?)
        ''', (link_id, viewer_id, viewer_username, ip_hash))
        
        # به‌روزرسانی تعداد بازدیدها
        cursor.execute('''
            UPDATE glass_links 
            SET current_views = current_views + 1 
            WHERE link_id = ?
        ''', (link_id,))
        
        conn.commit()
        conn.close()
    
    def is_link_valid(self, link_id):
        """بررسی معتبر بودن لینک"""
        link_data = self.get_link(link_id)
        if not link_data:
            return False, "لینک یافت نشد"
        
        # بررسی فعال بودن
        if not link_data[14]:  # is_active
            return False, "لینک غیرفعال شده است"
        
        # بررسی تعداد بازدید
        if link_data[12] >= link_data[11]:  # current_views >= max_views
            return False, "حد مجاز بازدید این لینک تمام شده است"
        
        # بررسی زمان انقضا
        if link_data[10]:  # expires_at
            expires_at = datetime.fromisoformat(link_data[10])
            if datetime.now() > expires_at:
                return False, "زمان این لینک به پایان رسیده است"
        
        return True, "معتبر"
    
    def get_user_links(self, user_id):
        """دریافت لینک‌های کاربر"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT link_id, title, content_type, created_at, current_views, max_views, is_active
            FROM glass_links 
            WHERE creator_id = ? 
            ORDER BY created_at DESC
        ''', (user_id,))
        
        results = cursor.fetchall()
        conn.close()
        return results

# نمونه پایگاه داده
glass_db = GlassLinksDB()

def generate_glass_image(title, content, background_style='gradient', text_color='white'):
    """تولید تصویر شیشه‌ای زیبا"""
    try:
        # اندازه تصویر
        width, height = 800, 600
        
        # ایجاد تصویر جدید
        img = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        
        # رنگ‌های مختلف برای پس‌زمینه
        backgrounds = {
            'gradient': [(138, 43, 226), (30, 144, 255)],  # بنفش به آبی
            'sunset': [(255, 94, 77), (255, 154, 0)],      # نارنجی غروب
            'ocean': [(0, 119, 190), (0, 180, 216)],       # آبی اقیانوس
            'forest': [(76, 175, 80), (139, 195, 74)],     # سبز جنگل
            'aurora': [(106, 17, 203), (37, 117, 252)],    # شفق قطبی
            'fire': [(255, 61, 0), (255, 154, 0)],         # آتش
            'mint': [(67, 206, 162), (24, 90, 157)],       # نعنایی
            'royal': [(116, 116, 191), (52, 138, 199)]     # سلطنتی
        }
        
        colors = backgrounds.get(background_style, backgrounds['gradient'])
        
        # ایجاد گرادیان
        for y in range(height):
            ratio = y / height
            r = int(colors[0][0] * (1 - ratio) + colors[1][0] * ratio)
            g = int(colors[0][1] * (1 - ratio) + colors[1][1] * ratio)
            b = int(colors[0][2] * (1 - ratio) + colors[1][2] * ratio)
            draw.line([(0, y), (width, y)], fill=(r, g, b, 180))
        
        # افزودن افکت شیشه‌ای
        overlay = Image.new('RGBA', (width, height), (255, 255, 255, 30))
        img = Image.alpha_composite(img, overlay)
        
        # اضافه کردن حاشیه شیشه‌ای
        draw = ImageDraw.Draw(img)
        margin = 40
        draw.rounded_rectangle(
            [margin, margin, width-margin, height-margin],
            radius=20,
            outline=(255, 255, 255, 100),
            width=3
        )
        
        # تنظیم فونت (استفاده از فونت پیش‌فرض)
        try:
            title_font = ImageFont.truetype("arial.ttf", 48)
            content_font = ImageFont.truetype("arial.ttf", 24)
        except:
            title_font = ImageFont.load_default()
            content_font = ImageFont.load_default()
        
        # رنگ متن
        text_colors = {
            'white': (255, 255, 255, 255),
            'black': (0, 0, 0, 255),
            'gold': (255, 215, 0, 255),
            'silver': (192, 192, 192, 255)
        }
        
        text_fill = text_colors.get(text_color, text_colors['white'])
        
        # اضافه کردن عنوان
        title_bbox = draw.textbbox((0, 0), title, font=title_font)
        title_width = title_bbox[2] - title_bbox[0]
        title_x = (width - title_width) // 2
        title_y = 120
        
        # سایه برای متن
        draw.text((title_x+2, title_y+2), title, fill=(0, 0, 0, 100), font=title_font)
        draw.text((title_x, title_y), title, fill=text_fill, font=title_font)
        
        # اضافه کردن محتوا
        max_width = width - 100
        lines = []
        words = content.split()
        current_line = ""
        
        for word in words:
            test_line = current_line + " " + word if current_line else word
            bbox = draw.textbbox((0, 0), test_line, font=content_font)
            if bbox[2] - bbox[0] <= max_width:
                current_line = test_line
            else:
                if current_line:
                    lines.append(current_line)
                current_line = word
        
        if current_line:
            lines.append(current_line)
        
        # محدود کردن تعداد خطوط
        if len(lines) > 10:
            lines = lines[:10]
            lines[-1] += "..."
        
        content_y = title_y + 80
        for line in lines:
            bbox = draw.textbbox((0, 0), line, font=content_font)
            line_width = bbox[2] - bbox[0]
            line_x = (width - line_width) // 2
            
            # سایه
            draw.text((line_x+1, content_y+1), line, fill=(0, 0, 0, 100), font=content_font)
            draw.text((line_x, content_y), line, fill=text_fill, font=content_font)
            content_y += 35
        
        # اضافه کردن لوگو یا نشان آبی
        draw.ellipse([width-100, height-100, width-20, height-20], 
                    fill=(255, 255, 255, 80))
        draw.text((width-70, height-70), "💎", font=title_font)
        
        # ذخیره تصویر در حافظه
        img_bytes = io.BytesIO()
        img.save(img_bytes, format='PNG')
        img_bytes.seek(0)
        
        return img_bytes
        
    except Exception as e:
        logger.error(f"Error generating glass image: {str(e)}")
        return None

async def create_glass_link_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """شروع فرآیند ساخت لینک شیشه‌ای"""
    try:
        # بررسی دسترسی (فقط در گروه)
        if update.effective_chat.type == "private":
            await update.message.reply_text(
                "🔒 لینک‌های شیشه‌ای فقط در گروه قابل ساخت هستند.\n"
                "💡 لطفاً در گروه این دستور را اجرا کنید."
            )
            return
        
        # منوی ساده ساخت لینک
        keyboard = [
            [InlineKeyboardButton("⚡ یکبار مصرف", callback_data='glass_quick_1')],
            [InlineKeyboardButton("⏰ ساعتی", callback_data='glass_quick_hour')],
            [InlineKeyboardButton("📅 روزانه", callback_data='glass_quick_day')],
            [InlineKeyboardButton("📋 لیست لینک‌های من", callback_data='glass_my_links')],
            [InlineKeyboardButton("❌ انصراف", callback_data='glass_cancel')]
        ]
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # دریافت تصویر پروفایل گروه
        try:
            chat_photos = await context.bot.get_chat(update.effective_chat.id)
            if chat_photos and hasattr(chat_photos, 'photo') and chat_photos.photo:
                # ارسال با تصویر پروفایل گروه
                await update.message.reply_photo(
                    photo=chat_photos.photo.small_file_id,
                    caption="✨ <b>ساخت لینک شیشه‌ای</b> ✨\n\n"
                            "💎 <b>ویژگی‌ها:</b>\n"
                            "🔹 طراحی زیبا با تصویر گروه\n"
                            "🔹 ارسال لینک به پیوی\n"
                            "🔹 انقضای خودکار\n\n"
                            "⚡ نوع لینک را انتخاب کنید:",
                    reply_markup=reply_markup,
                    parse_mode='HTML'
                )
            else:
                # ارسال بدون تصویر
                await update.message.reply_text(
                    "✨ <b>ساخت لینک شیشه‌ای</b> ✨\n\n"
                    "💎 <b>ویژگی‌ها:</b>\n"
                    "🔹 طراحی زیبا\n"
                    "🔹 ارسال لینک به پیوی\n"
                    "🔹 انقضای خودکار\n\n"
                    "⚡ نوع لینک را انتخاب کنید:",
                    reply_markup=reply_markup,
                    parse_mode='HTML'
                )
        except:
            # اگر نتوانست عکس پروفایل بگیرد
            await update.message.reply_text(
                "✨ <b>ساخت لینک شیشه‌ای</b> ✨\n\n"
                "💎 <b>ویژگی‌ها:</b>\n"
                "🔹 طراحی زیبا\n"
                "🔹 ارسال لینک به پیوی\n"
                "🔹 انقضای خودکار\n\n"
                "⚡ نوع لینک را انتخاب کنید:",
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
        
        logger.info(f"Glass link creation started by user {update.effective_user.id}")
        
    except Exception as e:
        logger.error(f"Error in create_glass_link_handler: {str(e)}")
        await update.message.reply_text("❌ خطایی رخ داد. لطفاً دوباره تلاش کنید.")

async def glass_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """مدیریت callback های مربوط به لینک شیشه‌ای"""
    try:
        query = update.callback_query
        await query.answer()
        
        user_id = query.from_user.id
        data = query.data
        
        if data == 'glass_cancel':
            await query.message.delete()
            return
        
        elif data == 'glass_my_links':
            await show_user_links(query, user_id)
            
        elif data.startswith('glass_create_'):
            content_type = data.replace('glass_create_', '')
            await start_link_creation(query, content_type)
            
        elif data.startswith('glass_quick_'):
            quick_type = data.replace('glass_quick_', '')
            await start_quick_link_creation(query, quick_type)
            
        elif data.startswith('glass_style_'):
            style = data.replace('glass_style_', '')
            await select_expiry_settings(query, style)
            
        elif data.startswith('glass_expiry_'):
            expiry_type = data.replace('glass_expiry_', '')
            await select_expiry_value(query, expiry_type)
            
        elif data.startswith('glass_views_'):
            max_views = int(data.replace('glass_views_', ''))
            await finalize_link_creation(query, max_views)
            
        elif data.startswith('glass_view_'):
            link_id = data.replace('glass_view_', '')
            await view_glass_link(query, link_id)
            
        elif data.startswith('glass_time_'):
            time_value = int(data.replace('glass_time_', ''))
            user_id = query.from_user.id
            if user_id in user_temp_data:
                user_temp_data[user_id]['expiry_value'] = time_value
            await select_view_limit(query)
            
    except Exception as e:
        logger.error(f"Error in glass_callback_handler: {str(e)}")
        await query.message.reply_text("❌ خطایی رخ داد.")

async def show_user_links(query, user_id):
    """نمایش لینک‌های کاربر"""
    links = glass_db.get_user_links(user_id)
    
    if not links:
        await query.message.edit_text(
            "📭 شما هنوز لینک شیشه‌ای نساخته‌اید!\n\n"
            "✨ برای ساخت اولین لینک از دستور /glass استفاده کنید.",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("🔙 بازگشت", callback_data='glass_cancel')
            ]])
        )
        return
    
    message = "📋 <b>لینک‌های شیشه‌ای شما:</b>\n\n"
    keyboard = []
    
    for i, link in enumerate(links[:10], 1):  # حداکثر 10 لینک
        link_id, title, content_type, created_at, current_views, max_views, is_active = link
        
        status = "🟢 فعال" if is_active else "🔴 غیرفعال"
        type_emoji = {
            'text': '📝', 'image': '🖼️', 
            'audio': '🎵', 'video': '📹'
        }.get(content_type, '📄')
        
        message += f"{i}. {type_emoji} <b>{title[:20]}...</b>\n"
        message += f"   👁️ {current_views}/{max_views} | {status}\n"
        message += f"   🔗 <code>https://t.me/your_bot?start=glass_{link_id}</code>\n\n"
        
        keyboard.append([InlineKeyboardButton(
            f"{i}. {title[:15]}...", 
            callback_data=f'glass_view_{link_id}'
        )])
    
    keyboard.append([InlineKeyboardButton("🔙 بازگشت", callback_data='glass_cancel')])
    
    await query.message.edit_text(
        message,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def start_link_creation(query, content_type):
    """شروع فرآیند ساخت لینک"""
    user_id = query.from_user.id
    
    # ذخیره اطلاعات در user_temp_data
    user_temp_data[user_id] = {
        'content_type': content_type,
        'step': 'title'
    }
    
    await query.message.edit_text(
        f"✨ <b>ساخت لینک شیشه‌ای - {content_type.upper()}</b>\n\n"
        "📝 لطفاً عنوان لینک خود را وارد کنید:\n"
        "(حداکثر 50 کاراکتر)",
        parse_mode='HTML'
    )

async def start_quick_link_creation(query, quick_type):
    """شروع فرآیند ساخت لینک سریع"""
    user_id = query.from_user.id
    
    # تعیین نوع لینک سریع
    if quick_type == '1':
        content_type = 'text'
        expiry_type = 'time'
        expiry_value = 1
        max_views = 1
    elif quick_type == 'hour':
        content_type = 'text'
        expiry_type = 'time'
        expiry_value = 1
        max_views = 1
    elif quick_type == 'day':
        content_type = 'text'
        expiry_type = 'days'
        expiry_value = 1
        max_views = 1
    else:
        await query.message.edit_text("❌ نوع لینک سریع معتبر نیست.")
        return
    
    # ذخیره اطلاعات در user_temp_data
    user_temp_data[user_id] = {
        'content_type': content_type,
        'expiry_type': expiry_type,
        'expiry_value': expiry_value,
        'max_views': max_views,
        'step': 'title'
    }
    
    await query.message.edit_text(
        f"✨ <b>ساخت لینک شیشه‌ای - {content_type.upper()}</b>\n\n"
        "📝 لطفاً عنوان لینک خود را وارد کنید:\n"
        "(حداکثر 50 کاراکتر)",
        parse_mode='HTML'
    )

async def view_glass_link(query, link_id):
    """نمایش محتوای لینک شیشه‌ای"""
    try:
        # بررسی معتبر بودن لینک
        is_valid, message = glass_db.is_link_valid(link_id)
        
        if not is_valid:
            await query.message.edit_text(
                f"⚠️ <b>لینک منقضی شده</b>\n\n"
                f"📝 <b>دلیل:</b> {message}\n\n"
                "💡 برای ساخت لینک جدید از دستور /glass استفاده کنید.",
                parse_mode='HTML'
            )
            return
        
        # دریافت اطلاعات لینک
        link_data = glass_db.get_link(link_id)
        if not link_data:
            await query.message.edit_text("❌ لینک یافت نشد.")
            return
        
        # اضافه کردن بازدید
        glass_db.add_view(link_id, query.from_user.id, query.from_user.username)
        
        # استخراج اطلاعات
        title = link_data[3]
        content = link_data[4]
        content_type = link_data[5]
        background_style = link_data[13]
        text_color = link_data[14]
        
        # نمایش محتوا بر اساس نوع
        if content_type == 'text':
            # تولید تصویر شیشه‌ای
            glass_image = generate_glass_image(title, content, background_style, text_color)
            
            if glass_image:
                # ارسال به صورت عکس
                await query.message.reply_photo(
                    photo=glass_image,
                    caption=f"✨ <b>{title}</b>\n\n{content}",
                    parse_mode='HTML'
                )
            else:
                # ارسال به صورت متن در صورت خرابی تصویر
                await query.message.edit_text(
                    f"✨ <b>{title}</b>\n\n"
                    f"{content}\n\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"💎 <i>ارسال شده از لینک شیشه‌ای</i>",
                    parse_mode='HTML'
                )
        
        # حذف لینک اگر یکبار مصرف باشد
        if link_data[12] >= link_data[11]:  # current_views >= max_views
            await query.message.reply_text(
                "🔥 <b>این لینک منقضی شد!</b>\n\n"
                "✨ این پیام فقط برای شما قابل مشاهده بود.\n"
                "💎 لینک شیشه‌ای - یکبار مصرف",
                parse_mode='HTML'
            )
        
        logger.info(f"Glass link {link_id} viewed by user {query.from_user.id}")
        
    except Exception as e:
        logger.error(f"Error viewing glass link: {str(e)}")
        await query.message.edit_text("❌ خطایی در نمایش لینک رخ داد.")

async def handle_glass_start_parameter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """مدیریت پارامتر start برای لینک‌های شیشه‌ای"""
    try:
        if not context.args or not context.args[0].startswith('glass_'):
            return False
        
        link_id = context.args[0].replace('glass_', '')
        
        # بررسی معتبر بودن لینک
        is_valid, message = glass_db.is_link_valid(link_id)
        
        if not is_valid:
            await update.message.reply_text(
                f"⚠️ <b>لینک منقضی شده</b>\n\n"
                f"📝 <b>دلیل:</b> {message}\n\n"
                "💡 لینک‌های شیشه‌ای محدودیت زمانی و تعداد بازدید دارند.",
                parse_mode='HTML'
            )
            return True
        
        # دریافت اطلاعات لینک
        link_data = glass_db.get_link(link_id)
        if not link_data:
            await update.message.reply_text("❌ لینک یافت نشد.")
            return True
        
        # اضافه کردن بازدید
        glass_db.add_view(link_id, update.effective_user.id, update.effective_user.username)
        
        # استخراج اطلاعات
        title = link_data[3]
        content = link_data[4]
        content_type = link_data[5]
        background_style = link_data[13] if len(link_data) > 13 else 'gradient'
        text_color = link_data[14] if len(link_data) > 14 else 'white'
        creator_username = link_data[2]
        
        # نمایش محتوا
        if content_type == 'text':
            # تولید تصویر شیشه‌ای
            glass_image = generate_glass_image(title, content, background_style, text_color)
            
            if glass_image:
                # ارسال به صورت عکس
                await update.message.reply_photo(
                    photo=glass_image,
                    caption=f"✨ <b>{title}</b>\n\n"
                           f"{content}\n\n"
                           f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                           f"💎 <i>لینک شیشه‌ای توسط @{creator_username or 'نامشخص'}</i>",
                    parse_mode='HTML'
                )
            else:
                # ارسال به صورت متن
                await update.message.reply_text(
                    f"✨ <b>{title}</b>\n\n"
                    f"{content}\n\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"💎 <i>لینک شیشه‌ای توسط @{creator_username or 'نامشخص'}</i>",
                    parse_mode='HTML'
                )
        
        # بررسی یکبار مصرف بودن
        if link_data[12] >= link_data[11]:  # current_views >= max_views
            await asyncio.sleep(2)
            await update.message.reply_text(
                "🔥 <b>این لینک منقضی شد!</b>\n\n"
                "✨ این پیام فقط برای شما قابل مشاهده بود.\n"
                "💎 لینک شیشه‌ای - یکبار مصرف\n\n"
                "🌟 برای ساخت لینک شیشه‌ای خودتان از /glass استفاده کنید.",
                parse_mode='HTML'
            )
        
        logger.info(f"Glass link {link_id} accessed via start parameter by user {update.effective_user.id}")
        return True
        
    except Exception as e:
        logger.error(f"Error handling glass start parameter: {str(e)}")
        await update.message.reply_text("❌ خطایی در بازکردن لینک رخ داد.")
        return True

# تابع اصلی برای دستور /glass
async def glass_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """دستور اصلی لینک شیشه‌ای"""
    await create_glass_link_handler(update, context)

# ذخیره موقت اطلاعات کاربران (در production باید از دیتابیس استفاده شود)
user_temp_data = {}

async def handle_glass_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """مدیریت پیام‌های مربوط به ساخت لینک شیشه‌ای"""
    try:
        user_id = update.effective_user.id
        message_text = update.message.text
        
        # بررسی وجود اطلاعات موقت کاربر
        if user_id not in user_temp_data:
            return False
        
        data = user_temp_data[user_id]
        step = data.get('step')
        
        if step == 'title':
            # دریافت عنوان
            if len(message_text) > 50:
                await update.message.reply_text(
                    "❌ عنوان نباید بیشتر از ۵۰ کاراکتر باشد.\n"
                    "لطفاً عنوان کوتاه‌تری وارد کنید:"
                )
                return True
            
            data['title'] = message_text
            data['step'] = 'content'
            
            content_type = data['content_type']
            if content_type == 'text':
                await update.message.reply_text(
                    "📝 حالا محتوای پیام خود را وارد کنید:\n"
                    "(حداکثر 500 کاراکتر)"
                )
            elif content_type == 'image':
                await update.message.reply_text(
                    "🖼️ لطفاً تصویر خود را ارسال کنید:\n"
                    "(همراه با توضیحات اختیاری)"
                )
                
        elif step == 'content':
            # دریافت محتوا
            content_type = data['content_type']
            
            if content_type == 'text':
                if len(message_text) > 500:
                    await update.message.reply_text(
                        "❌ محتوا نباید بیشتر از ۵۰۰ کاراکتر باشد.\n"
                        "لطفاً محتوای کوتاه‌تری وارد کنید:"
                    )
                    return True
                
                data['content'] = message_text
                
                # بررسی اینکه آیا اطلاعات کامل شده (برای quick links)
                if 'expiry_type' in data and 'max_views' in data:
                    await finalize_quick_link_creation(update, user_id)
                else:
                    await select_style_menu(update, user_id)
                
        return True
        
    except Exception as e:
        logger.error(f"Error handling glass message: {str(e)}")
        return False

async def handle_glass_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """مدیریت تصاویر مربوط به لینک شیشه‌ای"""
    try:
        user_id = update.effective_user.id
        
        if user_id not in user_temp_data:
            return False
        
        data = user_temp_data[user_id]
        
        if data.get('step') == 'content' and data.get('content_type') == 'image':
            # ذخیره تصویر
            photo = update.message.photo[-1]  # بزرگترین سایز
            file_id = photo.file_id
            
            caption = update.message.caption or ""
            data['content'] = f"IMAGE:{file_id}:{caption}"
            
            await update.message.reply_text("✅ تصویر دریافت شد!")
            await select_style_menu(update, user_id)
            return True
            
    except Exception as e:
        logger.error(f"Error handling glass photo: {str(e)}")
        return False

async def select_style_menu(update, user_id):
    """منوی انتخاب استایل"""
    keyboard = [
        [InlineKeyboardButton("🌈 گرادیان", callback_data='glass_style_gradient'),
         InlineKeyboardButton("🌅 غروب", callback_data='glass_style_sunset')],
        [InlineKeyboardButton("🌊 اقیانوس", callback_data='glass_style_ocean'),
         InlineKeyboardButton("🌲 جنگل", callback_data='glass_style_forest')],
        [InlineKeyboardButton("🌌 شفق قطبی", callback_data='glass_style_aurora'),
         InlineKeyboardButton("🔥 آتش", callback_data='glass_style_fire')],
        [InlineKeyboardButton("🍃 نعنایی", callback_data='glass_style_mint'),
         InlineKeyboardButton("👑 سلطنتی", callback_data='glass_style_royal')]
    ]
    
    await update.message.reply_text(
        "🎨 <b>انتخاب استایل پس‌زمینه:</b>\n\n"
        "رنگ و استایل مورد نظر خود را انتخاب کنید:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def select_expiry_settings(query, style):
    """انتخاب تنظیمات انقضا"""
    user_id = query.from_user.id
    if user_id in user_temp_data:
        user_temp_data[user_id]['background_style'] = style
    
    keyboard = [
        [InlineKeyboardButton("⏱️ ساعتی", callback_data='glass_expiry_time')],
        [InlineKeyboardButton("📅 روزانه", callback_data='glass_expiry_days')],
        [InlineKeyboardButton("📆 هفتگی", callback_data='glass_expiry_weeks')],
        [InlineKeyboardButton("♾️ بدون انقضا", callback_data='glass_expiry_never')]
    ]
    
    await query.message.edit_text(
        "⏰ <b>تنظیم زمان انقضا:</b>\n\n"
        "مدت زمان فعال بودن لینک را انتخاب کنید:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def select_expiry_value(query, expiry_type):
    """انتخاب مقدار انقضا"""
    user_id = query.from_user.id
    if user_id in user_temp_data:
        user_temp_data[user_id]['expiry_type'] = expiry_type
    
    keyboard = []
    
    if expiry_type == 'time':
        options = [
            ("1 ساعت", 1), ("3 ساعت", 3), ("6 ساعت", 6),
            ("12 ساعت", 12), ("24 ساعت", 24)
        ]
    elif expiry_type == 'days':
        options = [
            ("1 روز", 1), ("3 روز", 3), ("7 روز", 7),
            ("15 روز", 15), ("30 روز", 30)
        ]
    elif expiry_type == 'weeks':
        options = [
            ("1 هفته", 1), ("2 هفته", 2), ("4 هفته", 4),
            ("8 هفته", 8), ("12 هفته", 12)
        ]
    else:  # never
        user_temp_data[user_id]['expiry_value'] = 0
        await select_view_limit(query)
        return
    
    for text, value in options:
        keyboard.append([InlineKeyboardButton(text, callback_data=f'glass_time_{value}')])
    
    await query.message.edit_text(
        f"🕐 <b>انتخاب مدت زمان:</b>\n\n"
        f"مدت {expiry_type} را انتخاب کنید:",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def select_view_limit(query):
    """انتخاب محدودیت تعداد بازدید"""
    keyboard = [
        [InlineKeyboardButton("👁️ یکبار مصرف", callback_data='glass_views_1')],
        [InlineKeyboardButton("👁️ 3 بار", callback_data='glass_views_3')],
        [InlineKeyboardButton("👁️ 5 بار", callback_data='glass_views_5')],
        [InlineKeyboardButton("👁️ 10 بار", callback_data='glass_views_10')],
        [InlineKeyboardButton("👁️ 25 بار", callback_data='glass_views_25')],
        [InlineKeyboardButton("♾️ نامحدود", callback_data='glass_views_999')]
    ]
    
    await query.message.edit_text(
        "👁️ <b>تعداد مجاز بازدید:</b>\n\n"
        "چند نفر می‌توانند این لینک را ببینند؟",
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode='HTML'
    )

async def finalize_link_creation(query, max_views):
    """نهایی سازی و ایجاد لینک"""
    try:
        user_id = query.from_user.id
        
        if user_id not in user_temp_data:
            await query.message.edit_text("❌ اطلاعات جلسه منقضی شده. دوباره تلاش کنید.")
            return
        
        data = user_temp_data[user_id]
        data['max_views'] = max_views
        
        # ایجاد لینک در دیتابیس
        link_id = glass_db.create_link(
            creator_id=user_id,
            creator_username=query.from_user.username,
            title=data['title'],
            content=data['content'],
            content_type=data['content_type'],
            expiry_type=data['expiry_type'],
            expiry_value=data.get('expiry_value', 0),
            max_views=max_views,
            background_style=data.get('background_style', 'gradient'),
            text_color='white'
        )
        
        # پاک کردن اطلاعات موقت
        del user_temp_data[user_id]
        
        # ایجاد لینک نهایی
        bot_username = context.bot.username if hasattr(context, 'bot') else "your_bot"
        share_link = f"https://t.me/{bot_username}?start=glass_{link_id}"
        
        # نمایش تصویر پیش‌نمایش
        if data['content_type'] == 'text':
            glass_image = generate_glass_image(
                data['title'], 
                data['content'], 
                data.get('background_style', 'gradient'), 
                'white'
            )
            
            if glass_image:
                await query.message.reply_photo(
                    photo=glass_image,
                    caption=f"✨ <b>لینک شیشه‌ای ساخته شد!</b>\n\n"
                           f"🔗 <code>{share_link}</code>\n\n"
                           f"📋 <b>جزئیات:</b>\n"
                           f"📝 عنوان: {data['title']}\n"
                           f"👁️ حداکثر بازدید: {max_views}\n"
                           f"⏰ انقضا: {data['expiry_type']}\n\n"
                           f"💡 این لینک را با دوستان خود به اشتراک بگذارید!",
                    parse_mode='HTML'
                )
            else:
                await query.message.edit_text(
                    f"✅ <b>لینک شیشه‌ای ساخته شد!</b>\n\n"
                    f"🔗 <code>{share_link}</code>\n\n"
                    f"📋 <b>جزئیات:</b>\n"
                    f"📝 عنوان: {data['title']}\n"
                    f"👁️ حداکثر بازدید: {max_views}\n"
                    f"⏰ انقضا: {data['expiry_type']}\n\n"
                    f"💡 این لینک را با دوستان خود به اشتراک بگذارید!",
                    parse_mode='HTML'
                )
        
        logger.info(f"Glass link {link_id} created successfully by user {user_id}")
        
    except Exception as e:
        logger.error(f"Error finalizing link creation: {str(e)}")
        await query.message.edit_text("❌ خطایی در ساخت لینک رخ داد.")

async def finalize_quick_link_creation(update, user_id):
    """نهایی سازی و ایجاد لینک سریع"""
    try:
        if user_id not in user_temp_data:
            await update.message.reply_text("❌ اطلاعات جلسه منقضی شده. دوباره تلاش کنید.")
            return
        
        data = user_temp_data[user_id]
        
        # ایجاد لینک در دیتابیس
        link_id = glass_db.create_link(
            creator_id=user_id,
            creator_username=update.effective_user.username,
            title=data['title'],
            content=data['content'],
            content_type=data['content_type'],
            expiry_type=data['expiry_type'],
            expiry_value=data.get('expiry_value', 0),
            max_views=data['max_views'],
            background_style='gradient',
            text_color='white'
        )
        
        # پاک کردن اطلاعات موقت
        del user_temp_data[user_id]
        
        # ایجاد لینک نهایی
        bot_username = "your_bot"  # اینجا نام کاربری ربات باید وارد شود
        share_link = f"https://t.me/{bot_username}?start=glass_{link_id}"
        
        # تولید تصویر شیشه‌ای با تصویر گروه
        try:
            # دریافت تصویر پروفایل گروه
            from telegram import Update
            chat = await update.get_bot().get_chat(update.effective_chat.id)
            group_photo = None
            
            if chat and hasattr(chat, 'photo') and chat.photo:
                group_photo = chat.photo.big_file_id
            
            # تولید تصویر شیشه‌ای
            glass_image = generate_glass_image_with_group_photo(
                data['title'], 
                data['content'], 
                group_photo,
                'gradient', 
                'white'
            )
            
            if glass_image:
                # ارسال لینک به پیوی کاربر
                try:
                    await update.get_bot().send_photo(
                        chat_id=user_id,
                        photo=glass_image,
                        caption=f"✨ <b>لینک شیشه‌ای ساخته شد!</b>\n\n"
                               f"🔗 <code>{share_link}</code>\n\n"
                               f"📋 <b>جزئیات:</b>\n"
                               f"📝 عنوان: {data['title']}\n"
                               f"👁️ حداکثر بازدید: {data['max_views']}\n"
                               f"⏰ انقضا: {data['expiry_type']}\n\n"
                               f"💡 این لینک را با دوستان خود به اشتراک بگذارید!",
                        parse_mode='HTML'
                    )
                    
                    # پیام تأیید در گروه
                    await update.message.reply_text(
                        f"✅ لینک شیشه‌ای ساخته شد!\n"
                        f"💌 لینک به پیوی شما ارسال شد.\n"
                        f"📱 می‌توانید آن را با دوستان خود به اشتراک بگذارید."
                    )
                    
                except Exception as e:
                    # اگر نتوانست به پیوی بفرستد، در گروه نمایش بده
                    await update.message.reply_photo(
                        photo=glass_image,
                        caption=f"✨ <b>لینک شیشه‌ای ساخته شد!</b>\n\n"
                               f"🔗 <code>{share_link}</code>\n\n"
                               f"⚠️ نتوانستیم لینک را به پیوی شما بفرستیم.\n"
                               f"لطفاً ابتدا با ربات در پرایوت صحبت کنید.",
                        parse_mode='HTML'
                    )
            else:
                # ارسال بدون تصویر
                await update.message.reply_text(
                    f"✅ <b>لینک شیشه‌ای ساخته شد!</b>\n\n"
                    f"🔗 <code>{share_link}</code>\n\n"
                    f"📋 <b>جزئیات:</b>\n"
                    f"📝 عنوان: {data['title']}\n"
                    f"👁️ حداکثر بازدید: {data['max_views']}\n"
                    f"⏰ انقضا: {data['expiry_type']}\n\n"
                    f"💡 این لینک را با دوستان خود به اشتراک بگذارید!",
                    parse_mode='HTML'
                )
                
        except Exception as e:
            logger.error(f"Error generating glass image: {str(e)}")
            await update.message.reply_text(
                f"✅ <b>لینک شیشه‌ای ساخته شد!</b>\n\n"
                f"🔗 <code>{share_link}</code>\n\n"
                f"💡 این لینک را با دوستان خود به اشتراک بگذارید!",
                parse_mode='HTML'
            )
        
        logger.info(f"Quick glass link {link_id} created successfully by user {user_id}")
        
    except Exception as e:
        logger.error(f"Error finalizing quick link creation: {str(e)}")
        await update.message.reply_text("❌ خطایی در ساخت لینک رخ داد.")

def generate_glass_image_with_group_photo(title, content, group_photo_file_id=None, background_style='gradient', text_color='white'):
    """تولید تصویر شیشه‌ای با عکس پروفایل گروه"""
    try:
        # اگر عکس گروه موجود باشد، آن را دانلود کن
        # فعلاً از تابع قبلی استفاده می‌کنیم
        return generate_glass_image(title, content, background_style, text_color)
        
    except Exception as e:
        logger.error(f"Error generating glass image with group photo: {str(e)}")
        return None 