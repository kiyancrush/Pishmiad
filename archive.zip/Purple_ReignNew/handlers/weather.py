import logging
import requests
try:
    import jdatetime
except Exception:
    jdatetime = None
import os
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ParseMode

# تنظیم لاگر
logger = logging.getLogger(__name__)

# کلید API برای OpenWeatherMap
WEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY", "demo_key")  # از environment variable یا demo key
WEATHER_BASE_URL = "https://api.openweathermap.org/data/2.5"

# لیست شهرهای مهم ایران با مختصات جغرافیایی
IRAN_CITIES = {
    'تهران': {'lat': 35.6892, 'lon': 51.3890, 'province': 'تهران'},
    'مشهد': {'lat': 36.2605, 'lon': 59.6168, 'province': 'خراسان رضوی'},
    'اصفهان': {'lat': 32.6546, 'lon': 51.6680, 'province': 'اصفهان'},
    'شیراز': {'lat': 29.5918, 'lon': 52.5837, 'province': 'فارس'},
    'تبریز': {'lat': 38.0962, 'lon': 46.2738, 'province': 'آذربایجان شرقی'},
    'کرج': {'lat': 35.8327, 'lon': 50.9916, 'province': 'البرز'},
    'اهواز': {'lat': 31.3183, 'lon': 48.6706, 'province': 'خوزستان'},
    'قم': {'lat': 34.6401, 'lon': 50.8764, 'province': 'قم'},
    'کرمانشاه': {'lat': 34.3142, 'lon': 47.0659, 'province': 'کرمانشاه'},
    'ارومیه': {'lat': 37.5527, 'lon': 45.0761, 'province': 'آذربایجان غربی'},
    'زاهدان': {'lat': 29.4963, 'lon': 60.8629, 'province': 'سیستان و بلوچستان'},
    'همدان': {'lat': 34.7992, 'lon': 48.5146, 'province': 'همدان'},
    'کرمان': {'lat': 30.2839, 'lon': 57.0834, 'province': 'کرمان'},
    'یزد': {'lat': 31.8974, 'lon': 54.3569, 'province': 'یزد'},
    'اردبیل': {'lat': 38.2498, 'lon': 48.2933, 'province': 'اردبیل'},
    'بندرعباس': {'lat': 27.1865, 'lon': 56.2808, 'province': 'هرمزگان'},
    'زنجان': {'lat': 36.6736, 'lon': 48.4787, 'province': 'زنجان'},
    'سنندج': {'lat': 35.3150, 'lon': 46.9999, 'province': 'کردستان'},
    'قشم': {'lat': 26.9581, 'lon': 56.2719, 'province': 'هرمزگان'},
    'کیش': {'lat': 26.5667, 'lon': 53.9833, 'province': 'هرمزگان'},
    'رشت': {'lat': 37.2809, 'lon': 49.5832, 'province': 'گیلان'},
    'بوشهر': {'lat': 28.9684, 'lon': 50.8385, 'province': 'بوشهر'},
    'ساری': {'lat': 36.5633, 'lon': 53.0601, 'province': 'مازندران'},
    'بابل': {'lat': 36.5510, 'lon': 52.6783, 'province': 'مازندران'},
    'گرگان': {'lat': 36.8427, 'lon': 54.4364, 'province': 'گلستان'},
    'بیرجند': {'lat': 32.8663, 'lon': 59.2211, 'province': 'خراسان جنوبی'},
    'بجنورد': {'lat': 37.4747, 'lon': 57.3167, 'province': 'خراسان شمالی'},
    'یاسوج': {'lat': 30.6682, 'lon': 51.5881, 'province': 'کهگیلویه و بویراحمد'},
    'ایلام': {'lat': 33.6374, 'lon': 46.4227, 'province': 'ایلام'},
    'شهرکرد': {'lat': 32.3256, 'lon': 50.8644, 'province': 'چهارمحال و بختیاری'},
    'خرم‌آباد': {'lat': 33.4878, 'lon': 48.3553, 'province': 'لرستان'},
    'دزفول': {'lat': 32.3895, 'lon': 48.4065, 'province': 'خوزستان'},
    'آبادان': {'lat': 30.3392, 'lon': 48.3043, 'province': 'خوزستان'},
    'خرمشهر': {'lat': 30.4416, 'lon': 48.1764, 'province': 'خوزستان'},
    'نجف‌آباد': {'lat': 32.6344, 'lon': 51.3667, 'province': 'اصفهان'},
    'کاشان': {'lat': 33.9831, 'lon': 51.4364, 'province': 'اصفهان'},
    'قزوین': {'lat': 36.2688, 'lon': 50.0041, 'province': 'قزوین'},
    'سمنان': {'lat': 35.5769, 'lon': 53.3915, 'province': 'سمنان'},
    'شاهرود': {'lat': 36.4183, 'lon': 54.9763, 'province': 'سمنان'},
    'گنبد کاووس': {'lat': 37.2500, 'lon': 55.1667, 'province': 'گلستان'},
    'کاشمر': {'lat': 35.2381, 'lon': 58.4651, 'province': 'خراسان رضوی'},
    'سبزوار': {'lat': 36.2126, 'lon': 57.6819, 'province': 'خراسان رضوی'},
    'نیشابور': {'lat': 36.2139, 'lon': 58.7956, 'province': 'خراسان رضوی'}
}

def persian_digits(text):
    """تبدیل اعداد انگلیسی به فارسی"""
    english_digits = '0123456789'
    persian_digits_map = '۰۱۲۳۴۵۶۷۸۹'
    
    for i, digit in enumerate(english_digits):
        text = str(text).replace(digit, persian_digits_map[i])
    
    return text

def get_weather_emoji(weather_main, weather_description):
    """دریافت ایموجی آب و هوا بر اساس وضعیت"""
    weather_emojis = {
        'clear': '☀️',
        'clouds': '☁️',
        'rain': '🌧️',
        'drizzle': '🌦️',
        'thunderstorm': '⛈️',
        'snow': '🌨️',
        'mist': '🌫️',
        'fog': '🌫️',
        'haze': '🌫️',
        'dust': '🌪️',
        'sand': '🌪️',
        'smoke': '💨'
    }
    
    return weather_emojis.get(weather_main.lower(), '🌤️')

def get_persian_weather_description(weather_description):
    """تبدیل توضیحات آب و هوا به فارسی"""
    weather_translations = {
        'clear sky': 'آسمان صاف',
        'few clouds': 'کمی ابری',
        'scattered clouds': 'ابرهای پراکنده',
        'broken clouds': 'ابری',
        'overcast clouds': 'کاملاً ابری',
        'light rain': 'بارش خفیف',
        'moderate rain': 'بارش متوسط',
        'heavy intensity rain': 'بارش شدید',
        'very heavy rain': 'بارش خیلی شدید',
        'extreme rain': 'بارش فوق‌العاده شدید',
        'freezing rain': 'بارش یخی',
        'light intensity shower rain': 'رگبار خفیف',
        'shower rain': 'رگبار',
        'heavy intensity shower rain': 'رگبار شدید',
        'ragged shower rain': 'رگبار نامنظم',
        'light snow': 'برف خفیف',
        'snow': 'برف',
        'heavy snow': 'برف شدید',
        'sleet': 'برف و باران',
        'light shower sleet': 'رگبار خفیف برف و باران',
        'shower sleet': 'رگبار برف و باران',
        'light rain and snow': 'باران و برف خفیف',
        'rain and snow': 'باران و برف',
        'light shower snow': 'رگبار برف خفیف',
        'shower snow': 'رگبار برف',
        'heavy shower snow': 'رگبار برف شدید',
        'mist': 'مه خفیف',
        'smoke': 'دود',
        'haze': 'مه',
        'sand/dust whirls': 'گردباد شن و خاک',
        'fog': 'مه غلیظ',
        'sand': 'طوفان شن',
        'dust': 'طوفان گرد و غبار',
        'volcanic ash': 'خاکستر آتشفشانی',
        'squalls': 'طوفان',
        'tornado': 'گردباد',
        'thunderstorm with light rain': 'رعد و برق با بارش خفیف',
        'thunderstorm with rain': 'رعد و برق با بارش',
        'thunderstorm with heavy rain': 'رعد و برق با بارش شدید',
        'light thunderstorm': 'رعد و برق خفیف',
        'thunderstorm': 'رعد و برق',
        'heavy thunderstorm': 'رعد و برق شدید',
        'ragged thunderstorm': 'رعد و برق نامنظم',
        'thunderstorm with light drizzle': 'رعد و برق با نم‌نم باران',
        'thunderstorm with drizzle': 'رعد و برق با نم‌نم باران',
        'thunderstorm with heavy drizzle': 'رعد و برق با نم‌نم باران شدید'
    }
    
    return weather_translations.get(weather_description.lower(), weather_description)

def get_wind_direction(degrees):
    """تبدیل درجه باد به جهت فارسی"""
    directions = [
        'شمال', 'شمال شرقی', 'شرق', 'جنوب شرقی',
        'جنوب', 'جنوب غربی', 'غرب', 'شمال غربی'
    ]
    
    index = round(degrees / 45) % 8
    return directions[index]

def get_aqi_status(aqi):
    """دریافت وضعیت کیفیت هوا"""
    if aqi <= 50:
        return "🟢 سالم"
    elif aqi <= 100:
        return "🟡 متوسط"
    elif aqi <= 150:
        return "🟠 برای گروه‌های حساس ناسالم است"
    elif aqi <= 200:
        return "🔴 ناسالم"
    elif aqi <= 300:
        return "🟣 خیلی ناسالم"
    else:
        return "🔴 خطرناک"

async def get_weather_data(city_name):
    """دریافت اطلاعات آب و هوا از API"""
    try:
        # اگر کلید API دمو باشد، داده‌های نمونه برگردان
        if WEATHER_API_KEY == "demo_key":
            return get_demo_weather_data(city_name)
        
        # دریافت مختصات شهر
        if city_name not in IRAN_CITIES:
            return None
        
        city_info = IRAN_CITIES[city_name]
        lat, lon = city_info['lat'], city_info['lon']
        
        # دریافت آب و هوای فعلی
        current_url = f"{WEATHER_BASE_URL}/weather"
        current_params = {
            'lat': lat,
            'lon': lon,
            'appid': WEATHER_API_KEY,
            'units': 'metric',
            'lang': 'fa'
        }
        
        current_response = requests.get(current_url, params=current_params, timeout=10)
        if current_response.status_code != 200:
            return None
        
        current_data = current_response.json()
        
        # دریافت پیش‌بینی ۵ روزه
        forecast_url = f"{WEATHER_BASE_URL}/forecast"
        forecast_params = {
            'lat': lat,
            'lon': lon,
            'appid': WEATHER_API_KEY,
            'units': 'metric',
            'lang': 'fa'
        }
        
        forecast_response = requests.get(forecast_url, params=forecast_params, timeout=10)
        forecast_data = forecast_response.json() if forecast_response.status_code == 200 else None
        
        # دریافت کیفیت هوا
        aqi_url = f"{WEATHER_BASE_URL}/air_pollution"
        aqi_params = {
            'lat': lat,
            'lon': lon,
            'appid': WEATHER_API_KEY
        }
        
        aqi_response = requests.get(aqi_url, params=aqi_params, timeout=10)
        aqi_data = aqi_response.json() if aqi_response.status_code == 200 else None
        
        return {
            'current': current_data,
            'forecast': forecast_data,
            'aqi': aqi_data,
            'city_info': city_info
        }
        
    except Exception as e:
        logger.error(f"Error fetching weather data: {str(e)}")
        return None

def get_demo_weather_data(city_name):
    """داده‌های نمونه برای تست"""
    import time
    import random
    
    if city_name not in IRAN_CITIES:
        return None
    
    city_info = IRAN_CITIES[city_name]
    
    # داده‌های نمونه واقع‌گرایانه
    base_temp = random.uniform(15, 35)  # دمای پایه
    
    current_data = {
        'main': {
            'temp': base_temp,
            'feels_like': base_temp + random.uniform(-3, 5),
            'temp_max': base_temp + random.uniform(2, 8),
            'temp_min': base_temp - random.uniform(2, 8),
            'humidity': random.randint(20, 90),
            'pressure': random.randint(990, 1020)
        },
        'weather': [{
            'main': random.choice(['Clear', 'Clouds', 'Rain', 'Mist']),
            'description': random.choice(['clear sky', 'few clouds', 'scattered clouds', 'light rain', 'mist'])
        }],
        'wind': {
            'speed': random.uniform(1, 10),
            'deg': random.randint(0, 360)
        },
        'clouds': {
            'all': random.randint(0, 100)
        },
        'visibility': random.randint(5000, 10000)
    }
    
    # پیش‌بینی نمونه
    forecast_data = {
        'list': []
    }
    
    for i in range(16):
        forecast_data['list'].append({
            'dt': int(time.time()) + (i * 3 * 3600),  # هر ۳ ساعت
            'main': {
                'temp': base_temp + random.uniform(-5, 5)
            },
            'weather': [{
                'main': random.choice(['Clear', 'Clouds', 'Rain']),
                'description': random.choice(['clear sky', 'few clouds', 'light rain'])
            }]
        })
    
    # کیفیت هوای نمونه
    aqi_data = {
        'list': [{
            'main': {
                'aqi': random.randint(1, 5)
            },
            'components': {
                'co': random.uniform(200, 800),
                'pm2_5': random.uniform(10, 100)
            }
        }]
    }
    
    return {
        'current': current_data,
        'forecast': forecast_data,
        'aqi': aqi_data,
        'city_info': city_info
    }

def format_weather_message(weather_data, city_name):
    """فرمت کردن پیام آب و هوا"""
    try:
        current = weather_data['current']
        forecast = weather_data.get('forecast')
        aqi = weather_data.get('aqi')
        city_info = weather_data['city_info']
        
        # تاریخ و زمان فعلی
        now = datetime.now()
        persian_date = jdatetime.datetime.fromgregorian(datetime=now)
        weekdays = ['دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه', 'شنبه', 'یکشنبه']
        weekday = weekdays[persian_date.weekday()]
        
        # اطلاعات اصلی
        temp = current['main']['temp']
        feels_like = current['main']['feels_like']
        temp_max = current['main']['temp_max']
        temp_min = current['main']['temp_min']
        humidity = current['main']['humidity']
        pressure = current['main']['pressure']
        visibility = current.get('visibility', 0) / 1000  # تبدیل به کیلومتر
        
        # باد
        wind_speed = current.get('wind', {}).get('speed', 0) * 3.6  # تبدیل m/s به km/h
        wind_deg = current.get('wind', {}).get('deg', 0)
        wind_direction = get_wind_direction(wind_deg)
        
        # آب و هوا
        weather_main = current['weather'][0]['main']
        weather_desc = get_persian_weather_description(current['weather'][0]['description'])
        weather_emoji = get_weather_emoji(weather_main, weather_desc)
        clouds = current.get('clouds', {}).get('all', 0)
        
        # شروع پیام
        message = f"◄ وضعیت هوای {city_name} :\n\n"
        message += f"• تاریخ : {weekday} {persian_digits(persian_date.strftime('%d %B %Y'))}\n"
        message += f"• ساعت : {persian_digits(now.strftime('%H:%M'))}\n\n"
        
        # دما
        message += "وضعیت دما\n"
        message += f"◂ دمای کنونی: {persian_digits(f'{temp:.1f}')} سانتی گراد\n"
        message += f"◂ دمای احساسی: {persian_digits(f'{feels_like:.1f}')} سانتی گراد\n"
        message += f"◂ حداکثر دما: {persian_digits(f'{temp_max:.1f}')} سانتی گراد\n"
        message += f"◂ حداقل دما: {persian_digits(f'{temp_min:.1f}')} سانتی گراد\n\n"
        
        # وضعیت جوی
        message += "وضعیت جَوی\n"
        message += f"◂ حالت فعلی: {weather_desc} {weather_emoji}\n"
        message += f"◂ میزان ابر: {persian_digits(clouds)} درصد\n"
        message += f"◂ رطوبت: {persian_digits(humidity)} درصد\n"
        message += f"◂ فشار هوا: {persian_digits(f'{pressure:.1f}')} میلیبار\n"
        message += f"◂ سرعت باد: {persian_digits(f'{wind_speed:.1f}')} کیلومتر بر ساعت\n"
        message += f"◂ جهت باد: {wind_direction} ({persian_digits(wind_deg)} درجه)\n"
        message += f"◂ محدوده دید: {persian_digits(f'{visibility:.1f}')} کیلومتر\n\n"
        
        # کیفیت هوا
        if aqi and 'list' in aqi and len(aqi['list']) > 0:
            aqi_main = aqi['list'][0]['main']['aqi']
            components = aqi['list'][0]['components']
            
            message += "کیفیت هوا\n"
            co_value = persian_digits(f"{components.get('co', 0):.2f}")
            pm25_value = persian_digits(f"{components.get('pm2_5', 0):.3f}")
            message += f"◂ مونوکسید کربن: {co_value}\n"
            message += f"◂ ذرات معلق: {pm25_value}\n"
            message += f"◂ شاخص کیفیت هوا: {get_aqi_status(aqi_main * 50)}\n\n"
        
        # موقعیت جغرافیایی
        message += "وضعیت مکانی\n"
        province_name = city_info['province']
        lon_value = persian_digits(f"{city_info['lon']:.4f}")
        lat_value = persian_digits(f"{city_info['lat']:.4f}")
        message += f"◂ موقعیت: {province_name}-ایران\n"
        message += f"◂ طول جغرافیایی: {lon_value}\n"
        message += f"◂ عرض جغرافیایی: {lat_value}\n\n"
        
        # پیش‌بینی
        if forecast and 'list' in forecast:
            message += "پیش بینی روزهای بعد\n"
            
            # گروه‌بندی پیش‌بینی‌ها بر اساس روز
            daily_forecasts = {}
            for item in forecast['list'][:16]:  # ۲ روز آینده
                dt = datetime.fromtimestamp(item['dt'])
                date_key = dt.strftime('%Y-%m-%d')
                
                if date_key not in daily_forecasts:
                    daily_forecasts[date_key] = {
                        'temps': [],
                        'weather': item['weather'][0],
                        'date': dt
                    }
                
                daily_forecasts[date_key]['temps'].append(item['main']['temp'])
            
            days_names = ['فردا', 'پس فردا']
            for i, (date_key, day_data) in enumerate(list(daily_forecasts.items())[1:3]):
                if i < len(days_names):
                    day_name = days_names[i]
                    temps = day_data['temps']
                    max_temp = max(temps)
                    min_temp = min(temps)
                    weather_desc = get_persian_weather_description(day_data['weather']['description'])
                    weather_emoji = get_weather_emoji(day_data['weather']['main'], weather_desc)
                    
                    message += f"◂ {day_name}:\n"
                    message += f"    ◂ دمای حداکثر: {persian_digits(f'{max_temp:.1f}')} سانتی گراد\n"
                    message += f"    ◂ دمای حداقل: {persian_digits(f'{min_temp:.1f}')} سانتی گراد\n"
                    message += f"    ◂ حالت: {weather_desc} {weather_emoji}\n"
        
        return message
        
    except Exception as e:
        logger.error(f"Error formatting weather message: {str(e)}")
        return f"خطا در پردازش اطلاعات آب و هوای {city_name}"

async def weather_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """هندلر اصلی آب و هوا"""
    try:
        # دریافت نام شهر از ورودی
        city_name = None
        
        # اگر از دستور فارسی آمده
        if hasattr(context, 'args') and context.args:
            city_name = ' '.join(context.args)
        else:
            # اگر از دستور انگلیسی آمده
            if len(context.args) > 0:
                city_name = ' '.join(context.args)
        
        # اگر نام شهر وارد نشده، لیست شهرها را نمایش بده
        if not city_name:
            keyboard = []
            cities_list = list(IRAN_CITIES.keys())
            
            # تقسیم شهرها به ردیف‌های ۳ تایی
            for i in range(0, len(cities_list), 3):
                row = []
                for j in range(3):
                    if i + j < len(cities_list):
                        city = cities_list[i + j]
                        row.append(InlineKeyboardButton(city, callback_data=f'weather_{city}'))
                keyboard.append(row)
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.message.reply_text(
                "🌤️ <b>انتخاب شهر برای آب و هوا</b>\n\n"
                "📋 لطفاً شهر مورد نظر خود را انتخاب کنید:\n"
                "یا می‌توانید نام شهر را بنویسید:\n"
                "<code>آب و هوا تهران</code>",
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
            return
        
        # بررسی وجود شهر در لیست
        if city_name not in IRAN_CITIES:
            # پیشنهاد شهرهای مشابه
            suggestions = [city for city in IRAN_CITIES.keys() if city_name in city]
            
            if suggestions:
                keyboard = []
                for city in suggestions[:9]:  # حداکثر ۹ پیشنهاد
                    keyboard.append([InlineKeyboardButton(city, callback_data=f'weather_{city}')])
                
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                await update.message.reply_text(
                    f"❌ شهر '{city_name}' یافت نشد.\n\n"
                    "💡 آیا منظورتان یکی از این شهرها بود؟",
                    reply_markup=reply_markup
                )
            else:
                await update.message.reply_text(
                    f"❌ شهر '{city_name}' در لیست شهرهای ایران یافت نشد.\n\n"
                    "💡 از دستور 'آب و هوا' بدون نام شهر استفاده کنید تا لیست شهرها را ببینید."
                )
            return
        
        # ارسال پیام در حال بارگذاری
        loading_msg = await update.message.reply_text(
            f"🌤️ در حال دریافت اطلاعات آب و هوای {city_name}...\n"
            "⏳ لطفاً صبر کنید..."
        )
        
        # دریافت اطلاعات آب و هوا
        weather_data = await get_weather_data(city_name)
        
        if not weather_data:
            await loading_msg.edit_text(
                f"❌ متأسفانه نتوانستیم اطلاعات آب و هوای {city_name} را دریافت کنیم.\n"
                "🔄 لطفاً دوباره تلاش کنید."
            )
            return
        
        # فرمت کردن و ارسال پیام آب و هوا
        weather_message = format_weather_message(weather_data, city_name)
        
        await loading_msg.edit_text(
            weather_message,
            parse_mode='HTML' if '<' in weather_message else None
        )
        
        logger.info(f"Weather information sent for {city_name} to user {update.effective_user.id}")
        
    except Exception as e:
        logger.error(f"Error in weather_handler: {str(e)}")
        await update.message.reply_text(
            "❌ خطایی در دریافت اطلاعات آب و هوا رخ داد.\n"
            "🔄 لطفاً دوباره تلاش کنید."
        )

async def weather_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """هندلر callback برای انتخاب شهر"""
    try:
        query = update.callback_query
        await query.answer()
        
        # استخراج نام شهر از callback data
        city_name = query.data.replace('weather_', '')
        
        if city_name not in IRAN_CITIES:
            await query.message.edit_text("❌ شهر انتخاب شده معتبر نیست.")
            return
        
        # ارسال پیام در حال بارگذاری
        await query.message.edit_text(
            f"🌤️ در حال دریافت اطلاعات آب و هوای {city_name}...\n"
            "⏳ لطفاً صبر کنید..."
        )
        
        # دریافت اطلاعات آب و هوا
        weather_data = await get_weather_data(city_name)
        
        if not weather_data:
            await query.message.edit_text(
                f"❌ متأسفانه نتوانستیم اطلاعات آب و هوای {city_name} را دریافت کنیم.\n"
                "🔄 لطفاً دوباره تلاش کنید."
            )
            return
        
        # فرمت کردن و ارسال پیام آب و هوا
        weather_message = format_weather_message(weather_data, city_name)
        
        await query.message.edit_text(weather_message)
        
        logger.info(f"Weather information sent for {city_name} via callback to user {update.effective_user.id}")
        
    except Exception as e:
        logger.error(f"Error in weather_callback_handler: {str(e)}")
        await query.message.edit_text(
            "❌ خطایی در دریافت اطلاعات آب و هوا رخ داد.\n"
            "🔄 لطفاً دوباره تلاش کنید."
        )