
import logging
import random
import re
from dataclasses import dataclass, field
from types import SimpleNamespace
from typing import Dict, List, Optional, Tuple

from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
from telegram.constants import ParseMode
from telegram import InlineKeyboardMarkup, InlineKeyboardButton

from config import ADMIN_ID
from database.database import Database

logger = logging.getLogger(__name__)
db = Database("group_manager.db")

ROLE_DEFINITIONS: Dict[str, Dict] = {
    "شاه": {"permissions": {"all"}},
    "رئیس جمهور": {"permissions": {"moderate", "broadcast", "games", "view_roles", "admin_panel"}},
    "نخست وزیر": {"permissions": {"moderate", "games", "view_roles", "admin_panel"}},
    "مشاور نخست وزیر": {"permissions": {"games", "view_roles"}},
    "دست راست شاه": {"permissions": {"moderate", "games", "set_roles", "view_roles", "admin_panel"}},
    "دست چپ شاه": {"permissions": {"moderate", "games", "view_roles", "admin_panel"}},
    "مقام ویژه": {"permissions": {"moderate", "games", "view_roles"}},
    "بالا مقام": {"permissions": {"moderate", "games", "set_roles", "broadcast", "view_roles", "admin_panel"}},
    "رئیس قوه قضائیه": {"permissions": {"moderate", "view_roles", "admin_panel"}},
    "رئیس قوه مقننه": {"permissions": {"games", "view_roles", "moderate", "admin_panel"}},
    "رئیس قوه مجریه": {"permissions": {"broadcast", "games", "view_roles", "admin_panel"}},
}

SUIT_ALIASES = {
    "s": "S", "spade": "S", "spades": "S", "p": "S", "پیک": "S", "♠": "S",
    "h": "H", "heart": "H", "hearts": "H", "d": "H", "دل": "H", "♥": "H",
    "c": "C", "club": "C", "clubs": "C", "g": "C", "گشنیز": "C", "♣": "C",
    "d1": "D", "diamonds": "D", "diamond": "D", "خشت": "D", "♦": "D", "k": "D",
}
SUIT_NAMES = {"S": "پیک", "H": "دل", "C": "گشنیز", "D": "خشت"}
SUIT_EMOJI = {"S": "♠", "H": "♥", "C": "♣", "D": "♦"}
RANK_ORDER = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]
CARD_REGEX = re.compile(r"^\s*(10|[2-9JQKAjqa])\s*([SHCDshcd♠♥♦♣]|پیک|دل|گشنیز|خشت|spade|spades|heart|hearts|club|clubs|diamond|diamonds)\s*$")

SEVEN_SESSIONS: Dict[int, "SevenGameSession"] = {}
HOKM_SESSIONS: Dict[int, "HokmGameSession"] = {}


def _games_panel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🃏 هفت خبیث 2 نفره", callback_data="games_seven_2"),
            InlineKeyboardButton("🃏 هفت خبیث 4 نفره", callback_data="games_seven_4"),
        ],
        [
            InlineKeyboardButton("🂠 حکم 2 نفره", callback_data="games_hokm_2"),
            InlineKeyboardButton("🂠 حکم 4 نفره", callback_data="games_hokm_4"),
        ],
        [
            InlineKeyboardButton("📊 وضعیت هفت خبیث", callback_data="games_seven_status"),
            InlineKeyboardButton("📊 وضعیت حکم", callback_data="games_hokm_status"),
        ],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="games_back")],
    ])


async def _show_games_panel_message(query_or_update, context: ContextTypes.DEFAULT_TYPE, edit: bool = False):
    text = """🎮 <b>پنل بازی‌ها</b>

از اینجا می‌توانی بازی بسازی، بپیوندی یا وضعیت را ببینی.

کامندها:
• /seven 2 یا /seven 4
• /sevenjoin /sevenstart /sevenplay /sevendraw /sevenstatus
• /hokm 2 یا /hokm 4
• /hokmjoin /hokmstart /hokmchoose /hokmplay /hokmstatus"""
    if hasattr(query_or_update, "callback_query"):
        msg = query_or_update.callback_query.message
    else:
        msg = query_or_update.message
    if edit and hasattr(query_or_update, "callback_query"):
        await msg.edit_text(text, parse_mode=ParseMode.HTML, reply_markup=_games_panel_keyboard())
    else:
        await msg.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=_games_panel_keyboard())


async def games_command(update: Update, context: ContextTypes.DEFAULT_TYPE):

    if update.effective_chat.type == "private":
        await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
        return
    await _show_games_panel_message(update, context)


def _create_seven_session_from_query(query, count: str):
    chat_id = query.message.chat.id
    if chat_id in SEVEN_SESSIONS and SEVEN_SESSIONS[chat_id].started is False:
        return False, "یک بازی هفت خبیث در حال ساخت است. اول همان را شروع یا لغو کن."
    SEVEN_SESSIONS[chat_id] = SevenGameSession(chat_id=chat_id, host_id=query.from_user.id, target_players=int(count), players=[query.from_user.id])
    return True, f"""🃏 بازی هفت خبیث ساخته شد برای {count} بازیکن.
سایر بازیکن‌ها با /sevenjoin اضافه شوند، سپس میزبان با /sevenstart شروع کند."""


def _create_hokm_session_from_query(query, count: str):
    chat_id = query.message.chat.id
    if chat_id in HOKM_SESSIONS and HOKM_SESSIONS[chat_id].started is False:
        return False, "یک بازی حکم در حال ساخت است. اول همان را شروع یا لغو کن."
    HOKM_SESSIONS[chat_id] = HokmGameSession(chat_id=chat_id, host_id=query.from_user.id, target_players=int(count), players=[query.from_user.id], trick_wins={})
    return True, f"""🂠 بازی حکم ساخته شد برای {count} بازیکن.
بازیکن‌ها با /hokmjoin اضافه شوند و سپس میزبان با /hokmstart شروع کند."""


async def games_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        query = update.callback_query
        await query.answer()
        data = query.data

        if data == "games_back":
            await _show_games_panel_message(update, context, edit=True)
            return

        if data.startswith("games_seven_"):
            tail = data.rsplit("_", 1)[-1]
            if tail in {"2", "4"}:
                ok, msg = _create_seven_session_from_query(query, tail)
                await query.message.edit_text(msg, reply_markup=_games_panel_keyboard() if not ok else None)
                return
            if data == "games_seven_status":
                session = _seven_session(query.message.chat.id)
                if not session:
                    await query.message.edit_text("بازی هفت خبیث فعالی وجود ندارد.", reply_markup=_games_panel_keyboard())
                    return
                await query.message.reply_text(
                    f"🃏 وضعیت هفت خبیث\n"
                    f"بازیکن‌ها: {len(session.players)}/{session.target_players}\n"
                    f"کارت رو: {_card_to_text(session.current_top()) if session.current_top() else 'ندارد'}\n"
                    f"رنگ: {SUIT_NAMES.get(session.current_suit, session.current_suit or '-')}\n"
                    f"جریمه معوق: {session.pending_draw}\n"
                )
                return

        if data.startswith("games_hokm_"):
            tail = data.rsplit("_", 1)[-1]
            if tail in {"2", "4"}:
                ok, msg = _create_hokm_session_from_query(query, tail)
                await query.message.edit_text(msg, reply_markup=_games_panel_keyboard() if not ok else None)
                return
            if data == "games_hokm_status":
                session = _hokm_session(query.message.chat.id)
                if not session:
                    await query.message.edit_text("بازی حکم فعالی وجود ندارد.", reply_markup=_games_panel_keyboard())
                    return
                await _hokm_show_status(update, context, session)
                return

    except Exception as e:
        logger.error("Error in games_callback_handler: %s", e)
        try:
            await query.message.reply_text("❌ خطایی در پردازش بازی رخ داد.")
        except Exception:
            pass


def _norm_suit(suit: str) -> Optional[str]:
    if not suit:
        return None
    return SUIT_ALIASES.get(suit.strip().lower()) or SUIT_ALIASES.get(suit.strip())


def _parse_card(card_text: str) -> Optional[Tuple[str, str]]:
    if not card_text:
        return None
    text = card_text.strip().replace("-", "").replace("_", "")
    # formats like 7H / 10S / j دل
    m = CARD_REGEX.match(text)
    if not m:
        # try split by space or no space with suit symbol
        text2 = text.upper().replace("♠", "S").replace("♥", "H").replace("♦", "D").replace("♣", "C")
        for suit_key, mapped in SUIT_ALIASES.items():
            if len(suit_key) == 1 and text2.endswith(suit_key.upper()):
                rank = text2[:-1]
                if rank in [r.upper() for r in RANK_ORDER]:
                    return rank.upper(), mapped
        parts = text.split()
        if len(parts) == 2:
            rank = parts[0].upper()
            suit = _norm_suit(parts[1])
            if rank == "J" or rank == "Q" or rank == "K" or rank == "A" or rank.isdigit() or rank == "10":
                if suit:
                    return rank, suit
        return None
    rank = m.group(1).upper()
    if rank == "J":
        rank = "J"
    if rank == "Q":
        rank = "Q"
    if rank == "K":
        rank = "K"
    if rank == "A":
        rank = "A"
    suit = _norm_suit(m.group(2))
    if suit:
        return rank, suit
    return None


def _card_to_text(card: Tuple[str, str]) -> str:
    rank, suit = card
    return f"{rank}{SUIT_EMOJI.get(suit, suit)}"


def _make_deck() -> List[Tuple[str, str]]:
    deck = [(rank, suit) for suit in ["S", "H", "C", "D"] for rank in RANK_ORDER]
    random.shuffle(deck)
    return deck


def _draw_non_special_card(deck: List[Tuple[str, str]]) -> Tuple[str, str]:
    special = {"7", "8", "10", "J", "A"}
    for idx, card in enumerate(deck):
        if card[0] not in special:
            return deck.pop(idx)
    return deck.pop()


def _format_hand(hand: List[Tuple[str, str]]) -> str:
    ordered = sorted(hand, key=lambda c: (RANK_ORDER.index(c[0]), c[1]))
    return " | ".join(_card_to_text(c) for c in ordered) if ordered else "بدون کارت"


def _role_permissions(role_name: str) -> set:
    if not role_name:
        return set()
    info = ROLE_DEFINITIONS.get(role_name.strip())
    if not info:
        return set()
    perms = set(info.get("permissions", set()))
    if "all" in perms:
        return {"all", "set_roles", "moderate", "broadcast", "games", "view_roles", "premium", "admin_panel"}
    return perms


async def user_has_permission(update: Update, context: ContextTypes.DEFAULT_TYPE, permission: str) -> bool:
    """Allow bot actions for Telegram admins and bot-side royal roles."""
    try:
        if not update.effective_user or not update.effective_chat:
            return False

        user_id = update.effective_user.id
        if user_id == ADMIN_ID:
            return True

        if update.effective_chat.type == "private":
            return False

        group_id = update.effective_chat.id

        try:
            member = await context.bot.get_chat_member(group_id, user_id)
            if member.status in ("creator", "administrator"):
                return True
        except Exception:
            pass

        role_name = db.get_royal_role(group_id, user_id)
        if not role_name:
            return False

        perms = _role_permissions(role_name)
        return permission in perms or "all" in perms

    except Exception as e:
        logger.error("Permission check error: %s", e)
        return False


async def handle_royal_text_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Handle Persian royal commands written as text."""
    try:
        if not update.message or not update.message.text or not update.effective_chat:
            return False

        if update.effective_chat.type == "private":
            return False

        text = update.message.text.strip()

        # Royal ping phrase
        if text == "ربات سلطنتی":
            if update.effective_user and update.effective_user.id == ADMIN_ID:
                await update.message.reply_text("بگوشم اعلیحضرت")
                return True
            return True  # handled silently for everyone else

        # Set role command
        if text.startswith("تنظیم "):
            if update.effective_user.id != ADMIN_ID:
                await update.message.reply_text("فقط آیدی عددی 7363381443 می‌تواند مقام تنظیم کند.")
                return True

            if not update.message.reply_to_message or not update.message.reply_to_message.from_user:
                await update.message.reply_text("این دستور باید روی پیام کاربر و با ریپلای ارسال شود.")
                return True

            role_name = text.removeprefix("تنظیم ").strip()
            if not role_name:
                await update.message.reply_text("نام مقام را بعد از تنظیم بنویس.")
                return True

            if role_name not in ROLE_DEFINITIONS:
                roles = "، ".join(ROLE_DEFINITIONS.keys())
                await update.message.reply_text(
                    "این مقام تعریف نشده است.\n"
                    f"مقام‌های معتبر: {roles}"
                )
                return True

            target = update.message.reply_to_message.from_user
            group_id = update.effective_chat.id
            db.set_royal_role(group_id, target.id, role_name, update.effective_user.id)
            perms = "، ".join(sorted(_role_permissions(role_name))) or "بدون دسترسی"
            await update.message.reply_text(
                f"👑 مقام «{role_name}» برای {target.first_name} ثبت شد.\n"
                f"🔐 دسترسی‌ها: {perms}"
            )
            return True

        if text in {"حذف مقام", "برداشتن مقام"}:
            if update.effective_user.id != ADMIN_ID:
                await update.message.reply_text("فقط آیدی عددی 7363381443 می‌تواند مقام حذف کند.")
                return True

            if not update.message.reply_to_message or not update.message.reply_to_message.from_user:
                await update.message.reply_text("برای حذف مقام باید روی پیام کاربر ریپلای کنی.")
                return True

            target = update.message.reply_to_message.from_user
            group_id = update.effective_chat.id
            old_role = db.get_royal_role(group_id, target.id)
            db.remove_royal_role(group_id, target.id)
            if old_role:
                await update.message.reply_text(f"مقام «{old_role}» از {target.first_name} حذف شد.")
            else:
                await update.message.reply_text("این کاربر مقامی ثبت‌شده نداشت.")
            return True

        if text in {"مقام من", "مقام من؟", "role me"}:
            role_name = db.get_royal_role(update.effective_chat.id, update.effective_user.id)
            if role_name:
                perms = "، ".join(sorted(_role_permissions(role_name))) or "بدون دسترسی"
                await update.message.reply_text(
                    f"مقام شما: {role_name}\n"
                    f"دسترسی‌ها: {perms}"
                )
            else:
                await update.message.reply_text("برای شما هیچ مقامی ثبت نشده است.")
            return True

        if text in {"مقام‌ها", "مقام ها", "لیست مقام ها", "لیست مقام‌ها"}:
            if not await user_has_permission(update, context, "view_roles"):
                await update.message.reply_text("برای دیدن فهرست مقام‌ها دسترسی لازم را ندارید.")
                return True

            roles = db.list_royal_roles(update.effective_chat.id)
            if not roles:
                await update.message.reply_text("هنوز هیچ مقامی ثبت نشده است.")
                return True

            lines = ["📜 فهرست مقام‌ها:"]
            for item in roles:
                role = item["role_name"]
                user_id = item["user_id"]
                name = item.get("first_name") or "نامشخص"
                lines.append(f"• {role} — {name} (`{user_id}`)")
            await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)
            return True

        if text.startswith("حذف مقام از "):
            if update.effective_user.id != ADMIN_ID:
                await update.message.reply_text("فقط آیدی عددی 7363381443 می‌تواند مقام حذف کند.")
                return True

            # no-op text form for now
            await update.message.reply_text("برای حذف مقام از ریپلای و ارسال «حذف مقام» استفاده کن.")
            return True

        return False
    except Exception as e:
        logger.error("Royal text handling error: %s", e)
        return False


async def royal_ping_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user and update.effective_user.id == ADMIN_ID:
        await update.message.reply_text("بگوشم اعلیحضرت")


async def royal_roles_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type == "private":
        await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
        return
    if not await user_has_permission(update, context, "view_roles"):
        await update.message.reply_text("برای دیدن فهرست مقام‌ها دسترسی لازم را ندارید.")
        return
    roles = db.list_royal_roles(update.effective_chat.id)
    if not roles:
        await update.message.reply_text("هنوز هیچ مقامی ثبت نشده است.")
        return
    lines = ["📜 فهرست مقام‌ها:"]
    for item in roles:
        lines.append(f"• {item['role_name']} — {item.get('first_name') or 'نامشخص'} (`{item['user_id']}`)")
    await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)


async def royal_set_role_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text("فقط آیدی عددی 7363381443 می‌تواند مقام تنظیم کند.")
        return
    if update.effective_chat.type == "private":
        await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
        return
    if not update.message.reply_to_message:
        await update.message.reply_text("این دستور باید با ریپلای ارسال شود.")
        return
    role_name = " ".join(context.args).strip()
    if not role_name:
        await update.message.reply_text(f"نام مقام را بنویس. نمونه: /setrole شاه")
        return
    if role_name not in ROLE_DEFINITIONS:
        await update.message.reply_text("مقام نامعتبر است.")
        return
    target = update.message.reply_to_message.from_user
    db.set_royal_role(update.effective_chat.id, target.id, role_name, update.effective_user.id)
    await update.message.reply_text(f"مقام «{role_name}» برای {target.first_name} ثبت شد.")


def _team_for_index(index: int) -> int:
    return index % 2


@dataclass
class SevenGameSession:
    chat_id: int
    host_id: int
    target_players: int
    players: List[int] = field(default_factory=list)
    started: bool = False
    deck: List[Tuple[str, str]] = field(default_factory=list)
    hands: Dict[int, List[Tuple[str, str]]] = field(default_factory=dict)
    discard_pile: List[Tuple[str, str]] = field(default_factory=list)
    current_index: int = 0
    direction: int = 1
    pending_draw: int = 0
    pending_rank: Optional[str] = None
    current_suit: Optional[str] = None
    skip_next: bool = False
    winner_id: Optional[int] = None

    def player_turn(self) -> int:
        return self.players[self.current_index % len(self.players)]

    def next_index(self, steps: int = 1):
        self.current_index = (self.current_index + (steps * self.direction)) % len(self.players)

    def current_top(self) -> Optional[Tuple[str, str]]:
        return self.discard_pile[-1] if self.discard_pile else None


@dataclass
class HokmGameSession:
    chat_id: int
    host_id: int
    target_players: int
    players: List[int] = field(default_factory=list)
    started: bool = False
    deck: List[Tuple[str, str]] = field(default_factory=list)
    hands: Dict[int, List[Tuple[str, str]]] = field(default_factory=dict)
    trump_suit: Optional[str] = None
    current_lead_index: int = 0
    current_turn_index: int = 0
    current_trick: List[Tuple[int, Tuple[str, str]]] = field(default_factory=list)
    trick_wins: Dict[int, int] = field(default_factory=dict)
    phase: str = "waiting_trump"
    winner_team: Optional[int] = None

    def turn_player(self) -> int:
        return self.players[self.current_turn_index % len(self.players)]

    def team_for(self, player_index: int) -> int:
        if self.target_players == 4:
            return player_index % 2
        return player_index


def _seven_session(chat_id: int) -> Optional[SevenGameSession]:
    return SEVEN_SESSIONS.get(chat_id)


def _hokm_session(chat_id: int) -> Optional[HokmGameSession]:
    return HOKM_SESSIONS.get(chat_id)


async def seven_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/seven <2|4> create session"""
    if update.effective_chat.type == "private":
        await update.message.reply_text("این بازی فقط در گروه‌ها قابل استفاده است.")
        return
    if not await user_has_permission(update, context, "games"):
        await update.message.reply_text("برای ساخت بازی دسترسی لازم را ندارید.")
        return
    if not context.args:
        await update.message.reply_text(
            """🃏 <b>هفت خبیث</b>

ساخت بازی:
• /seven 2
• /seven 4

پیوستن: /sevenjoin
شروع: /sevenstart
وضعیت: /sevenstatus""",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🃏 ساخت 2 نفره", callback_data="games_seven_2"),
                 InlineKeyboardButton("🃏 ساخت 4 نفره", callback_data="games_seven_4")],
                [InlineKeyboardButton("📊 وضعیت", callback_data="games_seven_status"),
                 InlineKeyboardButton("🔙 بازگشت", callback_data="games_back")],
            ])
        )
        return
    if context.args[0] not in {"2", "4"}:
        await update.message.reply_text("استفاده: /seven 2 یا /seven 4")
        return
    count = int(context.args[0])
    chat_id = update.effective_chat.id
    if chat_id in SEVEN_SESSIONS and SEVEN_SESSIONS[chat_id].started is False:
        await update.message.reply_text("یک بازی هفت خبیث در حال ساخت است. اول همان را شروع یا لغو کن.")
        return
    session = SevenGameSession(chat_id=chat_id, host_id=update.effective_user.id, target_players=count, players=[update.effective_user.id])
    SEVEN_SESSIONS[chat_id] = session
    await update.message.reply_text(
        f"🃏 بازی هفت خبیث ساخته شد برای {count} بازیکن.\n"
        f"سایر بازیکن‌ها با /sevenjoin اضافه شوند، سپس میزبان با /sevenstart شروع کند."
    )


async def seven_join_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type == "private":
        return
    session = _seven_session(update.effective_chat.id)
    if not session or session.started:
        await update.message.reply_text("بازی فعالی برای پیوستن وجود ندارد.")
        return
    if update.effective_user.id in session.players:
        await update.message.reply_text("شما قبلاً وارد بازی شده‌اید.")
        return
    if len(session.players) >= session.target_players:
        await update.message.reply_text("تعداد بازیکن‌ها کامل شده است.")
        return
    session.players.append(update.effective_user.id)
    await update.message.reply_text(f"{update.effective_user.first_name} به بازی هفت خبیث اضافه شد. ({len(session.players)}/{session.target_players})")


async def seven_start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type == "private":
        return
    session = _seven_session(update.effective_chat.id)
    if not session:
        await update.message.reply_text("بازی هفت خبیثی ساخته نشده است.")
        return
    if update.effective_user.id != session.host_id and update.effective_user.id != ADMIN_ID:
        await update.message.reply_text("فقط میزبان بازی می‌تواند آن را شروع کند.")
        return
    if len(session.players) != session.target_players:
        await update.message.reply_text(f"هنوز تعداد بازیکن‌ها کامل نیست. ({len(session.players)}/{session.target_players})")
        return

    session.deck = _make_deck()
    # deal 7 cards each
    for pid in session.players:
        session.hands[pid] = [session.deck.pop() for _ in range(7)]

    first_card = _draw_non_special_card(session.deck)
    session.discard_pile = [first_card]
    session.current_suit = first_card[1]
    session.started = True
    session.current_index = 0
    session.pending_draw = 0
    session.pending_rank = None

    await update.message.reply_text(
        "🎮 هفت خبیث شروع شد!\n"
        f"کارت رو: {_card_to_text(first_card)}\n"
        f"نوبت: {session.players[0]}"
    )
    await _seven_show_turn(update, context, session)


async def _seven_show_turn(update: Update, context: ContextTypes.DEFAULT_TYPE, session: SevenGameSession):
    pid = session.player_turn()
    hand = session.hands.get(pid, [])
    try:
        user = await context.bot.get_chat(pid)
        name = user.first_name or user.username or str(pid)
    except Exception:
        name = str(pid)
    msg = (
        f"نوبت {name} است.\n"
        f"کارت رو: {_card_to_text(session.current_top()) if session.current_top() else 'ندارد'}\n"
        f"رنگ جاری: {SUIT_NAMES.get(session.current_suit, session.current_suit or '-')}\n"
        f"کارت‌های شما: {_format_hand(hand)}\n"
        f"برای بازی: /sevenplay <کارت>\n"
        f"برای کشیدن: /sevendraw"
    )
    await context.bot.send_message(chat_id=session.chat_id, text=msg)


async def seven_draw_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type == "private":
        return
    session = _seven_session(update.effective_chat.id)
    if not session or not session.started:
        await update.message.reply_text("بازی فعال نیست.")
        return
    if update.effective_user.id != session.player_turn():
        await update.message.reply_text("الان نوبت شما نیست.")
        return
    hand = session.hands[update.effective_user.id]
    if session.pending_draw > 0:
        for _ in range(session.pending_draw):
            hand.append(session.deck.pop())
        await update.message.reply_text(f"شما {session.pending_draw} کارت کشیدید.")
        session.pending_draw = 0
        session.pending_rank = None
        _advance_seven_turn(session, skip=True)
        await _seven_check_end_or_next(update, context, session)
        return
    if not session.deck:
        await update.message.reply_text("دسته کارت خالی است.")
        return
    hand.append(session.deck.pop())
    await update.message.reply_text("یک کارت کشیدید. حالا می‌توانید اگر کارت مناسب دارید آن را بازی کنید.")
    _advance_seven_turn(session, skip=False)
    await _seven_show_turn(update, context, session)


def _advance_seven_turn(session: SevenGameSession, skip: bool = False):
    if session.skip_next:
        session.next_index(2)
        session.skip_next = False
    else:
        session.next_index(1)


async def _seven_check_end_or_next(update: Update, context: ContextTypes.DEFAULT_TYPE, session: SevenGameSession):
    current_player = session.player_turn()
    if len(session.hands[current_player]) == 0:
        session.winner_id = current_player
        await context.bot.send_message(chat_id=session.chat_id, text=f"🏆 برنده هفت خبیث: {current_player}")
        SEVEN_SESSIONS.pop(session.chat_id, None)
        return
    await _seven_show_turn(update, context, session)


async def seven_play_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type == "private":
        return
    session = _seven_session(update.effective_chat.id)
    if not session or not session.started:
        await update.message.reply_text("بازی فعال نیست.")
        return
    if update.effective_user.id != session.player_turn():
        await update.message.reply_text("الان نوبت شما نیست.")
        return
    if not context.args:
        await update.message.reply_text("استفاده: /sevenplay 7H یا /sevenplay J دل")
        return

    # support "rank suit" or single token
    card_text = " ".join(context.args)
    parsed = _parse_card(card_text)
    if not parsed:
        await update.message.reply_text("فرمت کارت نامعتبر است. نمونه: 7H ، 10S ، J دل")
        return
    rank, suit = parsed
    hand = session.hands[update.effective_user.id]

    # verify ownership
    idx = next((i for i, c in enumerate(hand) if c == (rank, suit)), None)
    if idx is None:
        await update.message.reply_text("این کارت در دست شما نیست.")
        return

    top = session.current_top()
    top_rank, top_suit = top if top else (None, None)

    # draw penalty handling
    if session.pending_draw > 0 and rank not in {"7", "2"}:
        await update.message.reply_text(f"باید اول {session.pending_draw} کارت جریمه را بردارید یا با 7/2 جریمه را ادامه دهید.")
        return

    # legal move
    legal = False
    if not top:
        legal = True
    elif rank in {"J", "A"}:
        legal = True
    elif session.pending_draw > 0 and rank in {"7", "2"}:
        legal = True
    elif rank == top_rank or suit == session.current_suit:
        legal = True

    if not legal:
        await update.message.reply_text("این کارت روی کارت رو مجاز نیست.")
        return

    # remove from hand
    hand.pop(idx)
    session.discard_pile.append((rank, suit))
    session.current_suit = suit if rank not in {"J", "A"} else session.current_suit

    # apply effects
    if rank == "7":
        session.pending_draw += 2
        session.pending_rank = "7"
    elif rank == "2":
        session.pending_draw += 1
        session.pending_rank = "2"
    elif rank == "8":
        session.skip_next = True
    elif rank == "10":
        session.direction *= -1
    elif rank in {"J", "A"}:
        chosen = None
        if len(context.args) >= 2:
            chosen = _norm_suit(context.args[-1])
        if not chosen:
            await update.message.reply_text("برای J یا A باید خال بعدی را هم بنویسی. مثال: /sevenplay J دل")
            # restore card
            hand.append((rank, suit))
            session.discard_pile.pop()
            return
        session.current_suit = chosen
        session.discard_pile[-1] = (rank, chosen)

    await update.message.reply_text(f"کارت {_card_to_text(session.discard_pile[-1])} بازی شد.")

    # check finish
    if len(hand) == 0:
        session.winner_id = update.effective_user.id
        await context.bot.send_message(chat_id=session.chat_id, text=f"🏆 برنده هفت خبیث: {update.effective_user.first_name}")
        SEVEN_SESSIONS.pop(session.chat_id, None)
        return

    # advance turn
    if session.skip_next:
        session.next_index(2)
        session.skip_next = False
    else:
        session.next_index(1)

    # if pending draw and next player is forced, just announce
    await _seven_check_end_or_next(update, context, session)


async def seven_status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type == "private":
        return
    session = _seven_session(update.effective_chat.id)
    if not session:
        await update.message.reply_text("بازی فعالی وجود ندارد.")
        return
    text = (
        f"🃏 وضعیت هفت خبیث\n"
        f"بازیکن‌ها: {len(session.players)}/{session.target_players}\n"
        f"کارت رو: {_card_to_text(session.current_top()) if session.current_top() else 'ندارد'}\n"
        f"رنگ: {SUIT_NAMES.get(session.current_suit, session.current_suit or '-')}\n"
        f"جریمه معوق: {session.pending_draw}\n"
    )
    await update.message.reply_text(text)


def _hokm_rank_value(rank: str) -> int:
    order = {r: i for i, r in enumerate(RANK_ORDER)}
    return order.get(rank, 0)


async def hokm_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type == "private":
        await update.message.reply_text("این بازی فقط در گروه‌ها قابل استفاده است.")
        return
    if not context.args:
        await update.message.reply_text(
            """🂠 <b>حکم</b>

ساخت بازی:
• /hokm 2
• /hokm 4

پیوستن: /hokmjoin
شروع: /hokmstart
انتخاب حکم: /hokmchoose دل
وضعیت: /hokmstatus""",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🂠 ساخت 2 نفره", callback_data="games_hokm_2"),
                 InlineKeyboardButton("🂠 ساخت 4 نفره", callback_data="games_hokm_4")],
                [InlineKeyboardButton("📊 وضعیت", callback_data="games_hokm_status"),
                 InlineKeyboardButton("🔙 بازگشت", callback_data="games_back")],
            ])
        )
        return
    if not await user_has_permission(update, context, "games"):
        await update.message.reply_text("برای ساخت بازی دسترسی لازم را ندارید.")
        return
    if context.args[0] not in {"2", "4"}:
        await update.message.reply_text("استفاده: /hokm 2 یا /hokm 4")
        return
    count = int(context.args[0])
    chat_id = update.effective_chat.id
    if chat_id in HOKM_SESSIONS and HOKM_SESSIONS[chat_id].started is False:
        await update.message.reply_text("یک بازی حکم در حال ساخت است. اول همان را شروع یا لغو کن.")
        return
    session = HokmGameSession(chat_id=chat_id, host_id=update.effective_user.id, target_players=count, players=[update.effective_user.id], trick_wins={})
    HOKM_SESSIONS[chat_id] = session
    await update.message.reply_text(
        f"🂠 بازی حکم ساخته شد برای {count} بازیکن.\n"
        f"بازیکن‌ها با /hokmjoin اضافه شوند و سپس میزبان با /hokmstart شروع کند."
    )


async def hokm_join_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type == "private":
        return
    session = _hokm_session(update.effective_chat.id)
    if not session or session.started:
        await update.message.reply_text("بازی فعالی برای پیوستن وجود ندارد.")
        return
    if update.effective_user.id in session.players:
        await update.message.reply_text("شما قبلاً وارد بازی شده‌اید.")
        return
    if len(session.players) >= session.target_players:
        await update.message.reply_text("تعداد بازیکن‌ها کامل شده است.")
        return
    session.players.append(update.effective_user.id)
    await update.message.reply_text(f"{update.effective_user.first_name} به بازی حکم اضافه شد. ({len(session.players)}/{session.target_players})")


async def hokm_start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type == "private":
        return
    session = _hokm_session(update.effective_chat.id)
    if not session:
        await update.message.reply_text("بازی حکمی ساخته نشده است.")
        return
    if update.effective_user.id != session.host_id and update.effective_user.id != ADMIN_ID:
        await update.message.reply_text("فقط میزبان بازی می‌تواند آن را شروع کند.")
        return
    if len(session.players) != session.target_players:
        await update.message.reply_text(f"هنوز تعداد بازیکن‌ها کامل نیست. ({len(session.players)}/{session.target_players})")
        return

    session.deck = _make_deck()
    deal_count = 13 if session.target_players == 4 else 26
    for pid in session.players:
        session.hands[pid] = [session.deck.pop() for _ in range(deal_count)]
        session.trick_wins[pid] = 0

    session.started = True
    session.phase = "waiting_trump"
    session.current_turn_index = 0
    session.current_lead_index = 0
    await update.message.reply_text(
        "🎲 حکم شروع شد.\n"
        "میزبان/حاکم باید حکم را با /hokmchoose دل (یا پیک/خشت/گشنیز) انتخاب کند."
    )
    await _hokm_show_status(update, context, session)


async def hokm_choose_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type == "private":
        return
    session = _hokm_session(update.effective_chat.id)
    if not session or not session.started:
        await update.message.reply_text("بازی حکم فعال نیست.")
        return
    if update.effective_user.id != session.host_id and update.effective_user.id != ADMIN_ID:
        await update.message.reply_text("فقط میزبان می‌تواند حکم را انتخاب کند.")
        return
    if not context.args:
        await update.message.reply_text("استفاده: /hokmchoose دل")
        return
    suit = _norm_suit(context.args[0])
    if not suit:
        await update.message.reply_text("خال نامعتبر است. از دل، پیک، خشت یا گشنیز استفاده کن.")
        return
    session.trump_suit = suit
    session.phase = "playing"
    await update.message.reply_text(f"حکم انتخاب شد: {SUIT_NAMES[suit]}")
    await _hokm_announce_turn(update, context, session)


async def _hokm_announce_turn(update: Update, context: ContextTypes.DEFAULT_TYPE, session: HokmGameSession):
    pid = session.turn_player()
    try:
        user = await context.bot.get_chat(pid)
        name = user.first_name or user.username or str(pid)
    except Exception:
        name = str(pid)
    await context.bot.send_message(
        chat_id=session.chat_id,
        text=(
            f"نوبت {name} است.\n"
            f"حکم: {SUIT_NAMES.get(session.trump_suit, '-')}\n"
            f"برای بازی: /hokmplay <کارت>\n"
            f"کارت‌های شما: {_format_hand(session.hands.get(pid, []))}"
        )
    )


async def hokm_play_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type == "private":
        return
    session = _hokm_session(update.effective_chat.id)
    if not session or not session.started:
        await update.message.reply_text("بازی فعال نیست.")
        return
    if session.phase != "playing":
        await update.message.reply_text("اول باید حکم انتخاب شود.")
        return
    if update.effective_user.id != session.turn_player():
        await update.message.reply_text("الان نوبت شما نیست.")
        return
    if not context.args:
        await update.message.reply_text("استفاده: /hokmplay 10H")
        return

    card_text = " ".join(context.args)
    parsed = _parse_card(card_text)
    if not parsed:
        await update.message.reply_text("فرمت کارت نامعتبر است.")
        return
    rank, suit = parsed
    hand = session.hands[update.effective_user.id]
    idx = next((i for i, c in enumerate(hand) if c == (rank, suit)), None)
    if idx is None:
        await update.message.reply_text("این کارت در دست شما نیست.")
        return

    lead_suit = session.current_trick[0][1][1] if session.current_trick else suit
    if session.current_trick:
        has_lead = any(c[1] == lead_suit for c in hand)
        if has_lead and suit != lead_suit:
            await update.message.reply_text("باید خالِ شروع دست را رعایت کنید.")
            return

    hand.pop(idx)
    session.current_trick.append((update.effective_user.id, (rank, suit)))
    await update.message.reply_text(f"کارت {_card_to_text((rank, suit))} بازی شد.")

    # If trick is complete
    if len(session.current_trick) == session.target_players:
        winner_pid = _hokm_winner(session)
        session.trick_wins[winner_pid] = session.trick_wins.get(winner_pid, 0) + 1
        session.current_trick = []
        session.current_lead_index = session.players.index(winner_pid)
        session.current_turn_index = session.current_lead_index
        await context.bot.send_message(
            chat_id=session.chat_id,
            text=f"🏁 این دست را {winner_pid} برد. امتیازها: {session.trick_wins}"
        )
        if _hokm_game_over(session):
            team, text = _hokm_final_text(session)
            await context.bot.send_message(chat_id=session.chat_id, text=text)
            HOKM_SESSIONS.pop(session.chat_id, None)
            return
        await _hokm_announce_turn(update, context, session)
        return

    session.current_turn_index = (session.current_turn_index + 1) % len(session.players)
    await _hokm_announce_turn(update, context, session)


def _hokm_winner(session: HokmGameSession) -> int:
    lead_suit = session.current_trick[0][1][1]
    trump = session.trump_suit
    best_pid = session.current_trick[0][0]
    best_card = session.current_trick[0][1]
    best_value = _hokm_rank_value(best_card[0])
    best_is_trump = best_card[1] == trump

    for pid, card in session.current_trick[1:]:
        rank, suit = card
        is_trump = suit == trump
        value = _hokm_rank_value(rank)
        if best_is_trump and is_trump:
            if value > best_value:
                best_pid, best_card, best_value = pid, card, value
        elif is_trump and not best_is_trump:
            best_pid, best_card, best_value, best_is_trump = pid, card, value, True
        elif not best_is_trump and not is_trump and suit == lead_suit and best_card[1] == lead_suit:
            if value > best_value:
                best_pid, best_card, best_value = pid, card, value
        elif not best_is_trump and suit == lead_suit and best_card[1] != lead_suit:
            best_pid, best_card, best_value = pid, card, value

    return best_pid


def _hokm_game_over(session: HokmGameSession) -> bool:
    # Standard target is 7 tricks
    if session.target_players == 4:
        team0 = sum(v for pid, v in session.trick_wins.items() if session.players.index(pid) % 2 == 0)
        team1 = sum(v for pid, v in session.trick_wins.items() if session.players.index(pid) % 2 == 1)
        return team0 >= 7 or team1 >= 7 or all(len(h) == 0 for h in session.hands.values())
    return any(v >= 7 for v in session.trick_wins.values()) or all(len(h) == 0 for h in session.hands.values())


def _hokm_final_text(session: HokmGameSession) -> str:
    if session.target_players == 4:
        team0 = sum(v for pid, v in session.trick_wins.items() if session.players.index(pid) % 2 == 0)
        team1 = sum(v for pid, v in session.trick_wins.items() if session.players.index(pid) % 2 == 1)
        if team0 > team1:
            return f"🏆 تیم ۱ برنده حکم شد.\nامتیاز: {team0} - {team1}"
        if team1 > team0:
            return f"🏆 تیم ۲ برنده حکم شد.\nامتیاز: {team1} - {team0}"
        return f"🤝 بازی مساوی شد.\nامتیاز: {team0} - {team1}"
    winner = max(session.trick_wins.items(), key=lambda kv: kv[1])[0]
    return f"🏆 برنده حکم: {winner}\nامتیازها: {session.trick_wins}"


async def _hokm_show_status(update: Update, context: ContextTypes.DEFAULT_TYPE, session: HokmGameSession):
    text = (
        f"🂠 وضعیت حکم\n"
        f"بازیکن‌ها: {len(session.players)}/{session.target_players}\n"
        f"حکم: {SUIT_NAMES.get(session.trump_suit, 'انتخاب نشده')}\n"
        f"دست‌های برده شده: {session.trick_wins}\n"
    )
    await context.bot.send_message(chat_id=session.chat_id, text=text)


async def hokm_status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type == "private":
        return
    session = _hokm_session(update.effective_chat.id)
    if not session:
        await update.message.reply_text("بازی فعالی وجود ندارد.")
        return
    await _hokm_show_status(update, context, session)


async def get_royal_role_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> str:
    role = db.get_royal_role(update.effective_chat.id, update.effective_user.id)
    if role:
        perms = "، ".join(sorted(_role_permissions(role))) or "بدون دسترسی"
        return f"مقام شما: {role}\nدسترسی‌ها: {perms}"
    return "برای شما هیچ مقامی ثبت نشده است."


def register_handlers(application: Application):
    application.add_handler(CallbackQueryHandler(games_callback_handler, pattern='^games_'))
    application.add_handler(CommandHandler("royal", royal_ping_command))
    application.add_handler(CommandHandler("roles", royal_roles_command))
    application.add_handler(CommandHandler("setrole", royal_set_role_command))

    application.add_handler(CommandHandler("seven", seven_command))
    application.add_handler(CommandHandler("sevenjoin", seven_join_command))
    application.add_handler(CommandHandler("sevenstart", seven_start_command))
    application.add_handler(CommandHandler("sevenplay", seven_play_command))
    application.add_handler(CommandHandler("sevendraw", seven_draw_command))
    application.add_handler(CommandHandler("sevenstatus", seven_status_command))

    application.add_handler(CommandHandler("hokm", hokm_command))
    application.add_handler(CommandHandler("hokmjoin", hokm_join_command))
    application.add_handler(CommandHandler("hokmstart", hokm_start_command))
    application.add_handler(CommandHandler("hokmchoose", hokm_choose_command))
    application.add_handler(CommandHandler("hokmplay", hokm_play_command))
    application.add_handler(CommandHandler("hokmstatus", hokm_status_command))
