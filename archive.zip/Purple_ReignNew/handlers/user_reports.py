import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, CommandHandler, MessageHandler, filters, CallbackQueryHandler
from database.database import Database
from config import ADMIN_ID

logger = logging.getLogger(__name__)
db = Database("group_manager.db")

async def report_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """دستور گزارش پیام"""
    try:
        # بررسی اینکه آیا پیام ریپلای شده است
        if not update.message.reply_to_message:
            await update.message.reply_text("برای گزارش، باید روی پیام مورد نظر ریپلای کنید.")
            return
            
        # دریافت اطلاعات پیام و کاربر گزارش شده
        reported_message = update.message.reply_to_message
        reported_user = reported_message.from_user
        reporter_user = update.message.from_user
        group_id = update.effective_chat.id
        
        # دریافت متن گزارش (اختیاری)
        report_text = " ".join(context.args) if context.args else "بدون توضیحات"
        
        # ثبت گزارش در دیتابیس
        report_id = db.add_user_report(
            group_id=group_id,
            reported_user_id=reported_user.id,
            reporter_user_id=reporter_user.id,
            message_id=reported_message.message_id,
            report_text=report_text
        )
        
        # ارسال پیام تأیید به کاربر گزارش‌دهنده
        await update.message.reply_text(
            f"✅ گزارش شما با شناسه #{report_id} ثبت شد و توسط ادمین‌ها بررسی خواهد شد."
        )
        
        # ارسال گزارش به ادمین‌های گروه
        keyboard = [
            [InlineKeyboardButton("✅ تأیید", callback_data=f'report_approve_{report_id}')],
            [InlineKeyboardButton("❌ رد", callback_data=f'report_reject_{report_id}')],
            [InlineKeyboardButton("🔍 بررسی بیشتر", callback_data=f'report_details_{report_id}')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # دریافت محتوای پیام گزارش شده
        reported_message_content = ""
        if reported_message.text:
            reported_message_content = reported_message.text
        elif reported_message.caption:
            reported_message_content = reported_message.caption
        elif reported_message.photo:
            reported_message_content = "[تصویر]"
        elif reported_message.video:
            reported_message_content = "[ویدیو]"
        elif reported_message.document:
            reported_message_content = f"[فایل: {reported_message.document.file_name}]"
        elif reported_message.sticker:
            reported_message_content = "[استیکر]"
        else:
            reported_message_content = "[محتوای نامشخص]"
        
        # ساخت متن گزارش برای ادمین‌ها
        admin_report = f"📣 گزارش جدید (#{report_id}):\n\n"
        admin_report += f"👤 گزارش‌دهنده: {reporter_user.first_name} (@{reporter_user.username or 'بدون یوزرنیم'})\n"
        admin_report += f"👤 کاربر گزارش‌شده: {reported_user.first_name} (@{reported_user.username or 'بدون یوزرنیم'})\n"
        admin_report += f"💬 متن گزارش: {report_text}\n\n"
        admin_report += f"📄 محتوای پیام گزارش شده:\n"
        admin_report += f"{reported_message_content}\n"
        
        # دریافت لیست ادمین‌های گروه
        try:
            chat_administrators = await context.bot.get_chat_administrators(group_id)
            admin_ids = [admin.user.id for admin in chat_administrators]
            admin_mentions = []
            
            # ساخت منشن برای هر ادمین
            for admin in chat_administrators:
                if not admin.user.is_bot:  # بات‌ها را منشن نکن
                    admin_mentions.append(f"[{admin.user.first_name}](tg://user?id={admin.user.id})")
            
            # اضافه کردن منشن ادمین‌ها به پیام
            if admin_mentions:
                admin_report += "\n🔔 ادمین‌های گروه: " + ", ".join(admin_mentions)
        except Exception as e:
            logger.error(f"Error getting chat administrators: {str(e)}")
        
        # ارسال به گروه
        try:
            await context.bot.send_message(
                chat_id=group_id,
                text=admin_report,
                reply_markup=reply_markup,
                parse_mode="Markdown",
                reply_to_message_id=reported_message.message_id
            )
        except Exception as e:
            logger.error(f"Error sending report to group: {str(e)}")
            # اگر ارسال به گروه با خطا مواجه شد، به ADMIN_ID ارسال کن
            await context.bot.send_message(
                chat_id=ADMIN_ID,
                text=admin_report + "\n\n⚠️ خطا در ارسال به گروه",
                reply_markup=reply_markup,
                parse_mode="Markdown"
            )
        
    except Exception as e:
        logger.error(f"Error in report_command: {str(e)}")
        await update.message.reply_text(f"خطا در ثبت گزارش: {str(e)}")

async def report_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """پردازش دکمه‌های گزارش"""
    try:
        query = update.callback_query
        await query.answer()
        
        # دریافت شناسه گزارش و عملیات
        data = query.data.split('_')
        action = data[1]  # approve, reject, details
        report_id = int(data[2])
        
        # دریافت اطلاعات گزارش
        report = db.get_report_details(report_id)
        if not report:
            await query.message.edit_text("گزارش یافت نشد یا حذف شده است.")
            return
            
        if action == 'approve':
            # تأیید گزارش
            db.update_report_status(
                report_id=report_id,
                status='approved',
                admin_response="گزارش تأیید شد",
                admin_id=update.effective_user.id
            )
            
            # ویرایش پیام ادمین
            await query.message.edit_text(
                f"✅ گزارش #{report_id} تأیید شد.\n\n"
                f"👤 کاربر گزارش‌شده: {report['reported_user_id']}\n"
                f"💬 متن گزارش: {report['report_text']}",
                reply_markup=None
            )
            
            # ارسال پیام به کاربر گزارش‌دهنده
            try:
                await context.bot.send_message(
                    chat_id=report['reporter_user_id'],
                    text=f"✅ گزارش شما با شناسه #{report_id} بررسی و تأیید شد.\n\nاقدامات لازم انجام خواهد شد."
                )
            except Exception as e:
                logger.error(f"Error sending approval message to reporter: {str(e)}")
                
            # ریپلای به پیام گزارش‌شده با دکمه شیشه‌ای
            try:
                await context.bot.send_message(
                    chat_id=report['group_id'],
                    reply_to_message_id=report['message_id'],
                    text="✅ این پیام توسط ادمین بررسی و تأیید شد."
                )
            except Exception as e:
                logger.error(f"Error replying to reported message: {str(e)}")
                
        elif action == 'reject':
            # رد گزارش
            db.update_report_status(
                report_id=report_id,
                status='rejected',
                admin_response="گزارش رد شد",
                admin_id=update.effective_user.id
            )
            
            # ویرایش پیام ادمین
            await query.message.edit_text(
                f"❌ گزارش #{report_id} رد شد.\n\n"
                f"👤 کاربر گزارش‌شده: {report['reported_user_id']}\n"
                f"💬 متن گزارش: {report['report_text']}",
                reply_markup=None
            )
            
            # ارسال پیام به کاربر گزارش‌دهنده
            try:
                await context.bot.send_message(
                    chat_id=report['reporter_user_id'],
                    text=f"❌ گزارش شما با شناسه #{report_id} بررسی و رد شد.\n\nاین پیام مغایرتی با قوانین گروه ندارد."
                )
            except Exception as e:
                logger.error(f"Error sending rejection message to reporter: {str(e)}")
                
            # ریپلای به پیام گزارش‌شده با دکمه شیشه‌ای
            try:
                await context.bot.send_message(
                    chat_id=report['group_id'],
                    reply_to_message_id=report['message_id'],
                    text="❌ این پیام توسط ادمین بررسی و رد شد."
                )
            except Exception as e:
                logger.error(f"Error replying to reported message: {str(e)}")
                
        elif action == 'details':
            # نمایش جزئیات بیشتر گزارش
            details = f"🔍 جزئیات گزارش #{report_id}:\n\n"
            details += f"👤 گزارش‌دهنده: {report['reporter_user_id']}\n"
            details += f"👤 کاربر گزارش‌شده: {report['reported_user_id']}\n"
            details += f"💬 متن گزارش: {report['report_text']}\n"
            details += f"⏰ زمان گزارش: {report['report_time']}\n"
            details += f"📝 وضعیت: {report['status']}\n"
            
            keyboard = [
                [InlineKeyboardButton("✅ تأیید", callback_data=f'report_approve_{report_id}')],
                [InlineKeyboardButton("❌ رد", callback_data=f'report_reject_{report_id}')],
                [InlineKeyboardButton("بازگشت", callback_data=f'report_back')]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.message.edit_text(details, reply_markup=reply_markup)
            
        elif action == 'back':
            # بازگشت به لیست گزارش‌ها (در نسخه کامل‌تر باید پیاده‌سازی شود)
            await query.message.edit_text("بازگشت به لیست گزارش‌ها...")
            
    except Exception as e:
        logger.error(f"Error in report_callback_handler: {str(e)}")
        await query.message.edit_text(f"خطا در پردازش گزارش: {str(e)}")

def setup_handlers(application):
    """تنظیم هندلرهای گزارش"""
    application.add_handler(CommandHandler("report", report_command))
    application.add_handler(CallbackQueryHandler(report_callback_handler, pattern='^report_'))