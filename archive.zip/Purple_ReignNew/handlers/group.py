import logging
import sqlite3
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import ContextTypes
from telegram.error import TelegramError
from config import MAX_WARNINGS, ADMIN_ID
from database.database import Database
import re

# Set up logger
logger = logging.getLogger(__name__)

# Initialize database
db = Database("group_manager.db")

# Regex patterns
LINK_PATTERN = r'(https?://\S+)|(t\.me/\S+)|(@\S+)|(telegram\.me/\S+)|(telegram\.dog/\S+)'

# Persian/Iranian profanity words list
PROFANITY_WORDS = [
    'کیر', 'کص', 'کس', 'جنده', 'گایید', 'گاید', 'کون', 'جاکش', 'قحبه',
    'مادرجنده', 'کسکش', 'کیری', 'گوه', 'عن', 'لاشی', 'بیناموس', 'حرومزاده',
    'دیوث', 'بیشرف', 'آشغال', 'عوضی', 'پفیوز', 'خفه شو', 'بی ناموس', 'حروم زاده',
    'کسخل', 'کصخل', 'بیغیرت', 'بی غیرت', 'جاکش', 'گوز', 'چاقال', 'جاکش', 'گه',
    'شاش', 'ریدی', 'مادر خراب', 'پدر سگ', 'پدرسگ'
]

def contains_profanity(text):
    """Check if text contains any profanity words."""
    text = text.lower()
    return any(word in text for word in PROFANITY_WORDS)

async def check_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Check messages for links and profanity."""
    try:
        # Add group to database if not exists
        db.add_group(update.effective_chat.id, update.effective_chat.title)
        
        # Add user to database if not exists
        user = update.effective_user
        db.add_user(user.id, user.username)
        
        # Add message to database for tagging feature
        db.add_message(update.message.message_id, update.effective_chat.id, user.id)
        
        # Check if group is premium
        is_premium = db.is_group_premium(update.effective_chat.id)

        # Ignore messages from admins
        user = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if user.status in ['administrator', 'creator'] or update.effective_user.id == ADMIN_ID:
            return

        message = update.message.text or update.message.caption or ""
        
        # Check for profanity or links
        has_profanity = contains_profanity(message)
        has_link = bool(re.search(LINK_PATTERN, message, re.IGNORECASE))
        
        if has_profanity or has_link:
            # Delete the message
            await update.message.delete()
            
            # Get user info
            user = update.effective_user
            db.add_user(user.id, user.username)
            
            if not is_premium:
                # Show premium subscription message
                warning_msg = (
                    "⭐️ برای استفاده از امکانات کامل ربات، گروه باید پرمیوم شود!\n\n"
                    "✅ مزایای اشتراک پرمیوم:\n"
                    "• سیستم اخطار خودکار\n"
                    "• خوش‌آمدگویی خودکار\n"
                    "• مدیریت کامل گروه\n"
                    "• پشتیبانی ۲۴ ساعته\n\n"
                    "👈 برای فعال‌سازی اشتراک پرمیوم، ادمین گروه می‌تواند از دستور /admin استفاده کند."
                )
            else:
                # Add warning in premium groups
                group_id = update.effective_chat.id
                db.add_warning(user.id, group_id, "استفاده از محتوای نامناسب" if has_profanity else "ارسال لینک غیرمجاز")
                warnings = db.get_user_warnings(user.id, group_id)
                
                if has_profanity:
                    warning_msg = (
                        f"🚫 <b>اخطار | کلمات نامناسب</b>\n\n"
                        f"👤 کاربر: {user.mention_html()}\n"
                        f"⚠️ دلیل: استفاده از کلمات نامناسب\n"
                        f"📊 تعداد اخطارها: <b>{warnings}/{MAX_WARNINGS}</b>\n\n"
                        f"💡 لطفاً از کلمات مناسب استفاده کنید و احترام به سایر اعضا را رعایت نمایید."
                    )
                else:
                    warning_msg = (
                        f"🔗 <b>اخطار | ارسال لینک</b>\n\n"
                        f"👤 کاربر: {user.mention_html()}\n"
                        f"⚠️ دلیل: ارسال لینک غیرمجاز\n"
                        f"📊 تعداد اخطارها: <b>{warnings}/{MAX_WARNINGS}</b>\n\n"
                        f"💡 برای حفظ امنیت گروه، ارسال لینک بدون اجازه ممنوع است."
                    )
                
                if warnings >= MAX_WARNINGS:
                    db.ban_user(user.id)
                    try:
                        await context.bot.ban_chat_member(update.effective_chat.id, user.id)
                        warning_msg += f"\n\n🚨 <b>کاربر به دلیل دریافت {MAX_WARNINGS} اخطار از گروه مسدود شد!</b>"
                    except TelegramError:
                        warning_msg += "\n\n❌ خطا در مسدود کردن کاربر!"
                else:
                    remaining_warnings = MAX_WARNINGS - warnings
                    if remaining_warnings == 1:
                        warning_msg += f"\n\n⚡️ <b>توجه:</b> تنها <b>1 اخطار</b> تا مسدود شدن باقی مانده!"
                    elif remaining_warnings == 2:
                        warning_msg += f"\n\n⚠️ <b>هشدار:</b> <b>{remaining_warnings} اخطار</b> تا مسدود شدن باقی مانده!"
            
            await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text=warning_msg,
                parse_mode=ParseMode.HTML
            )
    except Exception as e:
        logger.error(f"Error in check_message: {str(e)}")

async def welcome_new_member(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Welcome new members with customizable message"""
    try:
        # Get group settings
        group_id = update.effective_chat.id
        group_settings = db.get_group_settings(group_id)
        
        if not group_settings or not group_settings.get('welcome_enabled', True):
            return
            
        # Get custom welcome message if exists
        custom_welcome = group_settings.get('welcome_message', '')
        
        for new_member in update.message.new_chat_members:
            # Skip if the new member is the bot itself
            if new_member.id == context.bot.id:
                continue
                
            # Add user to database
            db.add_user(new_member.id, new_member.username)
            
            # Prepare welcome message
            if custom_welcome:
                # Replace placeholders
                welcome_msg = custom_welcome
                welcome_msg = welcome_msg.replace('{name}', new_member.first_name)
                welcome_msg = welcome_msg.replace('{username}', f"@{new_member.username}" if new_member.username else new_member.first_name)
                welcome_msg = welcome_msg.replace('{group}', update.effective_chat.title)
            else:
                # Default welcome message
                welcome_msg = f"👋 سلام {new_member.first_name} عزیز!\n\n"
                welcome_msg += f"به گروه {update.effective_chat.title} خوش آمدید.\n"
                welcome_msg += "لطفاً قوانین گروه را مطالعه کنید و رعایت نمایید.\n\n"
                welcome_msg += "⚠️ قوانین مهم:\n"
                welcome_msg += "• ارسال لینک ممنوع است\n"
                welcome_msg += "• استفاده از کلمات نامناسب ممنوع است\n"
                welcome_msg += "• احترام به سایر اعضا الزامی است\n"
            
            # Add buttons if enabled
            if group_settings.get('welcome_buttons_enabled', False):
                keyboard = []
                
                # Add rules button if rules message is set
                if group_settings.get('rules_message'):
                    keyboard.append([InlineKeyboardButton("📋 قوانین گروه", callback_data=f'rules_{group_id}')])
                
                # Add custom buttons
                custom_buttons = group_settings.get('custom_buttons', [])
                for button in custom_buttons:
                    if button.get('url'):
                        keyboard.append([InlineKeyboardButton(button.get('text', 'لینک'), url=button.get('url'))])
                
                if keyboard:
                    reply_markup = InlineKeyboardMarkup(keyboard)
                    await update.message.reply_text(welcome_msg, reply_markup=reply_markup)
                    return
            
            # Send welcome message without buttons
            await update.message.reply_text(welcome_msg)
            
    except Exception as e:
        logger.error(f"Error in welcome_new_member: {str(e)}")

async def warn_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Warn a user by replying to their message."""
    try:
        # Add group to database if not exists
        db.add_group(update.effective_chat.id, update.effective_chat.title)

        # Only allow warning in premium groups
        if not db.is_group_premium(update.effective_chat.id):
            if update.effective_user.id == ADMIN_ID:
                await update.message.reply_text(
                    "❌ سیستم اخطار فقط در گروه‌های پرمیوم فعال است!\n"
                    "برای افزودن گروه به لیست پرمیوم، از دستور /admin استفاده کنید."
                )
            return

        # Check if command issuer is admin
        user = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if user.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("شما دسترسی به این دستور را ندارید!")
            return

        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً روی پیام کاربر مورد نظر ریپلای کنید.")
            return

        target_user = update.message.reply_to_message.from_user
        warner = update.message.from_user
        
        if target_user.id == warner.id:
            await update.message.reply_text("شما نمی‌توانید به خودتان اخطار دهید!")
            return
        
        # Add user to database if not exists
        db.add_user(target_user.id, target_user.username)
        
        # Add warning
        group_id = update.effective_chat.id
        reason = ' '.join(context.args) if context.args else "نقض قوانین گروه"
        db.add_warning(target_user.id, group_id, reason, warner.id)
        warnings = db.get_user_warnings(target_user.id, group_id)
        
        if warnings >= MAX_WARNINGS:
            db.ban_user(target_user.id)
            try:
                await context.bot.ban_chat_member(update.message.chat.id, target_user.id)
                await update.message.reply_text(
                    f"🚨 <b>مسدود شدن کاربر</b>\n\n"
                    f"👤 کاربر: {target_user.mention_html()}\n"
                    f"⚠️ دلیل: دریافت {MAX_WARNINGS} اخطار\n"
                    f"🔒 وضعیت: مسدود شده از گروه\n\n"
                    f"💡 کاربر به دلیل نقض مکرر قوانین از گروه حذف شد.",
                    parse_mode=ParseMode.HTML
                )
            except TelegramError:
                await update.message.reply_text(
                    f"❌ <b>خطا در مسدود کردن</b>\n\n"
                    f"👤 کاربر: {target_user.mention_html()}\n"
                    f"⚠️ علت: عدم دسترسی کافی ربات\n\n"
                    f"💡 لطفاً دسترسی‌های ربات را بررسی کنید.",
                    parse_mode=ParseMode.HTML
                )
        else:
            remaining_warnings = MAX_WARNINGS - warnings
            warning_msg = (
                f"⚠️ <b>اخطار دستی</b>\n\n"
                f"👤 کاربر: {target_user.mention_html()}\n"
                f"🔍 دلیل: {reason}\n"
                f"📊 تعداد اخطارها: <b>{warnings}/{MAX_WARNINGS}</b>\n"
                f"👮‍♂️ اخطار توسط: {warner.mention_html()}\n\n"
            )
            
            if remaining_warnings == 1:
                warning_msg += f"⚡️ <b>توجه:</b> تنها <b>1 اخطار</b> تا مسدود شدن باقی مانده!"
            elif remaining_warnings == 2:
                warning_msg += f"⚠️ <b>هشدار:</b> <b>{remaining_warnings} اخطار</b> تا مسدود شدن باقی مانده!"
            else:
                warning_msg += f"💡 <b>{remaining_warnings} اخطار</b> تا مسدود شدن باقی مانده."
            
            await update.message.reply_text(warning_msg, parse_mode=ParseMode.HTML)
    except Exception as e:
        logger.error(f"Error in warn_user: {str(e)}")
        await update.message.reply_text("خطایی رخ داد. لطفا دوباره تلاش کنید.")

async def unwarn_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Remove a warning from a user."""
    try:
        # Add group to database if not exists
        db.add_group(update.effective_chat.id, update.effective_chat.title)

        # Only allow unwarning in premium groups
        if not db.is_group_premium(update.effective_chat.id):
            if update.effective_user.id == ADMIN_ID:
                await update.message.reply_text(
                    "❌ سیستم اخطار فقط در گروه‌های پرمیوم فعال است!\n"
                    "برای افزودن گروه به لیست پرمیوم، از دستور /admin استفاده کنید."
                )
            return

        # Check if command issuer is admin
        user = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if user.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("شما دسترسی به این دستور را ندارید!")
            return

        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً روی پیام کاربر مورد نظر ریپلای کنید.")
            return

        target_user = update.message.reply_to_message.from_user
        
        # Add user to database if not exists
        db.add_user(target_user.id, target_user.username)
        
        # Remove warning
        group_id = update.effective_chat.id
        db.remove_warning(target_user.id, group_id)
        warnings = db.get_user_warnings(target_user.id, group_id)
        
        await update.message.reply_text(
            f"✅ <b>حذف اخطار</b>\n\n"
            f"👤 کاربر: {target_user.mention_html()}\n"
            f"📉 وضعیت: یک اخطار حذف شد\n"
            f"📊 تعداد اخطارهای فعلی: <b>{warnings}/{MAX_WARNINGS}</b>\n\n"
            f"💡 اخطار کاربر با موفقیت کاهش یافت.",
            parse_mode=ParseMode.HTML
        )
    except Exception as e:
        logger.error(f"Error in unwarn_user: {str(e)}")
        await update.message.reply_text("خطایی رخ داد. لطفا دوباره تلاش کنید.")


async def set_rules(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set group rules"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return
        
        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند از این دستور استفاده کنند.")
            return
        
        # Get rules text
        if not context.args and not update.message.reply_to_message:
            await update.message.reply_text(
                "برای تنظیم قوانین گروه، متن قوانین را بعد از دستور بنویسید یا به یک پیام حاوی قوانین ریپلای کنید.\n\n"
                "مثال:\n"
                "/setrules قوانین گروه:\n1- احترام به اعضا\n2- ارسال نکردن لینک\n3- ..."
            )
            return
        
        # Get rules from reply or args
        if update.message.reply_to_message and update.message.reply_to_message.text:
            rules_text = update.message.reply_to_message.text
        else:
            rules_text = " ".join(context.args)
        
        # Save rules to database
        group_id = update.effective_chat.id
        conn = sqlite3.connect(db.db_name)
        c = conn.cursor()
        c.execute("UPDATE groups SET rules_message = ? WHERE group_id = ?", (rules_text, group_id))
        conn.commit()
        conn.close()
        
        await update.message.reply_text("✅ قوانین گروه با موفقیت تنظیم شد!\n\nاعضا می‌توانند با دستور /rules قوانین را مشاهده کنند.")
        
    except Exception as e:
        logger.error(f"Error in set_rules: {str(e)}")
        await update.message.reply_text(f"خطا در تنظیم قوانین: {str(e)}")

async def show_rules(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show group rules"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return
        
        # Get rules from database
        group_id = update.effective_chat.id
        conn = sqlite3.connect(db.db_name)
        c = conn.cursor()
        c.execute("SELECT rules_message FROM groups WHERE group_id = ?", (group_id,))
        result = c.fetchone()
        conn.close()
        
        if result and result[0]:
            rules_text = result[0]
            await update.message.reply_text(f"📋 *قوانین گروه*\n\n{rules_text}", parse_mode='Markdown')
        else:
            await update.message.reply_text("❌ هنوز قوانینی برای این گروه تنظیم نشده است.\n\nادمین‌ها می‌توانند با دستور /setrules قوانین را تنظیم کنند.")
        
    except Exception as e:
        logger.error(f"Error in show_rules: {str(e)}")
