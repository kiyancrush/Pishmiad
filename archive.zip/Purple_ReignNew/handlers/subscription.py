import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from config import ADMIN_ID, SUBSCRIPTION_CONTACT_ID, SUBSCRIPTION_CONTACT_USERNAME
from database.premium import PremiumManager
from database.database import Database  # اضافه کردن این خط
from handlers.auto_permissions import get_auto_permission_manager
from handlers.royal_system import user_has_permission

logger = logging.getLogger(__name__)

# Initialize premium manager
premium_manager = PremiumManager("group_manager.db")
db = Database("group_manager.db")  # اضافه کردن این خط

# Subscription plans
SUBSCRIPTION_PLANS = {
    'monthly': {'name': 'ماهانه', 'price': 50000, 'days': 30},
    'quarterly': {'name': 'سه ماهه', 'price': 120000, 'days': 90},
    'biannual': {'name': 'شش ماهه', 'price': 200000, 'days': 180},
    'annual': {'name': 'سالانه', 'price': 350000, 'days': 365}
}

async def subscription_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    "Check subscription status of current group"
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text(
                "این دستور فقط در گروه‌ها قابل استفاده است.\n\n"
                "برای خرید اشتراک با ادمین تماس بگیرید:\n\n"
                f"@{SUBSCRIPTION_CONTACT_USERNAME}"
            )
            return

        group_id = update.effective_chat.id
        subscription_info = premium_manager.get_group_subscription_info(group_id)

        if subscription_info and premium_manager.is_group_premium(group_id):
            message = f"✅ وضعیت اشتراک: فعال\n\n"
            message += f"📅 شروع اشتراک: {subscription_info['subscription_start']}\n"
            message += f"📅 پایان اشتراک: {subscription_info['subscription_end']}\n"
            message += f"👤 خریدار: @{subscription_info['buyer_username']}\n\n"

            message += "💎 امکانات فعال:\n"
            message += "• سیستم اخطار خودکار ✅\n"
            message += "• ضد لینک و ضد فحش ✅\n"
            message += "• خوش‌آمدگویی خودکار ✅\n"
            message += "• قفل تایم‌دار پیام همگانی ✅\n"
            message += "• جوین اجباری چنل ✅\n"
            message += "• مدیریت کامل گروه ✅\n"
            message += "• پشتیبانی ۲۴ ساعته ✅"

        else:
            message = f"❌ وضعیت اشتراک: غیرفعال\n\n"
            message += "💎 برای استفاده از امکانات پیشرفته ربات، نیاز به خرید اشتراک دارید.\n\n"
            message += f"👨‍💼 برای خرید اشتراک با ادمین تماس بگیرید:\n"
            message += f"@{SUBSCRIPTION_CONTACT_USERNAME}\n"
            message += f"🆔 آیدی خریدار: `{SUBSCRIPTION_CONTACT_ID}`\n\n"
            message += f"🆔 آیدی گروه برای خرید: `{group_id}`\n\n"
            message += "📋 پلان‌های اشتراک:\n"
            for plan_key, plan_info in SUBSCRIPTION_PLANS.items():
                message += f"• {plan_info['name']}: {plan_info['price']:,} تومان ({plan_info['days']} روز)\n"

        await update.message.reply_text(message, parse_mode='Markdown')

    except Exception as e:
        logger.error(f"Error in subscription_status: {str(e)}")
        await update.message.reply_text("خطایی در بررسی وضعیت اشتراک رخ داد.")

async def add_premium_group(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Add a group to premium list (Admin only)"""
    try:
        if not await user_has_permission(update, context, "premium"):
            await update.message.reply_text("فقط ادمین اصلی یا مقام دارای دسترسی می‌تواند اشتراک اضافه کند.")
            return

        if len(context.args) < 3:
            await update.message.reply_text(
                "استفاده: /addpremium <group_id> <buyer_id> <duration_days>\n\n"
                "مثال:\n\n"
                "/addpremium -1001234567890 123456789 30\n\n"
                "پلان‌های پیش‌فرض:\n\n"
                "• 30 روز (ماهانه)\n"
                "• 90 روز (سه ماهه)\n"
                "• 180 روز (شش ماهه)\n"
                "• 365 روز (سالانه)"
            )
            return

        group_id = int(context.args[0])
        buyer_id = int(context.args[1])
        duration_days = int(context.args[2])

        # Get buyer info
        try:
            buyer_info = await context.bot.get_chat(buyer_id)
            buyer_username = buyer_info.username or "نامشخص"
        except:
            buyer_username = "نامشخص"

        # Check if bot has necessary permissions in the group
        auto_perm_manager = get_auto_permission_manager(premium_manager)
        if auto_perm_manager:
            bot_check, bot_message = await auto_perm_manager.check_bot_permissions(context, group_id)
            if not bot_check:
                await update.message.reply_text(
                    f"⚠️ هشدار: {bot_message}\n"
                    "اشتراک اضافه می‌شود اما ممکن است دسترسی‌های ادمینی به‌روزرسانی نشود.\n"
                    "لطفاً ربات را ادمین کنید و دسترسی 'ارتقا کاربران' را به آن بدهید."
                )

        # Add premium subscription
        success = premium_manager.add_premium_subscription(
            group_id=group_id,
            buyer_id=buyer_id,
            buyer_username=buyer_username,
            duration_days=duration_days
        )

        if success:
            # اضافه کردن این دو خط
            db.add_group(group_id, "Unknown", buyer_id)  # اضافه کردن گروه اگر وجود ندارد
            db.set_group_premium(group_id, True)  # تنظیم وضعیت پرمیوم
            
            logger.info(f"Premium subscription added successfully for group {group_id}")

            # Grant automatic admin access
            if auto_perm_manager:
                logger.info(f"Starting automatic admin access grant for group {group_id}")
                access_result = await auto_perm_manager.grant_premium_admin_access(context, group_id)

                # Send notification to group
                await auto_perm_manager.notify_admin_access_granted(context, group_id, access_result)

                # Confirm to admin
                await update.message.reply_text(
                    f"✅ اشتراک پرمیوم با موفقیت اضافه شد!\n\n"
                    f"🆔 گروه: `{group_id}`\n"
                    f"👤 خریدار: {buyer_username} (`{buyer_id}`)\n"
                    f"⏰ مدت: {duration_days} روز\n\n"
                    f"🔧 دسترسی‌های ادمینی:\n"
                    f"• موفق: {len(access_result.get('granted', []))}\n"
                    f"• ناموفق: {len(access_result.get('failed', []))}\n\n"
                    f"📊 جزئیات در گروه ارسال شد.",
                    parse_mode='Markdown'
                )

            else:
                await update.message.reply_text(
                    f"✅ اشتراک پرمیوم اضافه شد اما خطا در سیستم دسترسی‌ها!\n\n"
                    f"🆔 گروه: `{group_id}`\n"
                    f"👤 خریدار: {buyer_username} (`{buyer_id}`)\n"
                    f"⏰ مدت: {duration_days} روز",
                    parse_mode='Markdown'
                )

            # Refresh premium cache in main
            try:
                from main import load_premium_groups
                load_premium_groups()
                logger.info("Premium groups cache refreshed successfully")
            except Exception as cache_error:
                logger.error(f"Error refreshing premium cache: {str(cache_error)}")

        else:
            await update.message.reply_text("❌ خطا در اضافه کردن اشتراک!")

    except ValueError:
        await update.message.reply_text("❌ مقادیر وارد شده نامعتبر است!")
    except Exception as e:
        logger.error(f"Error in add_premium_group: {str(e)}")
        await update.message.reply_text(f"❌ خطا: {str(e)}")

async def list_premium_groups(update: Update, context: ContextTypes.DEFAULT_TYPE):
    "List all premium groups (Admin only)"
    try:
        if update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین اصلی می‌تواند لیست گروه‌های پرمیوم را مشاهده کند.")
            return

        groups = premium_manager.get_all_premium_groups()

        if not groups:
            await update.message.reply_text("هیچ گروه پرمیومی یافت نشد.")
            return

        message = "📋 لیست گروه‌های پرمیوم:\n\n"

        active_count = 0
        inactive_count = 0

        for group in groups:
            is_active = premium_manager.is_group_premium(group['group_id'])
            status = "🟢 فعال" if is_active else "🔴 منقضی"

            if is_active:
                active_count += 1
            else:
                inactive_count += 1

            message += f"🆔 `{group['group_id']}`\n"
            message += f"📅 {group['subscription_start']} تا {group['subscription_end']}\n"
            message += f"👤 @{group['buyer_username']} (`{group['buyer_id']}`)\n"
            message += f"📊 {status}\n\n"

        message += f"📊 خلاصه آمار:\n"
        message += f"• فعال: {active_count}\n"
        message += f"• منقضی: {inactive_count}\n"
        message += f"• کل: {len(groups)}"

        # Split message if too long
        if len(message) > 4000:
            messages = [message[i:i+4000] for i in range(0, len(message), 4000)]
            for msg in messages:
                await update.message.reply_text(msg, parse_mode='Markdown')
        else:
            await update.message.reply_text(message, parse_mode='Markdown')

    except Exception as e:
        logger.error(f"Error in list_premium_groups: {str(e)}")
        await update.message.reply_text("خطایی در نمایش لیست گروه‌های پرمیوم رخ داد.")

async def check_expiring_subscriptions(context: ContextTypes.DEFAULT_TYPE):
    """Check for subscriptions that are about to expire and send reminders"""
    try:
        premium_manager = PremiumManager("group_manager.db")
        expiring_groups = premium_manager.get_expiring_subscriptions(days=3)

        for group in expiring_groups:
            group_id = group['group_id']
            days_left = group['days_left']

            reminder_message = f"""⚠️ *هشدار انقضای اشتراک*

📅 اشتراک پرمیوم این گروه تا *{days_left} روز دیگر* منقضی می‌شود.

💎 برای تمدید اشتراک با ادمین تماس بگیرید:
[@{SUBSCRIPTION_CONTACT_USERNAME}](https://t.me/{SUBSCRIPTION_CONTACT_USERNAME})

🆔 آیدی گروه: `{group_id}`"""

            try:
                await context.bot.send_message(
                    chat_id=group_id,
                    text=reminder_message,
                    parse_mode='Markdown'
                )
                logger.info(f"Sent expiration reminder to group {group_id} ({days_left} days left)")
            except Exception as e:
                logger.error(f"Failed to send expiration reminder to group {group_id}: {str(e)}")

    except Exception as e:
        logger.error(f"Error in check_expiring_subscriptions: {str(e)}")

# اضافه کردن این متغیر در بالای فایل
PAYMENT_CARD_NUMBER = "6037-XXXX-XXXX-XXXX"  # شماره کارت برای پرداخت

async def buy_subscription(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle subscription purchase process"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text(
                "این دستور فقط در گروه‌ها قابل استفاده است.\n\n"
                "برای خرید اشتراک، ابتدا ربات را به گروه خود اضافه کنید و سپس این دستور را در گروه اجرا کنید."
            )
            return

        group_id = update.effective_chat.id
        user_id = update.effective_user.id
        
        # Check if user is admin in the group
        chat_member = await context.bot.get_chat_member(group_id, user_id)
        if chat_member.status not in ['creator', 'administrator']:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند اشتراک خریداری کنند.")
            return
        
        # Create subscription plan buttons
        keyboard = []
        for plan_key, plan_info in SUBSCRIPTION_PLANS.items():
            keyboard.append([
                InlineKeyboardButton(
                    f"💎 {plan_info['name']}: {plan_info['price']:,} تومان ({plan_info['days']} روز)", 
                    callback_data=f"buy_plan_{plan_key}_{group_id}"
                )
            ])
        
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(
            "🛒 *خرید اشتراک پرمیوم*\n\n"
            "لطفاً پلن مورد نظر خود را انتخاب کنید:\n",
            reply_markup=reply_markup,
            parse_mode='Markdown'
        )
        
    except Exception as e:
        logger.error(f"Error in buy_subscription: {str(e)}")
        await update.message.reply_text("خطایی در فرآیند خرید اشتراک رخ داد.")

async def handle_subscription_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle subscription purchase callbacks"""
    try:
        query = update.callback_query
        await query.answer()
        
        data = query.data
        
        if data.startswith("buy_plan_"):
            # Extract plan and group info
            _, plan_key, group_id = data.split("_", 2)
            group_id = int(group_id)
            
            plan_info = SUBSCRIPTION_PLANS.get(plan_key)
            if not plan_info:
                await query.edit_message_text("پلن انتخابی نامعتبر است. لطفاً دوباره تلاش کنید.")
                return
            
            # Create payment message
            payment_message = f"💳 *اطلاعات پرداخت*\n\n"
            payment_message += f"📋 پلن انتخابی: *{plan_info['name']}*\n"
            payment_message += f"💰 مبلغ قابل پرداخت: *{plan_info['price']:,} تومان*\n"
            payment_message += f"⏱ مدت اشتراک: *{plan_info['days']} روز*\n\n"
            payment_message += f"🏦 شماره کارت: `{PAYMENT_CARD_NUMBER}`\n\n"
            payment_message += f"🆔 آیدی گروه: `{group_id}`\n\n"
            payment_message += "پس از پرداخت، لطفاً رسید پرداخت را به همراه آیدی گروه به ادمین ارسال کنید:\n"
            payment_message += f"👨‍💼 @{SUBSCRIPTION_CONTACT_USERNAME}\n\n"
            payment_message += "⚠️ *نکته مهم*: پس از تأیید پرداخت توسط ادمین، اشتراک شما فعال خواهد شد."
            
            # Create back button
            keyboard = [[
                InlineKeyboardButton("🔙 بازگشت", callback_data=f"back_to_plans_{group_id}")
            ]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                payment_message,
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
            
        elif data.startswith("back_to_plans_"):
            # Extract group id
            _, group_id = data.split("_", 3)
            group_id = int(group_id)
            
            # Recreate subscription plan buttons
            keyboard = []
            for plan_key, plan_info in SUBSCRIPTION_PLANS.items():
                keyboard.append([
                    InlineKeyboardButton(
                        f"💎 {plan_info['name']}: {plan_info['price']:,} تومان ({plan_info['days']} روز)", 
                        callback_data=f"buy_plan_{plan_key}_{group_id}"
                    )
                ])
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                "🛒 *خرید اشتراک پرمیوم*\n\n"
                "لطفاً پلن مورد نظر خود را انتخاب کنید:\n",
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
    
    except Exception as e:
        logger.error(f"Error in handle_subscription_callback: {str(e)}")
        await query.edit_message_text("خطایی در پردازش درخواست رخ داد. لطفاً دوباره تلاش کنید.")
