import logging
import asyncio
from datetime import datetime, timedelta
from telegram import Update, ChatPermissions
from telegram.ext import ContextTypes
from telegram.error import TelegramError, BadRequest, Forbidden
from config import ADMIN_ID
from middleware.premium_check import check_group_premium_status
from database.premium import PremiumManager

logger = logging.getLogger(__name__)

# Global dictionaries to store locks and muted users
locked_groups = {}
force_join_channels = {}
muted_users = {}  # {group_id: {user_id: {'until': datetime, 'task': asyncio.Task}}}

# Initialize premium manager
premium_manager = PremiumManager("group_manager.db")

async def mute_user_timed(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Mute user for specified time duration"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند از این دستور استفاده کنند.")
            return

        # Check if message is a reply
        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً این دستور را در پاسخ به پیام کاربر مورد نظر استفاده کنید.")
            return

        # Log the context args for debugging
        logger.info(f"Mute command context args: {context.args}")

        if not context.args:
            await update.message.reply_text(
                "استفاده: سکوت <مدت به ثانیه>\n"
                "مثال: سکوت 1800 (سکوت برای 30 دقیقه)\n"
                "حداکثر: 86400 ثانیه (24 ساعت)"
            )
            return

        try:
            duration = int(context.args[0])
            if duration <= 0 or duration > 86400:  # Max 24 hours
                await update.message.reply_text("مدت زمان باید بین 1 تا 86400 ثانیه (24 ساعت) باشد.")
                return
        except ValueError:
            await update.message.reply_text("لطفاً یک عدد معتبر وارد کنید.")
            return

        user_to_mute = update.message.reply_to_message.from_user
        group_id = update.effective_chat.id

        # Don't mute admins
        target_member = await context.bot.get_chat_member(group_id, user_to_mute.id)
        if target_member.status in ['administrator', 'creator']:
            await update.message.reply_text("نمی‌توان ادمین‌ها را سکوت کرد.")
            return

        # Don't mute the main admin
        if user_to_mute.id == ADMIN_ID:
            await update.message.reply_text("نمی‌توان ادمین اصلی را سکوت کرد.")
            return

        # Set user permissions to muted
        mute_permissions = ChatPermissions(
            can_send_messages=False,
            can_send_polls=False,
            can_send_other_messages=False,
            can_add_web_page_previews=False,
            can_send_audios=False,
            can_send_documents=False,
            can_send_photos=False,
            can_send_videos=False,
            can_send_video_notes=False,
            can_send_voice_notes=False
        )

        # Calculate unmute time
        unmute_time = datetime.now() + timedelta(seconds=duration)

        # Restrict user
        await context.bot.restrict_chat_member(
            chat_id=group_id,
            user_id=user_to_mute.id,
            permissions=mute_permissions,
            until_date=unmute_time
        )

        # Store mute info
        if group_id not in muted_users:
            muted_users[group_id] = {}

        # Cancel previous mute task if exists
        if user_to_mute.id in muted_users[group_id]:
            old_task = muted_users[group_id][user_to_mute.id].get('task')
            if old_task and not old_task.done():
                old_task.cancel()

        # Create auto-unmute task
        unmute_task = asyncio.create_task(
            auto_unmute_user(context, group_id, user_to_mute.id, duration)
        )

        muted_users[group_id][user_to_mute.id] = {
            'until': unmute_time,
            'muted_by': update.effective_user.id,
            'muted_by_name': update.effective_user.first_name,
            'task': unmute_task
        }

        # Format time display
        hours = duration // 3600
        minutes = (duration % 3600) // 60
        seconds = duration % 60

        time_str = ""
        if hours > 0:
            time_str += f"{hours} ساعت "
        if minutes > 0:
            time_str += f"{minutes} دقیقه "
        if seconds > 0:
            time_str += f"{seconds} ثانیه"

        await update.message.reply_text(
            f"🔇 کاربر {user_to_mute.first_name} برای {time_str} سکوت شد.\n"
            f"⏰ باز شدن خودکار: {unmute_time.strftime('%H:%M:%S')}\n"
            f"👤 سکوت شده توسط: {update.effective_user.first_name}"
        )

        logger.info(f"User {user_to_mute.id} muted in group {group_id} for {duration} seconds by user {update.effective_user.id}")

    except BadRequest as e:
        if "not enough rights" in str(e).lower():
            await update.message.reply_text("ربات دسترسی کافی برای سکوت کردن کاربران ندارد.")
        else:
            await update.message.reply_text(f"خطا در سکوت کردن کاربر: {str(e)}")
        logger.error(f"BadRequest in mute_user_timed: {str(e)}")
    except Forbidden as e:
        await update.message.reply_text("ربات مسدود شده یا دسترسی ندارد.")
        logger.error(f"Forbidden in mute_user_timed: {str(e)}")
    except Exception as e:
        logger.error(f"Error in mute_user_timed: {str(e)}")
        await update.message.reply_text(f"خطا در سکوت کردن کاربر: {str(e)}")

async def unmute_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unmute user manually"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند از این دستور استفاده کنند.")
            return

        # Check if message is a reply
        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً این دستور را در پاسخ به پیام کاربر مورد نظر استفاده کنید.")
            return

        user_to_unmute = update.message.reply_to_message.from_user
        group_id = update.effective_chat.id

        # Check if user is muted
        if group_id not in muted_users or user_to_unmute.id not in muted_users[group_id]:
            await update.message.reply_text("این کاربر سکوت نیست.")
            return

        # Restore normal permissions
        normal_permissions = ChatPermissions(
            can_send_messages=True,
            #   # این پارامتر دیگر پشتیبانی نمی‌شود
            can_send_polls=True,
            can_send_other_messages=True,
            can_add_web_page_previews=True,
            # اضافه کردن پارامترهای جدید
            can_send_audios=True,
            can_send_documents=True,
            can_send_photos=True,
            can_send_videos=True,
            can_send_video_notes=True,
            can_send_voice_notes=True
        )

        await context.bot.restrict_chat_member(
            chat_id=group_id,
            user_id=user_to_unmute.id,
            permissions=normal_permissions
        )

        # Cancel auto-unmute task
        mute_info = muted_users[group_id][user_to_unmute.id]
        if 'task' in mute_info and not mute_info['task'].done():
            mute_info['task'].cancel()

        # Remove from muted users
        del muted_users[group_id][user_to_unmute.id]
        if not muted_users[group_id]:
            del muted_users[group_id]

        await update.message.reply_text(f"🔊 کاربر {user_to_unmute.first_name} از حالت سکوت خارج شد.")

        logger.info(f"User {user_to_unmute.id} unmuted manually in group {group_id}")

    except Exception as e:
        logger.error(f"Error in unmute_user: {str(e)}")
        await update.message.reply_text(f"خطا در خارج کردن کاربر از حالت سکوت: {str(e)}")

async def auto_unmute_user(context: ContextTypes.DEFAULT_TYPE, group_id: int, user_id: int, duration: int):
    """Automatically unmute user after specified duration"""
    try:
        await asyncio.sleep(duration)

        if group_id in muted_users and user_id in muted_users[group_id]:
            # Restore normal permissions
            normal_permissions = ChatPermissions(
                can_send_messages=True,
                
                can_send_polls=True,
                can_send_other_messages=True,
                can_add_web_page_previews=True
            )

            await context.bot.restrict_chat_member(
                chat_id=group_id,
                user_id=user_id,
                permissions=normal_permissions
            )

            # Get user info for notification
            try:
                user_info = await context.bot.get_chat_member(group_id, user_id)
                user_name = user_info.user.first_name
            except:
                user_name = "کاربر"

            # Send notification
            await context.bot.send_message(
                chat_id=group_id,
                text=f"🔊 سکوت کاربر {user_name} به صورت خودکار برداشته شد."
            )

            # Remove from muted users
            del muted_users[group_id][user_id]
            if not muted_users[group_id]:
                del muted_users[group_id]

            logger.info(f"User {user_id} auto-unmuted in group {group_id} after {duration} seconds")

    except Exception as e:
        logger.error(f"Error in auto_unmute_user for user {user_id} in group {group_id}: {str(e)}")

async def lock_time_messages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Lock group for specified time duration"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند از این دستور استفاده کنند.")
            return

        if not context.args:
            await update.message.reply_text(
                "استفاده: /locktime <مدت به ثانیه>\n"
                "مثال: /locktime 3600 (قفل برای 1 ساعت)\n"
                "یا: قفل_زمانی 1800 (قفل برای 30 دقیقه)"
            )
            return

        try:
            duration = int(context.args[0])
            if duration <= 0 or duration > 86400:  # Max 24 hours
                await update.message.reply_text("مدت زمان باید بین 1 تا 86400 ثانیه (24 ساعت) باشد.")
                return
        except ValueError:
            await update.message.reply_text("لطفاً یک عدد معتبر وارد کنید.")
            return

        group_id = update.effective_chat.id

        # Set group permissions to read-only
        permissions = ChatPermissions(
            can_send_messages=False,
            can_send_polls=False,
            can_send_other_messages=False,
            can_add_web_page_previews=False,
            can_change_info=False,
            can_invite_users=False,
            can_pin_messages=False,
            can_send_audios=False,
            can_send_documents=False,
            can_send_photos=False,
            can_send_videos=False,
            can_send_video_notes=False,
            can_send_voice_notes=False
        )

        await context.bot.set_chat_permissions(group_id, permissions)

        # Store lock info
        unlock_time = datetime.now() + timedelta(seconds=duration)
        locked_groups[group_id] = {
            'unlock_time': unlock_time,
            'locked_by': update.effective_user.id,
            'locked_by_name': update.effective_user.first_name
        }

        # Schedule unlock
        asyncio.create_task(auto_unlock_group(context, group_id, duration))

        hours = duration // 3600
        minutes = (duration % 3600) // 60
        seconds = duration % 60

        time_str = ""
        if hours > 0:
            time_str += f"{hours} ساعت "
        if minutes > 0:
            time_str += f"{minutes} دقیقه "
        if seconds > 0:
            time_str += f"{seconds} ثانیه"

        await update.message.reply_text(
            f"🔒 گروه برای {time_str} قفل شد.\n"
            f"⏰ باز شدن خودکار: {unlock_time.strftime('%H:%M:%S')}\n"
            f"👤 قفل شده توسط: {update.effective_user.first_name}"
        )

        logger.info(f"Group {group_id} locked for {duration} seconds by user {update.effective_user.id}")

    except Exception as e:
        logger.error(f"Error in lock_time_messages: {str(e)}")
        await update.message.reply_text(f"خطا در قفل کردن گروه: {str(e)}")

async def unlock_time_messages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unlock group manually"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند از این دستور استفاده کنند.")
            return

        group_id = update.effective_chat.id

        # حذف این بررسی تا دستور در هر حالتی کار کند
        # if group_id not in locked_groups:
        #     await update.message.reply_text("گروه قفل نیست.")
        #     return

        # Restore normal permissions
        permissions = ChatPermissions(
            can_send_messages=True,
            #   # این پارامتر دیگر پشتیبانی نمی‌شود
            can_send_polls=True,
            can_send_other_messages=True,
            can_add_web_page_previews=True,
            can_change_info=False,
            can_invite_users=True,
            can_pin_messages=False,
            # اضافه کردن پارامترهای جدید
            can_send_audios=True,
            can_send_documents=True,
            can_send_photos=True,
            can_send_videos=True,
            can_send_video_notes=True,
            can_send_voice_notes=True
        )

        await context.bot.set_chat_permissions(group_id, permissions)

        # Remove from locked groups if exists
        if group_id in locked_groups:
            del locked_groups[group_id]

        await update.message.reply_text(
            f"🔓 قفل گروه توسط {update.effective_user.first_name} باز شد."
        )

        logger.info(f"Group {group_id} unlocked manually by user {update.effective_user.id}")

    except Exception as e:
        logger.error(f"Error in unlock_time_messages: {str(e)}")
        await update.message.reply_text(f"خطا در باز کردن قفل گروه: {str(e)}")

async def auto_unlock_group(context: ContextTypes.DEFAULT_TYPE, group_id: int, duration: int):
    """Automatically unlock group after specified duration"""
    try:
        await asyncio.sleep(duration)

        if group_id in locked_groups:
            # Restore normal permissions
            permissions = ChatPermissions(
                can_send_messages=True,
                
                can_send_polls=True,
                can_send_other_messages=True,
                can_add_web_page_previews=True,
                can_change_info=False,
                can_invite_users=True,
                can_pin_messages=False
            )

            await context.bot.set_chat_permissions(group_id, permissions)

            # Send notification
            await context.bot.send_message(
                chat_id=group_id,
                text="🔓 قفل گروه به صورت خودکار باز شد."
            )

            # Remove from locked groups
            del locked_groups[group_id]

            logger.info(f"Group {group_id} auto-unlocked after {duration} seconds")

    except Exception as e:
        logger.error(f"Error in auto_unlock_group for group {group_id}: {str(e)}")

async def set_force_join(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set force join channel for group"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند از این دستور استفاده کنند.")
            return

        if not context.args:
            await update.message.reply_text(
                "استفاده: /forcejoin <channel_username>\n"
                "مثال: /forcejoin @mychannel\n"
                "یا: جوین_اجباری @mychannel"
            )
            return

        channel_username = context.args[0]
        if not channel_username.startswith('@'):
            channel_username = '@' + channel_username

        group_id = update.effective_chat.id

        # Test if channel exists and bot has access
        try:
            channel_info = await context.bot.get_chat(channel_username)
            force_join_channels[group_id] = {
                'channel_id': channel_info.id,
                'channel_username': channel_username,
                'channel_title': channel_info.title
            }

            await update.message.reply_text(
                f"✅ جوین اجباری چنل تنظیم شد.\n"
                f"📢 چنل: {channel_info.title} ({channel_username})\n"
                f"⚠️ کاربران باید عضو این چنل باشند تا بتوانند پیام ارسال کنند."
            )

            logger.info(f"Force join set for group {group_id} to channel {channel_username}")

        except Exception as e:
            await update.message.reply_text(
                f"❌ خطا در تنظیم جوین اجباری:\n"
                f"• چنل وجود ندارد یا عمومی نیست\n"
                f"• ربات عضو چنل نیست\n"
                f"• نام کاربری چنل اشتباه است\n\n"
                f"خطا: {str(e)}"
            )

    except Exception as e:
        logger.error(f"Error in set_force_join: {str(e)}")
        await update.message.reply_text(f"خطا در تنظیم جوین اجباری: {str(e)}")

async def unset_force_join(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Remove force join channel for group"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند از این دستور استفاده کنند.")
            return

        group_id = update.effective_chat.id

        if group_id not in force_join_channels:
            await update.message.reply_text("جوین اجباری برای این گروه تنظیم نشده است.")
            return

        channel_info = force_join_channels[group_id]
        del force_join_channels[group_id]

        await update.message.reply_text(
            f"✅ جوین اجباری حذف شد.\n"
            f"📢 چنل قبلی: {channel_info['channel_title']} ({channel_info['channel_username']})"
        )

        logger.info(f"Force join removed for group {group_id}")

    except Exception as e:
        logger.error(f"Error in unset_force_join: {str(e)}")
        await update.message.reply_text(f"خطا در حذف جوین اجباری: {str(e)}")

async def check_force_join_compliance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Check if user has joined required channel"""
    try:
        group_id = update.effective_chat.id

        if group_id not in force_join_channels:
            return

        user_id = update.effective_user.id
        channel_info = force_join_channels[group_id]

        # Check if user is member of required channel
        try:
            member_status = await context.bot.get_chat_member(
                channel_info['channel_id'],
                user_id
            )

            if member_status.status in ['left', 'kicked']:
                # Delete user's message
                await context.bot.delete_message(
                    chat_id=group_id,
                    message_id=update.message.message_id
                )

                # Send warning message
                warning_msg = await context.bot.send_message(
                    chat_id=group_id,
                    text=f"⚠️ {update.effective_user.first_name} عزیز!\n"
                         f"برای ارسال پیام در این گروه، ابتدا باید عضو چنل زیر شوید:\n\n"
                         f"📢 {channel_info['channel_title']}\n"
                         f"🔗 {channel_info['channel_username']}\n\n"
                         f"پس از عضویت، دوباره پیام خود را ارسال کنید."
                )

                # Delete warning message after 10 seconds
                asyncio.create_task(delete_message_after_delay(context, group_id, warning_msg.message_id, 10))

        except Exception as e:
            logger.error(f"Error checking force join compliance: {str(e)}")

    except Exception as e:
        logger.error(f"Error in check_force_join_compliance: {str(e)}")

async def delete_message_after_delay(context: ContextTypes.DEFAULT_TYPE, chat_id: int, message_id: int, delay: int):
    """Delete message after specified delay"""
    try:
        await asyncio.sleep(delay)
        await context.bot.delete_message(chat_id=chat_id, message_id=message_id)
    except Exception as e:
        logger.error(f"Error deleting message after delay: {str(e)}")


async def delete_service_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Delete service messages like join/leave notifications"""
    try:
        # Delete the service message
        await update.message.delete()
    except Exception as e:
        logger.error(f"Error in delete_service_message: {str(e)}")

async def premium_delete_service_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Delete service message with premium check"""
    if update.effective_chat.type == "private":
        return
    
    group_id = update.effective_chat.id
    
    # Check if group is premium
    
    # If premium, delete the service message
    return await delete_service_message(update, context)
