import time
import logging
from telegram import Update, ChatPermissions
from telegram.ext import ContextTypes, MessageHandler, filters, Application
from telegram.error import BadRequest
from config import ADMIN_ID
from handlers.royal_system import user_has_permission

logger = logging.getLogger(__name__)

async def mute_user_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Mute a user for a specified duration."""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return
        
        # Check if message text starts with "سکوت"
        if not update.message.text or not update.message.text.strip().startswith("سکوت"):
            return  # Not a mute command, ignore
        
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if not await user_has_permission(update, context, "moderate"):
            await update.message.reply_text("فقط ادمین‌های گروه یا مقام‌های مجاز می‌توانند از این دستور استفاده کنند.")
            return
        
        # Check if message is a reply
        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً این دستور را در پاسخ به پیام کاربر مورد نظر استفاده کنید.")
            return
        
        # Extract the command text
        command_text = update.message.text.strip()
        parts = command_text.split()
        
        # Check if the command is valid
        if len(parts) != 2 or parts[0] != "سکوت" or not parts[1].isdigit():
            await update.message.reply_text(
                "فرمت نادرست است. لطفاً از فرمت 'سکوت <مدت زمان>' استفاده کنید.\n"
                "مثال: سکوت 1800 (برای 30 دقیقه)"
            )
            return
        
        duration = int(parts[1])  # Get the duration in seconds
        
        # Validate duration (max 24 hours)
        if duration <= 0 or duration > 86400:
            await update.message.reply_text("مدت زمان باید بین 1 تا 86400 ثانیه (24 ساعت) باشد.")
            return
        
        user_to_mute = update.message.reply_to_message.from_user
        
        # Don't mute admins
        target_member = await context.bot.get_chat_member(update.effective_chat.id, user_to_mute.id)
        if target_member.status in ['administrator', 'creator']:
            await update.message.reply_text("نمی‌توان ادمین‌ها را سکوت کرد.")
            return
        
        # Don't mute the main admin
        if user_to_mute.id == ADMIN_ID:
            await update.message.reply_text("نمی‌توان ادمین اصلی را سکوت کرد.")
            return
        
        # Set chat permissions to mute the user
        permissions = ChatPermissions(
            can_send_messages=False,
            can_send_polls=False,
            can_send_other_messages=False,
            can_add_web_page_previews=False,
            can_change_info=False,
            can_invite_users=False,
            can_pin_messages=False
        )
        
        await context.bot.restrict_chat_member(
            chat_id=update.effective_chat.id,
            user_id=user_to_mute.id,
            permissions=permissions,
            until_date=int(time.time()) + duration  # Mute until the specified duration
        )
        
        # Format time display for user-friendly message
        hours = duration // 3600
        minutes = (duration % 3600) // 60
        seconds = duration % 60
        
        time_str = ""
        if hours > 0:
            time_str += f"{hours} ساعت "
        if minutes > 0:
            time_str += f"{minutes} دقیقه "
        if seconds > 0:
            time_str += f"{seconds} ثانیه"
        
        await update.message.reply_text(
            f"🔇 کاربر {user_to_mute.first_name} برای {time_str} سکوت شد.\n"
            f"👤 سکوت شده توسط: {update.effective_user.first_name}"
        )
        
        logger.info(f"User {user_to_mute.id} muted in group {update.effective_chat.id} for {duration} seconds by user {update.effective_user.id}")
        
    except Exception as e:
        logger.error(f"Error in mute_user_handler: {str(e)}")
        await update.message.reply_text(f"خطا در سکوت کردن کاربر: {str(e)}")

def register_mute_handler(application: Application):
    """Register the mute handler with the application."""
    # Add a message handler that checks for messages starting with "سکوت"
    application.add_handler(
        MessageHandler(
            filters.TEXT & filters.Regex(r"^سکوت \d+$") & ~filters.COMMAND,
            mute_user_handler
        )
    )
    logger.info("Mute handler registered")


async def promote_user_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Promote a user to administrator."""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return
        
        # Check if message text starts with "ارتقا"
        if not update.message.text or not update.message.text.strip().startswith("ارتقا"):
            return  # Not a promote command, ignore
        
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if not await user_has_permission(update, context, "moderate"):
            await update.message.reply_text("فقط ادمین‌های گروه یا مقام‌های مجاز می‌توانند از این دستور استفاده کنند.")
            return
        
        # Check if admin has promote permission
        if chat_member.status == 'administrator' and not chat_member.can_promote_members:
            await update.message.reply_text("شما دسترسی ارتقای کاربران به ادمین را ندارید.")
            return
        
        # Check if message is a reply
        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً این دستور را در پاسخ به پیام کاربر مورد نظر استفاده کنید.")
            return
        
        user_to_promote = update.message.reply_to_message.from_user
        
        # Don't promote the bot itself
        if user_to_promote.id == context.bot.id:
            await update.message.reply_text("نمی‌توان ربات را ارتقا داد.")
            return
        
        # Check if user is already an admin
        target_member = await context.bot.get_chat_member(update.effective_chat.id, user_to_promote.id)
        if target_member.status in ['administrator', 'creator']:
            await update.message.reply_text("این کاربر در حال حاضر ادمین است.")
            return
        
        # Promote the user with basic permissions
        await context.bot.promote_chat_member(
            chat_id=update.effective_chat.id,
            user_id=user_to_promote.id,
            can_delete_messages=True,
            can_restrict_members=True,
            can_invite_users=True,
            can_pin_messages=True,
            can_manage_video_chats=True
        )
        
        await update.message.reply_text(
            f"🎉 <b>ارتقای موفقیت‌آمیز!</b>\n\n"
            f"👑 <b>{user_to_promote.first_name}</b> اکنون ادمین گروه است\n"
            f"🔑 <b>دسترسی‌های جدید:</b>\n"
            f"   • حذف پیام‌ها\n"
            f"   • محدود کردن کاربران\n"
            f"   • دعوت کاربران جدید\n"
            f"   • پین کردن پیام‌ها\n"
            f"   • مدیریت ویدیو چت\n\n"
            f"👤 <b>ارتقا داده شده توسط:</b> {update.effective_user.first_name}",
            parse_mode='HTML'
        )
        
        logger.info(f"User {user_to_promote.id} promoted to admin in group {update.effective_chat.id} by user {update.effective_user.id}")
        
    except BadRequest as e:
        error_msg = str(e)
        if "not enough rights" in error_msg.lower():
            await update.message.reply_text("ربات دسترسی کافی برای ارتقا ندارد.")
        elif "user_not_mutual_contact" in error_msg.lower():
            await update.message.reply_text("کاربر با ربات در تماس نیست.")
        else:
            await update.message.reply_text(f"خطا در ارتقای کاربر: {error_msg}")
        logger.error(f"Error promoting user: {error_msg}")
    except Exception as e:
        await update.message.reply_text(f"خطا در ارتقای کاربر: {str(e)}")
        logger.error(f"Error promoting user: {str(e)}")

async def demote_user_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Demote an administrator to regular user."""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return
        
        # Check if message text starts with "عزل"
        if not update.message.text or not update.message.text.strip().startswith("عزل"):
            return  # Not a demote command, ignore
        
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if not await user_has_permission(update, context, "moderate"):
            await update.message.reply_text("فقط ادمین‌های گروه یا مقام‌های مجاز می‌توانند از این دستور استفاده کنند.")
            return
        
        # Check if admin has promote permission (needed for demote as well)
        if chat_member.status == 'administrator' and not chat_member.can_promote_members:
            await update.message.reply_text("شما دسترسی عزل ادمین‌ها را ندارید.")
            return
        
        # Check if message is a reply
        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً این دستور را در پاسخ به پیام کاربر مورد نظر استفاده کنید.")
            return
        
        user_to_demote = update.message.reply_to_message.from_user
        
        # Don't demote the bot itself
        if user_to_demote.id == context.bot.id:
            await update.message.reply_text("نمی‌توان ربات را عزل کرد.")
            return
        
        # Check if user is an admin
        target_member = await context.bot.get_chat_member(update.effective_chat.id, user_to_demote.id)
        if target_member.status not in ['administrator']:
            await update.message.reply_text("این کاربر ادمین نیست.")
            return
        
        # Don't demote the creator
        if target_member.status == 'creator':
            await update.message.reply_text("نمی‌توان سازنده گروه را عزل کرد.")
            return
        
        # Demote the user
        await context.bot.promote_chat_member(
            chat_id=update.effective_chat.id,
            user_id=user_to_demote.id,
            can_change_info=False,
            can_delete_messages=False,
            can_restrict_members=False,
            can_invite_users=False,
            can_pin_messages=False,
            can_promote_members=False,
            can_manage_video_chats=False,
            can_manage_topics=False
        )
        
        await update.message.reply_text(
            f"📉 <b>عزل انجام شد</b>\n\n"
            f"⬇️ <b>{user_to_demote.first_name}</b> از ادمینی گروه عزل شد\n"
            f"🔒 <b>دسترسی‌های حذف شده:</b>\n"
            f"   • حذف پیام‌ها\n"
            f"   • محدود کردن کاربران\n"
            f"   • دعوت کاربران\n"
            f"   • پین کردن پیام‌ها\n"
            f"   • مدیریت ویدیو چت\n\n"
            f"👤 <b>عزل شده توسط:</b> {update.effective_user.first_name}",
            parse_mode='HTML'
        )
        
        logger.info(f"User {user_to_demote.id} demoted from admin in group {update.effective_chat.id} by user {update.effective_user.id}")
        
    except BadRequest as e:
        error_msg = str(e)
        if "not enough rights" in error_msg.lower():
            await update.message.reply_text("ربات دسترسی کافی برای عزل ندارد.")
        elif "user_not_mutual_contact" in error_msg.lower():
            await update.message.reply_text("کاربر با ربات در تماس نیست.")
        else:
            await update.message.reply_text(f"خطا در عزل کاربر: {error_msg}")
        logger.error(f"Error demoting user: {error_msg}")
    except Exception as e:
        await update.message.reply_text(f"خطا در عزل کاربر: {str(e)}")
        logger.error(f"Error demoting user: {str(e)}")
async def special_user_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Give special permissions to a user."""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return
        
        # Check if message text starts with "ویژه"
        if not update.message.text or not update.message.text.strip().startswith("ویژه"):
            return  # Not a special command, ignore
        
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if not await user_has_permission(update, context, "moderate"):
            await update.message.reply_text("فقط ادمین‌های گروه یا مقام‌های مجاز می‌توانند از این دستور استفاده کنند.")
            return
        
        # Check if message is a reply
        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً این دستور را در پاسخ به پیام کاربر مورد نظر استفاده کنید.")
            return
        
        user_to_special = update.message.reply_to_message.from_user
        
        # Check if bot has admin permissions
        bot_member = await context.bot.get_chat_member(update.effective_chat.id, context.bot.id)
        if not bot_member.can_restrict_members:
            await update.message.reply_text("ربات دسترسی لازم برای تغییر دسترسی‌های کاربران را ندارد.")
            return
        
        # Set special permissions for the user
        permissions = ChatPermissions(
            can_send_messages=True,
            can_send_polls=True,
            can_send_other_messages=True,
            can_add_web_page_previews=True,
            can_change_info=False,
            can_invite_users=True,
            can_pin_messages=True
        )
        
        await context.bot.restrict_chat_member(
            chat_id=update.effective_chat.id,
            user_id=user_to_special.id,
            permissions=permissions
        )
        
        await update.message.reply_text(
            f"⭐ <b>دسترسی ویژه اعطا شد!</b>\n\n"
            f"✨ <b>{user_to_special.first_name}</b> دسترسی‌های ویژه دریافت کرد\n"
            f"🎯 <b>دسترسی‌های جدید:</b>\n"
            f"   • ارسال پیام‌ها\n"
            f"   • ارسال نظرسنجی\n"
            f"   • ارسال محتوای ویژه\n"
            f"   • دعوت کاربران\n"
            f"   • پین کردن پیام‌ها\n\n"
            f"👤 <b>تنظیم شده توسط:</b> {update.effective_user.first_name}",
            parse_mode='HTML'
        )
        
        logger.info(f"Special permissions given to user {user_to_special.id} in group {update.effective_chat.id} by user {update.effective_user.id}")
        
    except Exception as e:
        logger.error(f"Error in special_user_handler: {str(e)}")
        await update.message.reply_text(f"خطا در تنظیم دسترسی‌های ویژه: {str(e)}")

async def remove_special_user_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Remove special permissions from a user."""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return
        
        # Check if message text starts with "حذف ویژه"
        if not update.message.text or not update.message.text.strip().startswith("حذف ویژه"):
            return  # Not a remove special command, ignore
        
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if not await user_has_permission(update, context, "moderate"):
            await update.message.reply_text("فقط ادمین‌های گروه یا مقام‌های مجاز می‌توانند از این دستور استفاده کنند.")
            return
        
        # Check if message is a reply
        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً این دستور را در پاسخ به پیام کاربر مورد نظر استفاده کنید.")
            return
        
        user_to_remove_special = update.message.reply_to_message.from_user
        
        # Check if bot has admin permissions
        bot_member = await context.bot.get_chat_member(update.effective_chat.id, context.bot.id)
        if not bot_member.can_restrict_members:
            await update.message.reply_text("ربات دسترسی لازم برای تغییر دسترسی‌های کاربران را ندارد.")
            return
        
        # Get default chat permissions
        chat = await context.bot.get_chat(update.effective_chat.id)
        default_permissions = chat.permissions
        
        # Apply default permissions to the user
        await context.bot.restrict_chat_member(
            chat_id=update.effective_chat.id,
            user_id=user_to_remove_special.id,
            permissions=default_permissions
        )
        
        await update.message.reply_text(
            f"🚫 وضعیت ویژه کاربر {user_to_remove_special.first_name} حذف شد و به حالت عادی برگشت.\n"
            f"👤 حذف شده توسط: {update.effective_user.first_name}"
        )
        
        logger.info(f"Special status removed from user {user_to_remove_special.id} in group {update.effective_chat.id} by user {update.effective_user.id}")
        
    except Exception as e:
        logger.error(f"Error in remove_special_user_handler: {str(e)}")
        await update.message.reply_text(f"خطا در حذف وضعیت ویژه کاربر: {str(e)}")

def register_handlers(application: Application):
    """Register all moderation handlers with the application."""
    # Add a message handler that checks for messages starting with "سکوت"
    application.add_handler(
        MessageHandler(
            filters.TEXT & filters.Regex(r"^سکوت \d+$") & ~filters.COMMAND,
            mute_user_handler
        )
    )
    logger.info("Mute handler registered")


    # Add a message handler that checks for messages starting with "ارتقا"
    application.add_handler(
        MessageHandler(
            filters.TEXT & filters.Regex(r"^ارتقا$") & ~filters.COMMAND,
            promote_user_handler
        )
    )
    logger.info("Promote handler registered")


    # Add a message handler that checks for messages starting with "عزل"
    application.add_handler(
        MessageHandler(
            filters.TEXT & filters.Regex(r"^عزل$") & ~filters.COMMAND,
            demote_user_handler
        )
    )
    logger.info("Demote handler registered")


    # Add a message handler that checks for messages starting with "ویژه"
    application.add_handler(
        MessageHandler(
            filters.TEXT & filters.Regex(r"^ویژه$") & ~filters.COMMAND,
            special_user_handler
        )
    )
    logger.info("Special user handler registered")

    # Add a message handler for removing special status
    application.add_handler(
        MessageHandler(
            filters.TEXT & filters.Regex(r"^حذف ویژه$") & ~filters.COMMAND,
            remove_special_user_handler
        )
    )
