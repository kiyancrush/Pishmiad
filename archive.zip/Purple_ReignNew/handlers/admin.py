from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ChatPermissions
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
import sqlite3
from config import ADMIN_ID
from database.database import Database
import logging
from middleware.premium_check import is_premium_buyer
from database.premium import PremiumManager
from handlers.royal_system import user_has_permission
from datetime import datetime, timedelta  # اضافه کردن این خط

# Set up logger
logger = logging.getLogger(__name__)

# Initialize database
db = Database("group_manager.db")

async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show admin panel with available options."""
    try:
        premium_manager = PremiumManager("group_manager.db")
        is_admin = update.effective_user.id == ADMIN_ID
        is_buyer = False
        group_id = None
        
        # تشخیص محیط (گروه یا پرایوت)
        if update.effective_chat.type != "private":
            group_id = update.effective_chat.id
            is_buyer = is_premium_buyer(update.effective_user.id, group_id, premium_manager)
        
        # بررسی دسترسی
        royal_access = await user_has_permission(update, context, "admin_panel") if update.effective_chat.type != "private" else False
        if not is_admin and not is_buyer and not royal_access:
            await update.message.reply_text(
                "❌ شما دسترسی به پنل مدیریت ندارید!\n\n"
                "💡 برای دسترسی به پنل:\n"
                "🔹 باید سازنده ربات باشید\n"
                "🔹 یا خریدار اشتراک این گروه باشید\n"
                "🔹 یا یکی از مقام‌های مجاز باشید"
            )
            return
        
        keyboard = []
        
        # پنل ویژه خریداران اشتراک (فقط در گروه)
        if is_buyer and not is_admin and group_id:
            keyboard.append([InlineKeyboardButton("📊 آمار گروه", callback_data='buyer_stats'),
                             InlineKeyboardButton("⚠️ کاربران اخطار گرفته", callback_data='buyer_warned_users')])
            keyboard.append([InlineKeyboardButton("🚫 کاربران مسدود شده", callback_data='buyer_banned_users'),
                             InlineKeyboardButton("🔔 تنظیمات خوش‌آمدگویی", callback_data='buyer_welcome_settings')])
            keyboard.append([InlineKeyboardButton("🔒 قفل سرویس تلگرام", callback_data='buyer_telegram_service_lock'),
                             InlineKeyboardButton("📋 بررسی اشتراک", callback_data='check_subscription')])
            
            # ذخیره اطلاعات گروه در user_data برای استفاده در callback
            context.user_data['group_id'] = group_id
            context.user_data['is_admin'] = False
            context.user_data['is_buyer'] = True
            
            await update.message.reply_text(
                f"🎛️ <b>پنل مدیریت گروه</b>\n\n"
                f"👋 سلام <b>{update.effective_user.first_name}</b>!\n"
                f"💎 شما خریدار اشتراک این گروه هستید\n"
                f"🎯 <b>گروه:</b> {update.effective_chat.title}\n\n"
                f"📋 لطفاً یکی از گزینه‌های زیر را انتخاب کنید:",
                reply_markup=InlineKeyboardMarkup(keyboard),
                parse_mode='HTML'
            )
            return
        
        # پنل سازنده ربات
        if is_admin:
            # آمار گروه و کاربران
            keyboard.append([InlineKeyboardButton("📊 آمار ربات", callback_data='stats'),
                             InlineKeyboardButton("⚠️ کاربران اخطار گرفته", callback_data='warned_users')])
            keyboard.append([InlineKeyboardButton("🚫 کاربران مسدود شده", callback_data='banned_users'),
                             InlineKeyboardButton("🔔 تنظیمات خوش‌آمدگویی", callback_data='welcome_settings')])
            
            # مدیریت اشتراک‌ها
            keyboard.append([InlineKeyboardButton("💎 مدیریت گروه‌های پرمیوم", callback_data='premium_groups'),
                             InlineKeyboardButton("📢 ارسال پیام همگانی", callback_data='broadcast')])
            keyboard.append([InlineKeyboardButton("🔄 بروزرسانی کش", callback_data='refresh_cache')])
            
            # دکمه‌های مخصوص قفل سرویس تلگرام (اگر در گروه باشد)
            if group_id:
                keyboard.append([InlineKeyboardButton("🔒 قفل سرویس تلگرام", callback_data='telegram_service_lock')])
            
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            # ذخیره اطلاعات گروه در user_data برای استفاده در callback
            if group_id:
                context.user_data['group_id'] = group_id
            context.user_data['is_admin'] = is_admin
            context.user_data['is_buyer'] = is_buyer
            
            await update.message.reply_text(
                f"🔧 <b>پنل مدیریت سازنده</b>\n\n"
                f"👋 سلام <b>{update.effective_user.first_name}</b>!\n"
                f"👑 شما سازنده ربات هستید\n\n"
                f"📋 لطفاً یکی از گزینه‌های زیر را انتخاب کنید:",
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
            return
        
        # اگر به اینجا رسید، خطا داشته
        await update.message.reply_text("❌ خطا در تشخیص نوع کاربر.")
        
    except Exception as e:
        logger.error(f"Error in admin_panel: {str(e)}")
        await update.message.reply_text("❌ خطایی رخ داد. لطفا دوباره تلاش کنید.")

async def admin_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle admin panel button callbacks."""
    try:
        query = update.callback_query
        premium_manager = PremiumManager("group_manager.db")
        
        # بررسی دسترسی کاربر
        is_admin = update.effective_user.id == ADMIN_ID
        is_buyer = False
        group_id = context.user_data.get('group_id')
        
        if group_id:
            is_buyer = is_premium_buyer(update.effective_user.id, group_id, premium_manager)
        
        if not is_admin and not is_buyer:
            await query.answer("شما دسترسی به این بخش را ندارید!")
            return
        
        # بررسی دسترسی به بخش‌های مخصوص ادمین
        admin_only_sections = ['premium_groups', 'broadcast', 'refresh_cache', 'advanced_settings']
        if query.data in admin_only_sections and not is_admin:
            await query.answer("فقط ادمین اصلی می‌تواند به این بخش دسترسی داشته باشد!")
            return
        
        await query.answer()
        
        if query.data == 'stats':
            # نمایش آمار واقعی گروه
            conn = sqlite3.connect(db.db_name)
            c = conn.cursor()
            
            if is_admin and not group_id:
                # آمار کلی برای ادمین اصلی
                total_users = c.execute("SELECT COUNT(*) FROM users").fetchone()[0]
                warned_users = c.execute("SELECT COUNT(*) FROM users WHERE warnings > 0").fetchone()[0]
                banned_users = c.execute("SELECT COUNT(*) FROM users WHERE is_banned = 1").fetchone()[0]
                total_groups = c.execute("SELECT COUNT(*) FROM groups").fetchone()[0]
                premium_groups_count = c.execute("SELECT COUNT(*) FROM groups WHERE is_premium = 1").fetchone()[0]
                total_messages = c.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
                total_reports = c.execute("SELECT COUNT(*) FROM user_reports").fetchone()[0]
                pending_reports = c.execute("SELECT COUNT(*) FROM user_reports WHERE status = 'pending'").fetchone()[0]
                
                # محاسبه درصد گروه‌های پرمیوم
                premium_percentage = round((premium_groups_count / total_groups) * 100) if total_groups > 0 else 0
                premium_bar = generate_progress_bar(premium_percentage)
                
                stats_text = (
                    "📊 آمار کلی سیستم:\n\n"
                    f"👥 تعداد کل کاربران: {total_users:,}\n"
                    f"⚠️ کاربران اخطار گرفته: {warned_users:,} ({round((warned_users/total_users)*100) if total_users > 0 else 0}%)\n"
                    f"🚫 کاربران مسدود شده: {banned_users:,} ({round((banned_users/total_users)*100) if total_users > 0 else 0}%)\n\n"
                    f"👥 تعداد کل گروه‌ها: {total_groups:,}\n"
                    f"💎 گروه‌های پرمیوم: {premium_groups_count:,} ({premium_percentage}%)\n"
                    f"{premium_bar}\n\n"
                    f"💬 تعداد کل پیام‌ها: {total_messages:,}\n"
                    f"🔔 گزارش‌های کاربران: {total_reports:,} (در انتظار: {pending_reports:,})\n"
                )
                
                # دکمه‌های مدیریتی بیشتر
                keyboard = [
                    [InlineKeyboardButton("📈 نمودار فعالیت", callback_data='activity_chart')],
                    [InlineKeyboardButton("👥 گروه‌های فعال", callback_data='active_groups'),
                     InlineKeyboardButton("👤 کاربران فعال", callback_data='active_users')],
                    [InlineKeyboardButton("🔙 بازگشت", callback_data='back_to_main')]
                ]
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                await query.message.edit_text(stats_text, reply_markup=reply_markup)
            else:
                # آمار گروه فعلی برای خریدار یا ادمین
                if not group_id:
                    await query.message.edit_text("این دستور فقط در گروه قابل استفاده است.")
                    return
                
                # آمار واقعی گروه
                total_members = await context.bot.get_chat_member_count(group_id)
                admins_count = len(await context.bot.get_chat_administrators(group_id))
                
                # آمار پیام‌ها از دیتابیس
                total_messages = c.execute("SELECT COUNT(*) FROM messages WHERE group_id = ?", (group_id,)).fetchone()[0]
                unique_users = c.execute("SELECT COUNT(DISTINCT user_id) FROM messages WHERE group_id = ?", (group_id,)).fetchone()[0]
                
                # آمار اخطارها و بن‌ها
                warned_users = c.execute("SELECT COUNT(*) FROM warnings WHERE group_id = ?", (group_id,)).fetchone()[0]
                
                # آمار گزارش‌های کاربران
                total_reports = c.execute("SELECT COUNT(*) FROM user_reports WHERE group_id = ?", (group_id,)).fetchone()[0]
                pending_reports = c.execute("SELECT COUNT(*) FROM user_reports WHERE group_id = ? AND status = 'pending'", (group_id,)).fetchone()[0]
                
                # آمار پیام‌های هفته اخیر
                week_ago = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d %H:%M:%S")
                weekly_messages = c.execute("SELECT COUNT(*) FROM messages WHERE group_id = ? AND timestamp > ?", 
                                          (group_id, week_ago)).fetchone()[0]
                
                # محاسبه میانگین پیام روزانه
                daily_avg = round(weekly_messages / 7, 1) if weekly_messages > 0 else 0
                
                # محاسبه نسبت کاربران فعال به کل اعضا
                active_ratio = round((unique_users / total_members) * 100, 1) if total_members > 0 else 0
                activity_bar = generate_progress_bar(active_ratio)
                
                # اطلاعات اشتراک
                subscription_info = premium_manager.get_group_subscription_info(group_id)
                subscription_end = subscription_info['subscription_end'] if subscription_info else "ندارد"
                
                # محاسبه روزهای باقی‌مانده اشتراک
                days_left = "نامحدود"
                if subscription_end != "ندارد":
                    try:
                        end_date = datetime.strptime(subscription_end, "%Y-%m-%d")
                        days_left = (end_date - datetime.now()).days
                        if days_left < 0:
                            days_left = "منقضی شده"
                        else:
                            days_left = f"{days_left} روز"
                    except:
                        days_left = "نامشخص"
                
                stats_text = (
                    f"📊 آمار گروه {update.effective_chat.title}:\n\n"
                    f"👥 تعداد کل اعضا: {total_members:,}\n"
                    f"👮‍♂️ تعداد ادمین‌ها: {admins_count}\n"
                    f"💬 تعداد پیام‌های ثبت شده: {total_messages:,}\n"
                    f"📈 میانگین پیام روزانه: {daily_avg}\n"
                    f"👤 کاربران فعال: {unique_users:,} ({active_ratio}%)\n"
                    f"{activity_bar}\n"
                    f"⚠️ تعداد اخطارها: {warned_users:,}\n"
                    f"🔔 گزارش‌های کاربران: {total_reports:,} (در انتظار: {pending_reports})\n\n"
                    f"💎 وضعیت اشتراک: {'فعال ✅' if subscription_info else 'غیرفعال ❌'}\n"
                    f"📅 تاریخ پایان اشتراک: {subscription_end}\n"
                    f"⏳ زمان باقی‌مانده: {days_left}"
                )
                
                # دکمه‌های مدیریتی بیشتر
                keyboard = [
                    [InlineKeyboardButton("📊 گزارش هفتگی", callback_data=f'weekly_report_{group_id}')],
                    [InlineKeyboardButton("👤 کاربران فعال", callback_data=f'active_users_{group_id}'),
                     InlineKeyboardButton("⚠️ اخطارها", callback_data=f'warning_details_{group_id}')],
                    [InlineKeyboardButton("🔙 بازگشت", callback_data='back_to_main')]
                ]
                reply_markup = InlineKeyboardMarkup(keyboard)
                
                await query.message.edit_text(stats_text, reply_markup=reply_markup)
            
            conn.close()
        
        # Callback های ویژه خریداران
        elif query.data == 'buyer_stats':
            # همان کد آمار گروه اما فقط برای گروه خریدار
            await admin_callback(update, context)  # استفاده مجدد از stats
            
        elif query.data == 'buyer_warned_users':
            # کاربران اخطار گرفته در گروه خریدار
            await query.message.edit_text("⚠️ در حال بارگذاری لیست کاربران اخطار گرفته...")
            # پیاده‌سازی نمایش کاربران اخطار گرفته
            
        elif query.data == 'buyer_banned_users':
            # کاربران مسدود شده در گروه خریدار
            await query.message.edit_text("🚫 در حال بارگذاری لیست کاربران مسدود شده...")
            # پیاده‌سازی نمایش کاربران مسدود شده
            
        elif query.data == 'buyer_welcome_settings':
            # تنظیمات خوش‌آمدگویی برای خریدار
            keyboard = [
                [InlineKeyboardButton("فعال کردن خوش‌آمدگویی", callback_data='welcome_on')],
                [InlineKeyboardButton("غیرفعال کردن خوش‌آمدگویی", callback_data='welcome_off')],
                [InlineKeyboardButton("🔙 بازگشت", callback_data='back_to_main')]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.message.edit_text(
                "🔔 <b>تنظیمات خوش‌آمدگویی</b>\n\n"
                "📋 لطفاً یک گزینه را انتخاب کنید:",
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
            
        elif query.data == 'buyer_telegram_service_lock':
            # منوی قفل سرویس‌های تلگرام برای خریدار
            keyboard = [
                [InlineKeyboardButton("🔒 قفل عکس", callback_data='lock_photo')],
                [InlineKeyboardButton("🔒 قفل ویدیو", callback_data='lock_video')],
                [InlineKeyboardButton("🔒 قفل فایل", callback_data='lock_document')],
                [InlineKeyboardButton("🔒 قفل گیف", callback_data='lock_animation')],
                [InlineKeyboardButton("🔒 حذف پیام ورود اعضا", callback_data='lock_new_members')],
                [InlineKeyboardButton("🔒 حذف پیام اد شدن", callback_data='lock_join_messages')],
                [InlineKeyboardButton("🔒 حذف پیام پین", callback_data='lock_pin_messages')],
                [InlineKeyboardButton("🔒 حذف پیام‌های ویدیو چت", callback_data='lock_video_chat_messages')],
                [InlineKeyboardButton("🔓 باز کردن همه قفل‌ها", callback_data='unlock_all')],
                [InlineKeyboardButton("🔙 بازگشت", callback_data='back_to_main')]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.message.edit_text(
                "🔒 <b>قفل سرویس‌های تلگرام</b>\n\n"
                "📋 لطفاً یکی از گزینه‌های زیر را انتخاب کنید:",
                reply_markup=reply_markup,
                parse_mode='HTML'
            )
        
        elif query.data == 'warned_users':
            # Show users with warnings
            conn = sqlite3.connect(db.db_name)
            c = conn.cursor()
            warned = c.execute("SELECT user_id, username, warnings FROM users WHERE warnings > 0").fetchall()
            
            if not warned:
                await query.message.edit_text("هیچ کاربری اخطار ندارد.")
                return
                
            text = "⚠️ لیست کاربران اخطار گرفته:\n\n"
            for user_id, username, warnings in warned:
                text += f"👤 {username or user_id}\n"
                text += f"تعداد اخطار: {warnings}\n\n"
            
            await query.message.edit_text(text)
        
        elif query.data == 'banned_users':
            # Show banned users
            conn = sqlite3.connect(db.db_name)
            c = conn.cursor()
            banned = c.execute("SELECT user_id, username FROM users WHERE is_banned = 1").fetchall()
            
            if not banned:
                await query.message.edit_text("هیچ کاربری مسدود نشده است.")
                return
                
            text = "🚫 لیست کاربران مسدود شده:\n\n"
            for user_id, username in banned:
                text += f"👤 {username or user_id}\n"
            
            await query.message.edit_text(text)
        
        elif query.data == 'welcome_settings':
            keyboard = [
                [InlineKeyboardButton("فعال کردن خوش‌آمدگویی", callback_data='welcome_on')],
                [InlineKeyboardButton("غیرفعال کردن خوش‌آمدگویی", callback_data='welcome_off')],
                [InlineKeyboardButton("بازگشت به منوی اصلی", callback_data='back_to_main')]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.message.edit_text(
                "تنظیمات خوش‌آمدگویی:\n"
                "لطفاً یک گزینه را انتخاب کنید:",
                reply_markup=reply_markup
            )
        
        elif query.data == 'premium_groups':
            # Show premium groups list and management options
            premium_groups = db.get_premium_groups()
            
            if not premium_groups:
                text = "هیچ گروه پرمیومی وجود ندارد."
            else:
                text = "📊 لیست گروه‌های پرمیوم:\n\n"
                for group_id, title, added_by, added_date in premium_groups:
                    text += f"📌 {title or group_id}\n"
                    text += f"📅 تاریخ افزودن: {added_date}\n\n"
            
            keyboard = [
                [InlineKeyboardButton("افزودن گروه به لیست پرمیوم", callback_data='add_premium')],
                [InlineKeyboardButton("حذف گروه از لیست پرمیوم", callback_data='remove_premium')],
                [InlineKeyboardButton("بازگشت به منوی اصلی", callback_data='back_to_main')]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await query.message.edit_text(text, reply_markup=reply_markup)
            
        elif query.data == 'add_premium':
            # Add current group to premium list
            if update.effective_chat.type != "private":
                group_id = update.effective_chat.id
                group_title = update.effective_chat.title
                db.add_group(group_id, group_title, update.effective_user.id)
                db.set_group_premium(group_id, True)
                await query.message.edit_text(
                    f"✅ گروه {group_title} به لیست پرمیوم اضافه شد.",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("بازگشت", callback_data='premium_groups')
                    ]])
                )
            else:
                await query.message.edit_text(
                    "❌ این دستور فقط در گروه قابل استفاده است.",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("بازگشت", callback_data='premium_groups')
                    ]])
                )
                
        elif query.data == 'remove_premium':
            # Remove current group from premium list
            if update.effective_chat.type != "private":
                group_id = update.effective_chat.id
                db.set_group_premium(group_id, False)
                await query.message.edit_text(
                    "✅ گروه از لیست پرمیوم حذف شد.",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("بازگشت", callback_data='premium_groups')
                    ]])
                )
            else:
                await query.message.edit_text(
                    "❌ این دستور فقط در گروه قابل استفاده است.",
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("بازگشت", callback_data='premium_groups')
                    ]])
                )
                
        elif query.data == 'telegram_service_lock':
            # نمایش منوی قفل سرویس‌های تلگرام
            keyboard = [
                [InlineKeyboardButton("🔒 قفل عکس", callback_data='lock_photo')],
                [InlineKeyboardButton("🔒 قفل ویدیو", callback_data='lock_video')],
                [InlineKeyboardButton("🔒 قفل فایل", callback_data='lock_document')],
                [InlineKeyboardButton("🔒 قفل گیف", callback_data='lock_animation')],
                [InlineKeyboardButton("🔒 حذف پیام ورود اعضا", callback_data='lock_new_members')],
                [InlineKeyboardButton("🔒 حذف پیام اد شدن", callback_data='lock_join_messages')],
                [InlineKeyboardButton("🔒 حذف پیام پین", callback_data='lock_pin_messages')],
                [InlineKeyboardButton("🔒 حذف پیام‌های ویدیو چت", callback_data='lock_video_chat_messages')],
                [InlineKeyboardButton("🔓 باز کردن همه قفل‌ها", callback_data='unlock_all')],
                [InlineKeyboardButton("بازگشت به منوی اصلی", callback_data='back_to_main')]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.message.edit_text(
                "🔒 قفل سرویس‌های تلگرام:\n"
                "لطفاً یکی از گزینه‌های زیر را انتخاب کنید:",
                reply_markup=reply_markup
            )
        
        elif query.data == 'lock_photo':
            if not group_id:
                await query.message.edit_text("این دستور فقط در گروه قابل استفاده است.")
                return
                
            # قفل کردن ارسال عکس
            permissions = ChatPermissions(
                can_send_messages=True,
                can_send_photos=False,
                can_send_videos=True,
                can_send_documents=True,
                can_send_audios=True,
                can_send_polls=True,
                can_send_other_messages=True,
                can_add_web_page_previews=True,
                can_change_info=False,
                can_invite_users=True,
                can_pin_messages=False
            )
            
            await context.bot.set_chat_permissions(group_id, permissions)
            await query.message.edit_text(
                "✅ قفل عکس فعال شد. کاربران نمی‌توانند عکس ارسال کنند.",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("بازگشت", callback_data='telegram_service_lock')
                ]])
            )
        
        elif query.data == 'lock_video':
            if not group_id:
                await query.message.edit_text("این دستور فقط در گروه قابل استفاده است.")
                return
                
            # قفل کردن ارسال ویدیو
            permissions = ChatPermissions(
                can_send_messages=True,
                can_send_photos=True,
                can_send_videos=False,
                can_send_documents=True,
                can_send_audios=True,
                can_send_polls=True,
                can_send_other_messages=True,
                can_add_web_page_previews=True,
                can_change_info=False,
                can_invite_users=True,
                can_pin_messages=False
            )
            
            await context.bot.set_chat_permissions(group_id, permissions)
            await query.message.edit_text(
                "✅ قفل ویدیو فعال شد. کاربران نمی‌توانند ویدیو ارسال کنند.",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("بازگشت", callback_data='telegram_service_lock')
                ]])
            )
            
        elif query.data == 'lock_document':
            if not group_id:
                await query.message.edit_text("این دستور فقط در گروه قابل استفاده است.")
                return
                
            # قفل کردن ارسال فایل
            permissions = ChatPermissions(
                can_send_messages=True,
                can_send_photos=True,
                can_send_videos=True,
                can_send_documents=False,
                can_send_audios=True,
                can_send_polls=True,
                can_send_other_messages=True,
                can_add_web_page_previews=True,
                can_change_info=False,
                can_invite_users=True,
                can_pin_messages=False
            )
            
            await context.bot.set_chat_permissions(group_id, permissions)
            await query.message.edit_text(
                "✅ قفل فایل فعال شد. کاربران نمی‌توانند فایل ارسال کنند.",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("بازگشت", callback_data='telegram_service_lock')
                ]])
            )
            
        elif query.data == 'lock_animation':
            if not group_id:
                await query.message.edit_text("این دستور فقط در گروه قابل استفاده است.")
                return
                
            # قفل کردن ارسال گیف
            permissions = ChatPermissions(
                can_send_messages=True,
                can_send_photos=True,
                can_send_videos=True,
                can_send_documents=True,
                can_send_audios=True,
                can_send_polls=True,
                can_send_other_messages=False,  # این گزینه برای گیف‌ها و استیکرها استفاده می‌شود
                can_add_web_page_previews=True,
                can_change_info=False,
                can_invite_users=True,
                can_pin_messages=False
            )
            
            await context.bot.set_chat_permissions(group_id, permissions)
            await query.message.edit_text(
                "✅ قفل گیف فعال شد. کاربران نمی‌توانند گیف ارسال کنند.",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("بازگشت", callback_data='telegram_service_lock')
                ]])
            )
            
        elif query.data == 'unlock_all':
            if not group_id:
                await query.message.edit_text("این دستور فقط در گروه قابل استفاده است.")
                return
                
            # باز کردن همه قفل‌ها
            permissions = ChatPermissions(
                can_send_messages=True,
                can_send_photos=True,
                can_send_videos=True,
                can_send_documents=True,
                can_send_audios=True,
                can_send_polls=True,
                can_send_other_messages=True,
                can_add_web_page_previews=True,
                can_change_info=False,
                can_invite_users=True,
                can_pin_messages=False
            )
            
            # غیرفعال کردن قفل‌های دیگر در دیتابیس
            conn = sqlite3.connect(db.db_name)
            c = conn.cursor()
            c.execute("UPDATE groups SET delete_new_members = 0, delete_join_messages = 0, delete_pin_messages = 0, delete_video_chat_messages = 0 WHERE group_id = ?", (group_id,))
            conn.commit()
            conn.close()
            
            await context.bot.set_chat_permissions(group_id, permissions)
            await query.message.edit_text(
                "✅ همه قفل‌های سرویس باز شدند. کاربران می‌توانند همه نوع محتوا ارسال کنند و قفل‌های پیام ورود و اد شدن نیز غیرفعال شدند.",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("بازگشت", callback_data='telegram_service_lock')
                ]])
            )
            
        elif query.data == 'lock_new_members':
            if not group_id:
                await query.message.edit_text("این دستور فقط در گروه قابل استفاده است.")
                return
                
            # فعال/غیرفعال حذف پیام ورود اعضا
            conn = sqlite3.connect(db.db_name)
            c = conn.cursor()
            
            # بررسی وضعیت فعلی
            c.execute("SELECT delete_new_members FROM groups WHERE group_id = ?", (group_id,))
            result = c.fetchone()
            current_status = result[0] if result and result[0] is not None else 0
            
            # تغییر وضعیت
            new_status = 0 if current_status else 1
            c.execute("UPDATE groups SET delete_new_members = ? WHERE group_id = ?", (new_status, group_id))
            conn.commit()
            conn.close()
            
            status_text = "فعال" if new_status else "غیرفعال"
            await query.message.edit_text(
                f"✅ حذف پیام ورود اعضا {status_text} شد.",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("بازگشت", callback_data='telegram_service_lock')
                ]])
            )
            
        elif query.data == 'lock_join_messages':
            if not group_id:
                await query.message.edit_text("این دستور فقط در گروه قابل استفاده است.")
                return
                
            # فعال/غیرفعال کردن حذف پیام اد شدن
            conn = sqlite3.connect(db.db_name)
            c = conn.cursor()
            
            # بررسی وضعیت فعلی
            c.execute("SELECT delete_join_messages FROM groups WHERE group_id = ?", (group_id,))
            result = c.fetchone()
            current_status = result[0] if result and result[0] is not None else 0
            
            # تغییر وضعیت
            new_status = 0 if current_status else 1
            c.execute("UPDATE groups SET delete_join_messages = ? WHERE group_id = ?", (new_status, group_id))
            conn.commit()
            conn.close()
            
            status_text = "فعال" if new_status else "غیرفعال"
            await query.message.edit_text(
                f"✅ حذف پیام اد شدن {status_text} شد.",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("بازگشت", callback_data='telegram_service_lock')
                ]])
            )
            
        elif query.data == 'lock_pin_messages':
            if not group_id:
                await query.message.edit_text("این دستور فقط در گروه قابل استفاده است.")
                return
                
            # فعال/غیرفعال کردن حذف پیام پین
            conn = sqlite3.connect(db.db_name)
            c = conn.cursor()
            
            # بررسی وضعیت فعلی
            c.execute("SELECT delete_pin_messages FROM groups WHERE group_id = ?", (group_id,))
            result = c.fetchone()
            current_status = result[0] if result and result[0] is not None else 0
            
            # تغییر وضعیت
            new_status = 0 if current_status else 1
            c.execute("UPDATE groups SET delete_pin_messages = ? WHERE group_id = ?", (new_status, group_id))
            conn.commit()
            conn.close()
            
            status_text = "فعال" if new_status else "غیرفعال"
            await query.message.edit_text(
                f"✅ حذف پیام پین {status_text} شد.",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("بازگشت", callback_data='telegram_service_lock')
                ]])
            )
            
        elif query.data == 'lock_video_chat_messages':
            if not group_id:
                await query.message.edit_text("این دستور فقط در گروه قابل استفاده است.")
                return
                
            # فعال/غیرفعال کردن حذف پیام‌های ویدیو چت
            conn = sqlite3.connect(db.db_name)
            c = conn.cursor()
            
            # بررسی وضعیت فعلی
            c.execute("SELECT delete_video_chat_messages FROM groups WHERE group_id = ?", (group_id,))
            result = c.fetchone()
            current_status = result[0] if result and result[0] is not None else 0
            
            # تغییر وضعیت
            new_status = 0 if current_status else 1
            c.execute("UPDATE groups SET delete_video_chat_messages = ? WHERE group_id = ?", (new_status, group_id))
            conn.commit()
            conn.close()
            
            status_text = "فعال" if new_status else "غیرفعال"
            await query.message.edit_text(
                f"✅ حذف پیام‌های ویدیو چت {status_text} شد.",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("بازگشت", callback_data='telegram_service_lock')
                ]])
            )
            
        elif query.data == 'broadcast':
            # نمایش فرم ارسال پیام همگانی
            await query.message.edit_text(
                "📢 ارسال پیام همگانی:\n\n"
                "برای ارسال پیام همگانی به تمام گروه‌های پرمیوم، از دستور زیر استفاده کنید:\n\n"
                "`/broadcast متن پیام`\n\n"
                "این پیام به تمام گروه‌های پرمیوم فعال ارسال خواهد شد.",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("بازگشت به منوی اصلی", callback_data='back_to_main')
                ]])
            )
            
    except Exception as e:
        logger.error(f"Error in admin_callback: {str(e)}")
        await query.message.edit_text("خطایی رخ داد. لطفا دوباره تلاش کنید.")

# در انتهای فایل اضافه کنید
def generate_progress_bar(percentage, length=10):
    """ایجاد نوار پیشرفت متنی با درصد مشخص"""
    filled = int(percentage / 100 * length)
    bar = '█' * filled + '░' * (length - filled)
    return f"[{bar}] {percentage}%"
