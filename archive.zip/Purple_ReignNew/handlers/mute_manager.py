import logging
import asyncio
from datetime import datetime, timedelta
from telegram import Update, ChatPermissions
from telegram.ext import ContextTypes
from telegram.error import TelegramError, BadRequest, Forbidden
from config import ADMIN_ID

logger = logging.getLogger(__name__)

# Global dictionary to store muted users
muted_users = {}  # {group_id: {user_id: {'until': datetime, 'task': asyncio.Task}}}

async def mute_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Mute user for specified time duration"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند از این دستور استفاده کنند.")
            return

        # Check if message is a reply
        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً این دستور را در پاسخ به پیام کاربر مورد نظر استفاده کنید.")
            return

        # Log the context args for debugging
        logger.info(f"Mute command context args: {context.args}")

        if not context.args:
            await update.message.reply_text(
                "استفاده: سکوت <مدت به ثانیه>\n"
                "مثال: سکوت 1800 (سکوت برای 30 دقیقه)\n"
                "حداکثر: 86400 ثانیه (24 ساعت)"
            )
            return

        try:
            duration = int(context.args[0])
            if duration <= 0 or duration > 86400:  # Max 24 hours
                await update.message.reply_text("مدت زمان باید بین 1 تا 86400 ثانیه (24 ساعت) باشد.")
                return
        except ValueError:
            await update.message.reply_text("لطفاً یک عدد معتبر وارد کنید.")
            return

        user_to_mute = update.message.reply_to_message.from_user
        group_id = update.effective_chat.id

        # Don't mute admins
        target_member = await context.bot.get_chat_member(group_id, user_to_mute.id)
        if target_member.status in ['administrator', 'creator']:
            await update.message.reply_text("نمی‌توان ادمین‌ها را سکوت کرد.")
            return

        # Don't mute the main admin
        if user_to_mute.id == ADMIN_ID:
            await update.message.reply_text("نمی‌توان ادمین اصلی را سکوت کرد.")
            return

        # Set user permissions to muted
        mute_permissions = ChatPermissions(
            can_send_messages=False,
            can_send_polls=False,
            can_send_other_messages=False,
            can_add_web_page_previews=False,
            can_send_audios=False,
            can_send_documents=False,
            can_send_photos=False,
            can_send_videos=False,
            can_send_video_notes=False,
            can_send_voice_notes=False
        )

        # Calculate unmute time
        unmute_time = datetime.now() + timedelta(seconds=duration)

        # Restrict user
        await context.bot.restrict_chat_member(
            chat_id=group_id,
            user_id=user_to_mute.id,
            permissions=mute_permissions,
            until_date=unmute_time
        )

        # Store mute info
        if group_id not in muted_users:
            muted_users[group_id] = {}

        # Cancel previous mute task if exists
        if user_to_mute.id in muted_users[group_id]:
            old_task = muted_users[group_id][user_to_mute.id].get('task')
            if old_task and not old_task.done():
                old_task.cancel()

        # Create auto-unmute task
        unmute_task = asyncio.create_task(
            auto_unmute_user(context, group_id, user_to_mute.id, duration)
        )

        muted_users[group_id][user_to_mute.id] = {
            'until': unmute_time,
            'muted_by': update.effective_user.id,
            'muted_by_name': update.effective_user.first_name,
            'task': unmute_task
        }

        # Format time display
        hours = duration // 3600
        minutes = (duration % 3600) // 60
        seconds = duration % 60

        time_str = ""
        if hours > 0:
            time_str += f"{hours} ساعت "
        if minutes > 0:
            time_str += f"{minutes} دقیقه "
        if seconds > 0:
            time_str += f"{seconds} ثانیه"

        await update.message.reply_text(
            f"🔇 کاربر {user_to_mute.first_name} برای {time_str} سکوت شد.\n"
            f"⏰ باز شدن خودکار: {unmute_time.strftime('%H:%M:%S')}\n"
            f"👤 سکوت شده توسط: {update.effective_user.first_name}"
        )

        logger.info(f"User {user_to_mute.id} muted in group {group_id} for {duration} seconds by user {update.effective_user.id}")

    except BadRequest as e:
        if "not enough rights" in str(e).lower():
            await update.message.reply_text("ربات دسترسی کافی برای سکوت کردن کاربران ندارد.")
        else:
            await update.message.reply_text(f"خطا در سکوت کردن کاربر: {str(e)}")
        logger.error(f"BadRequest in mute_user: {str(e)}")
    except Forbidden as e:
        await update.message.reply_text("ربات مسدود شده یا دسترسی ندارد.")
        logger.error(f"Forbidden in mute_user: {str(e)}")
    except Exception as e:
        logger.error(f"Error in mute_user: {str(e)}")
        await update.message.reply_text(f"خطا در سکوت کردن کاربر: {str(e)}")

async def unmute_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unmute user manually"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند از این دستور استفاده کنند.")
            return

        # Check if message is a reply
        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً این دستور را در پاسخ به پیام کاربر مورد نظر استفاده کنید.")
            return

        user_to_unmute = update.message.reply_to_message.from_user
        group_id = update.effective_chat.id

        # Restore normal permissions
        normal_permissions = ChatPermissions(
            can_send_messages=True,
            can_send_polls=True,
            can_send_other_messages=True,
            can_add_web_page_previews=True,
            can_send_audios=True,
            can_send_documents=True,
            can_send_photos=True,
            can_send_videos=True,
            can_send_video_notes=True,
            can_send_voice_notes=True
        )

        await context.bot.restrict_chat_member(
            chat_id=group_id,
            user_id=user_to_unmute.id,
            permissions=normal_permissions
        )

        # Check if user is in muted list and remove
        if group_id in muted_users and user_to_unmute.id in muted_users[group_id]:
            # Cancel auto-unmute task
            mute_info = muted_users[group_id][user_to_unmute.id]
            if 'task' in mute_info and not mute_info['task'].done():
                mute_info['task'].cancel()

            # Remove from muted users
            del muted_users[group_id][user_to_unmute.id]
            if not muted_users[group_id]:
                del muted_users[group_id]

        await update.message.reply_text(f"🔊 کاربر {user_to_unmute.first_name} از حالت سکوت خارج شد.")

        logger.info(f"User {user_to_unmute.id} unmuted manually in group {group_id}")

    except Exception as e:
        logger.error(f"Error in unmute_user: {str(e)}")
        await update.message.reply_text(f"خطا در خارج کردن کاربر از حالت سکوت: {str(e)}")

async def auto_unmute_user(context: ContextTypes.DEFAULT_TYPE, group_id: int, user_id: int, duration: int):
    """Automatically unmute user after specified duration"""
    try:
        await asyncio.sleep(duration)

        if group_id in muted_users and user_id in muted_users[group_id]:
            # Restore normal permissions
            normal_permissions = ChatPermissions(
                can_send_messages=True,
                can_send_polls=True,
                can_send_other_messages=True,
                can_add_web_page_previews=True,
                can_send_audios=True,
                can_send_documents=True,
                can_send_photos=True,
                can_send_videos=True,
                can_send_video_notes=True,
                can_send_voice_notes=True
            )

            await context.bot.restrict_chat_member(
                chat_id=group_id,
                user_id=user_id,
                permissions=normal_permissions
            )

            # Get user info for notification
            try:
                user_info = await context.bot.get_chat_member(group_id, user_id)
                user_name = user_info.user.first_name
            except:
                user_name = "کاربر"

            # Send notification
            await context.bot.send_message(
                chat_id=group_id,
                text=f"🔊 سکوت کاربر {user_name} به صورت خودکار برداشته شد."
            )

            # Remove from muted users
            del muted_users[group_id][user_id]
            if not muted_users[group_id]:
                del muted_users[group_id]

            logger.info(f"User {user_id} auto-unmuted in group {group_id} after {duration} seconds")

    except Exception as e:
        logger.error(f"Error in auto_unmute_user for user {user_id} in group {group_id}: {str(e)}")