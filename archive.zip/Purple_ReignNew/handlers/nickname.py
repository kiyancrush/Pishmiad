import logging
from telegram import Update
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from config import ADMIN_ID
from database.database import Database

# تنظیم لاگر
logger = logging.getLogger(__name__)

# مقداردهی اولیه دیتابیس
db = Database("group_manager.db")

async def set_nickname_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """تنظیم لقب برای کاربر و تغییر title در گروه"""
    try:
        # بررسی می‌کنیم که آیا پیام در گروه ارسال شده است
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return
        
        # بررسی می‌کنیم که آیا کاربر ادمین است
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند از این دستور استفاده کنند.")
            return
        
        # بررسی می‌کنیم که آیا پیام در پاسخ به پیام دیگری است
        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً این دستور را در پاسخ به پیام کاربر مورد نظر استفاده کنید.")
            return
        
        # Extract nickname from arguments or message text
        nickname = None
        
        # If called from handle_persian_commands, use context.args
        if hasattr(context, 'args') and context.args:
            nickname = ' '.join(context.args)
        else:
            # Fallback: extract from message text (for backward compatibility)
            command_text = update.message.text.strip()
            parts = command_text.split(" ", 2)  # حداکثر به 3 بخش تقسیم می‌کنیم
            
            if len(parts) >= 3 and parts[0] == "تنظیم" and parts[1] == "لقب":
                nickname = parts[2]
        
        if not nickname:
            await update.message.reply_text(
                "فرمت نادرست است. لطفاً از فرمت 'تنظیم لقب <لقب>' استفاده کنید.\n"
                "مثال: تنظیم لقب مهندس"
            )
            return
        
        target_user = update.message.reply_to_message.from_user
        
        # بررسی اینکه آیا کاربر هدف ادمین است
        target_chat_member = await context.bot.get_chat_member(update.effective_chat.id, target_user.id)
        if target_chat_member.status not in ['administrator', 'creator']:
            await update.message.reply_text("فقط می‌توان title ادمین‌ها را تغییر داد.")
            return
        
        # بررسی اینکه آیا ربات مجوز تنظیم title ادمین‌ها را دارد
        bot_member = await context.bot.get_chat_member(update.effective_chat.id, context.bot.id)
        if not bot_member.can_promote_members:
            await update.message.reply_text("ربات دسترسی لازم برای تغییر title ادمین‌ها را ندارد.")
            return
        
        # تنظیم custom title برای ادمین
        try:
            await context.bot.set_chat_administrator_custom_title(
                chat_id=update.effective_chat.id,
                user_id=target_user.id,
                custom_title=nickname
            )
            
            # تنظیم لقب در دیتابیس نیز
            db.set_user_nickname(target_user.id, update.effective_chat.id, nickname, update.effective_user.id)
            
            # ارسال پیام تأیید
            await update.message.reply_text(
                f"🎖️ <b>تغییر لقب موفقیت‌آمیز!</b>\n\n"
                f"👤 <b>{target_user.first_name}</b>\n"
                f"🏷️ <b>لقب جدید:</b> «{nickname}»\n"
                f"✅ <b>وضعیت:</b> Title گروه به‌روزرسانی شد\n\n"
                f"👤 <b>تنظیم شده توسط:</b> {update.effective_user.first_name}",
                parse_mode=ParseMode.HTML
            )
            
            logger.info(f"Nickname and title set for user {target_user.id} to '{nickname}' in chat {update.effective_chat.id} by {update.effective_user.id}")
            
        except Exception as title_error:
            # اگر تنظیم title موفق نبود، حداقل در دیتابیس ذخیره کن
            db.set_user_nickname(target_user.id, update.effective_chat.id, nickname, update.effective_user.id)
            
            await update.message.reply_text(
                f"✅ لقب کاربر {target_user.first_name} به «{nickname}» تنظیم شد.\n"
                f"⚠️ تغییر title گروه ممکن نبود: {str(title_error)}",
                parse_mode=ParseMode.HTML
            )
            
            logger.warning(f"Could not set title but nickname saved for user {target_user.id}: {str(title_error)}")
        
    except Exception as e:
        logger.error(f"Error in set_nickname_handler: {str(e)}")
        await update.message.reply_text(f"خطایی رخ داد: {str(e)}")

async def show_nickname_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """نمایش لقب کاربر"""
    try:
        # بررسی می‌کنیم که آیا پیام در گروه ارسال شده است
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return
        
        # بررسی می‌کنیم که آیا پیام در پاسخ به پیام دیگری است
        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً این دستور را در پاسخ به پیام کاربر مورد نظر استفاده کنید.")
            return
        
        target_user = update.message.reply_to_message.from_user
        
        # دریافت لقب از دیتابیس
        nickname = db.get_user_nickname(target_user.id, update.effective_chat.id)
        
        if nickname:
            await update.message.reply_text(
                f"لقب کاربر <b>{target_user.first_name}</b>: <b>{nickname}</b>",
                parse_mode=ParseMode.HTML
            )
        else:
            await update.message.reply_text(
                f"کاربر <b>{target_user.first_name}</b> لقبی ندارد.",
                parse_mode=ParseMode.HTML
            )
        
    except Exception as e:
        logger.error(f"Error in show_nickname_handler: {str(e)}")
        await update.message.reply_text(f"خطایی رخ داد: {str(e)}")

async def remove_nickname_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """حذف لقب کاربر و title از گروه"""
    try:
        # بررسی می‌کنیم که آیا پیام در گروه ارسال شده است
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return
        
        # بررسی می‌کنیم که آیا کاربر ادمین است
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند از این دستور استفاده کنند.")
            return
        
        # بررسی می‌کنیم که آیا پیام در پاسخ به پیام دیگری است
        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً این دستور را در پاسخ به پیام کاربر مورد نظر استفاده کنید.")
            return
        
        target_user = update.message.reply_to_message.from_user
        
        # بررسی اینکه آیا کاربر هدف ادمین است
        target_chat_member = await context.bot.get_chat_member(update.effective_chat.id, target_user.id)
        if target_chat_member.status not in ['administrator', 'creator']:
            await update.message.reply_text("فقط می‌توان title ادمین‌ها را حذف کرد.")
            return
        
        # بررسی اینکه آیا ربات مجوز تنظیم title ادمین‌ها را دارد
        bot_member = await context.bot.get_chat_member(update.effective_chat.id, context.bot.id)
        if not bot_member.can_promote_members:
            await update.message.reply_text("ربات دسترسی لازم برای تغییر title ادمین‌ها را ندارد.")
            return
        
        # حذف custom title (با تنظیم title خالی)
        try:
            await context.bot.set_chat_administrator_custom_title(
                chat_id=update.effective_chat.id,
                user_id=target_user.id,
                custom_title=""  # title خالی
            )
            
            # حذف لقب از دیتابیس
            db.remove_user_nickname(target_user.id, update.effective_chat.id)
            
            await update.message.reply_text(
                f"✅ لقب و title کاربر {target_user.first_name} حذف شد.",
                parse_mode=ParseMode.HTML
            )
            
            logger.info(f"Nickname and title removed for user {target_user.id} in chat {update.effective_chat.id} by {update.effective_user.id}")
            
        except Exception as title_error:
            # اگر حذف title موفق نبود، حداقل از دیتابیس حذف کن
            db.remove_user_nickname(target_user.id, update.effective_chat.id)
            
            await update.message.reply_text(
                f"✅ لقب کاربر {target_user.first_name} از دیتابیس حذف شد.\n"
                f"⚠️ حذف title گروه ممکن نبود: {str(title_error)}",
                parse_mode=ParseMode.HTML
            )
            
            logger.warning(f"Could not remove title but nickname removed from database for user {target_user.id}: {str(title_error)}")
        
    except Exception as e:
        logger.error(f"Error in remove_nickname_handler: {str(e)}")
        await update.message.reply_text(f"خطایی رخ داد: {str(e)}")