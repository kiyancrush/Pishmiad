import sys
import os

# اضافه کردن مسیر ریشه پروژه به sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# سپس بقیه import ها
import logging
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, CommandHandler, CallbackQueryHandler, MessageHandler, filters
from database.database import Database
from config import ADMIN_ID

logger = logging.getLogger(__name__)
db = Database("group_manager.db")

# تنظیمات آستانه‌های تخلف
ABUSE_THRESHOLDS = {
    "ban": {"count": 5, "time_window": 300},  # 5 بن در 5 دقیقه
    "kick": {"count": 7, "time_window": 300},  # 7 اخراج در 5 دقیقه
    "mute": {"count": 10, "time_window": 300},  # 10 سکوت در 5 دقیقه
    "delete": {"count": 15, "time_window": 300},  # 15 حذف پیام در 5 دقیقه
}

async def report_admin_abuse(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """گزارش تخلف ادمین"""
    try:
        # بررسی اینکه آیا پیام ریپلای شده است
        if not update.message.reply_to_message:
            await update.message.reply_text("برای گزارش تخلف ادمین، باید روی پیام ادمین مورد نظر ریپلای کنید.")
            return
            
        # دریافت اطلاعات پیام و کاربر گزارش شده
        reported_message = update.message.reply_to_message
        reported_user = reported_message.from_user
        reporter_user = update.message.from_user
        group_id = update.effective_chat.id
        
        # بررسی اینکه آیا کاربر گزارش شده ادمین است
        chat_member = await context.bot.get_chat_member(group_id, reported_user.id)
        if chat_member.status not in ['administrator', 'creator']:
            await update.message.reply_text("این کاربر ادمین نیست. برای گزارش تخلف ادمین‌ها از این دستور استفاده کنید.")
            return
        
        # دریافت متن گزارش (اختیاری)
        report_text = " ".join(context.args) if context.args else "بدون توضیحات"
        
        # ثبت گزارش در دیتابیس
        report_id = db.add_admin_abuse_report(
            group_id=group_id,
            admin_id=reported_user.id,
            reporter_id=reporter_user.id,
            message_id=reported_message.message_id,
            report_text=report_text
        )
        
        # ارسال پیام تأیید به کاربر گزارش‌دهنده
        await update.message.reply_text(
            f"✅ گزارش تخلف ادمین با شناسه #{report_id} ثبت شد و توسط مدیر گروه بررسی خواهد شد."
        )
        
        # ارسال گزارش به مدیر گروه
        keyboard = [
            [InlineKeyboardButton("✅ تأیید", callback_data=f'admin_abuse_approve_{report_id}')],
            [InlineKeyboardButton("❌ رد", callback_data=f'admin_abuse_reject_{report_id}')],
            [InlineKeyboardButton("🔍 بررسی بیشتر", callback_data=f'admin_abuse_details_{report_id}')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # ساخت متن گزارش برای مدیر گروه
        admin_report = f"⚠️ گزارش تخلف ادمین (#{report_id}):\n\n"
        admin_report += f"👤 گزارش‌دهنده: {reporter_user.first_name} (@{reporter_user.username or 'بدون یوزرنیم'})\n"
        admin_report += f"👮‍♂️ ادمین گزارش‌شده: {reported_user.first_name} (@{reported_user.username or 'بدون یوزرنیم'})\n"
        admin_report += f"💬 متن گزارش: {report_text}\n\n"
        
        # دریافت آمار اقدامات ادمین در بازه زمانی اخیر
        admin_actions = db.get_admin_recent_actions(reported_user.id, group_id)
        if admin_actions:
            admin_report += f"📊 آمار اقدامات ادمین در 30 دقیقه اخیر:\n"
            admin_report += f"🚫 تعداد بن: {admin_actions.get('ban_count', 0)}\n"
            admin_report += f"👢 تعداد اخراج: {admin_actions.get('kick_count', 0)}\n"
            admin_report += f"🔇 تعداد سکوت: {admin_actions.get('mute_count', 0)}\n"
            admin_report += f"🗑️ تعداد حذف پیام: {admin_actions.get('delete_count', 0)}\n"
        
        # دریافت مدیر گروه
        try:
            chat_administrators = await context.bot.get_chat_administrators(group_id)
            creator = next((admin for admin in chat_administrators if admin.status == 'creator'), None)
            
            if creator:
                # ارسال به مدیر گروه
                try:
                    await context.bot.send_message(
                        chat_id=creator.user.id,
                        text=admin_report,
                        reply_markup=reply_markup,
                        parse_mode="Markdown"
                    )
                except Exception as e:
                    logger.error(f"Error sending report to group creator: {str(e)}")
                    # اگر ارسال به مدیر با خطا مواجه شد، به ADMIN_ID ارسال کن
                    await context.bot.send_message(
                        chat_id=ADMIN_ID,
                        text=admin_report + "\n\n⚠️ خطا در ارسال به مدیر گروه",
                        reply_markup=reply_markup,
                        parse_mode="Markdown"
                    )
            else:
                # اگر مدیر پیدا نشد، به ADMIN_ID ارسال کن
                await context.bot.send_message(
                    chat_id=ADMIN_ID,
                    text=admin_report,
                    reply_markup=reply_markup,
                    parse_mode="Markdown"
                )
        except Exception as e:
            logger.error(f"Error getting chat administrators: {str(e)}")
            # در صورت خطا به ADMIN_ID ارسال کن
            await context.bot.send_message(
                chat_id=ADMIN_ID,
                text=admin_report + "\n\n⚠️ خطا در دریافت لیست ادمین‌ها",
                reply_markup=reply_markup,
                parse_mode="Markdown"
            )
        
    except Exception as e:
        logger.error(f"Error in report_admin_abuse: {str(e)}")
        await update.message.reply_text(f"خطا در ثبت گزارش تخلف ادمین: {str(e)}")

async def admin_abuse_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """پردازش دکمه‌های گزارش تخلف ادمین"""
    try:
        query = update.callback_query
        await query.answer()
        
        # دریافت شناسه گزارش و عملیات
        data = query.data.split('_')
        action = data[2]  # approve, reject, details
        report_id = int(data[3])
        
        # دریافت اطلاعات گزارش
        report = db.get_admin_abuse_report(report_id)
        if not report:
            await query.message.edit_text("گزارش یافت نشد یا حذف شده است.")
            return
            
        if action == 'approve':
            # تأیید گزارش و محدود کردن دسترسی‌های ادمین
            db.update_admin_abuse_report_status(
                report_id=report_id,
                status='approved',
                admin_response="گزارش تأیید شد و دسترسی‌های ادمین محدود شد",
                responded_by=update.effective_user.id
            )
            
            # محدود کردن دسترسی‌های ادمین
            try:
                await context.bot.promote_chat_member(
                    chat_id=report['group_id'],
                    user_id=report['admin_id'],
                    can_change_info=False,
                    can_delete_messages=False,
                    can_restrict_members=False,
                    can_invite_users=True,
                    can_pin_messages=False,
                    can_promote_members=False,
                    can_manage_video_chats=False,
                    can_manage_topics=False
                )
                
                # ارسال پیام به گروه
                await context.bot.send_message(
                    chat_id=report['group_id'],
                    text=f"⚠️ به دلیل گزارش‌های متعدد تخلف، دسترسی‌های ادمین محدود شد."
                )
            except Exception as e:
                logger.error(f"Error restricting admin permissions: {str(e)}")
            
            # ویرایش پیام مدیر
            await query.message.edit_text(
                f"✅ گزارش تخلف ادمین #{report_id} تأیید شد.\n\n"
                f"👮‍♂️ ادمین گزارش‌شده: {report['admin_id']}\n"
                f"💬 متن گزارش: {report['report_text']}\n\n"
                f"🔒 دسترسی‌های ادمین محدود شد.",
                reply_markup=None
            )
            
        elif action == 'reject':
            # رد گزارش
            db.update_admin_abuse_report_status(
                report_id=report_id,
                status='rejected',
                admin_response="گزارش رد شد",
                responded_by=update.effective_user.id
            )
            
            # ویرایش پیام مدیر
            await query.message.edit_text(
                f"❌ گزارش تخلف ادمین #{report_id} رد شد.\n\n"
                f"👮‍♂️ ادمین گزارش‌شده: {report['admin_id']}\n"
                f"💬 متن گزارش: {report['report_text']}",
                reply_markup=None
            )
            
        elif action == 'details':
            # نمایش جزئیات بیشتر گزارش
            details = f"🔍 جزئیات گزارش تخلف ادمین #{report_id}:\n\n"
            details += f"👤 گزارش‌دهنده: {report['reporter_id']}\n"
            details += f"👮‍♂️ ادمین گزارش‌شده: {report['admin_id']}\n"
            details += f"💬 متن گزارش: {report['report_text']}\n"
            details += f"⏰ زمان گزارش: {report['report_time']}\n"
            details += f"📝 وضعیت: {report['status']}\n"
            
            # دریافت آمار اقدامات ادمین در بازه زمانی اخیر
            admin_actions = db.get_admin_recent_actions(report['admin_id'], report['group_id'])
            if admin_actions:
                details += f"\n📊 آمار اقدامات ادمین در 30 دقیقه اخیر:\n"
                details += f"🚫 تعداد بن: {admin_actions.get('ban_count', 0)}\n"
                details += f"👢 تعداد اخراج: {admin_actions.get('kick_count', 0)}\n"
                details += f"🔇 تعداد سکوت: {admin_actions.get('mute_count', 0)}\n"
                details += f"🗑️ تعداد حذف پیام: {admin_actions.get('delete_count', 0)}\n"
            
            keyboard = [
                [InlineKeyboardButton("✅ تأیید", callback_data=f'admin_abuse_approve_{report_id}')],
                [InlineKeyboardButton("❌ رد", callback_data=f'admin_abuse_reject_{report_id}')],
                [InlineKeyboardButton("بازگشت", callback_data=f'admin_abuse_back')]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.message.edit_text(details, reply_markup=reply_markup)
            
    except Exception as e:
        logger.error(f"Error in admin_abuse_callback_handler: {str(e)}")
        await query.message.edit_text(f"خطا در پردازش گزارش تخلف ادمین: {str(e)}")

async def check_admin_actions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """بررسی خودکار اقدامات ادمین‌ها برای شناسایی تخلف"""
    try:
        # بررسی اینکه آیا کاربر ادمین است
        user_id = update.effective_user.id
        chat_id = update.effective_chat.id
        
        chat_member = await context.bot.get_chat_member(chat_id, user_id)
        if chat_member.status not in ['administrator', 'creator']:
            return  # کاربر ادمین نیست، نیازی به بررسی نیست
        
        # تشخیص نوع اقدام ادمین
        action_type = None
        if update.message and update.message.text:
            text = update.message.text.lower()
            if text.startswith("بن") or text.startswith("/ban"):
                action_type = "ban"
            elif text.startswith("اخراج") or text.startswith("/kick"):
                action_type = "kick"
            elif text.startswith("سکوت") or text.startswith("/mute"):
                action_type = "mute"
            elif text.startswith("حذف") or text.startswith("/delete"):
                action_type = "delete"
        
        if not action_type:
            return  # اقدام قابل تشخیص نیست
        
        # ثبت اقدام ادمین در دیتابیس
        db.add_admin_action(user_id, chat_id, action_type)
        
        # بررسی تعداد اقدامات ادمین در بازه زمانی مشخص
        threshold = ABUSE_THRESHOLDS.get(action_type)
        if not threshold:
            return
        
        count = db.count_admin_actions(user_id, chat_id, action_type, threshold["time_window"])
        
        # اگر تعداد اقدامات از آستانه بیشتر باشد، هشدار بده و محدود کن
        if count >= threshold["count"]:
            # ثبت تخلف خودکار
            report_id = db.add_admin_abuse_report(
                group_id=chat_id,
                admin_id=user_id,
                reporter_id=context.bot.id,  # ربات به عنوان گزارش‌دهنده
                message_id=update.message.message_id if update.message else 0,
                report_text=f"تشخیص خودکار تخلف: {count} {action_type} در {threshold['time_window']} ثانیه"
            )
            
            # محدود کردن دسترسی‌های ادمین
            try:
                await context.bot.promote_chat_member(
                    chat_id=chat_id,
                    user_id=user_id,
                    can_change_info=False,
                    can_delete_messages=False,
                    can_restrict_members=False,
                    can_invite_users=True,
                    can_pin_messages=False,
                    can_promote_members=False,
                    can_manage_video_chats=False,
                    can_manage_topics=False
                )
                
                # ارسال پیام به گروه
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=f"⚠️ به دلیل تشخیص خودکار تخلف ({count} {action_type} در مدت کوتاه)، دسترسی‌های ادمین محدود شد."
                )
                
                # ارسال گزارش به مدیر گروه
                chat_administrators = await context.bot.get_chat_administrators(chat_id)
                creator = next((admin for admin in chat_administrators if admin.status == 'creator'), None)
                
                if creator:
                    admin_report = f"⚠️ گزارش خودکار تخلف ادمین (#{report_id}):\n\n"
                    admin_report += f"👮‍♂️ ادمین متخلف: {user_id}\n"
                    admin_report += f"🚫 نوع تخلف: {count} {action_type} در {threshold['time_window']} ثانیه\n"
                    admin_report += f"⏰ زمان تشخیص: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                    admin_report += f"🔒 دسترسی‌های ادمین به صورت خودکار محدود شد."
                    
                    await context.bot.send_message(
                        chat_id=creator.user.id,
                        text=admin_report,
                        parse_mode="Markdown"
                    )
            except Exception as e:
                logger.error(f"Error restricting admin permissions: {str(e)}")
        
    except Exception as e:
        logger.error(f"Error in check_admin_actions: {str(e)}")

def setup_handlers(application):
    """تنظیم هندلرهای گزارش تخلف ادمین"""
    application.add_handler(CommandHandler("reportadmin", report_admin_abuse))
    application.add_handler(CallbackQueryHandler(admin_abuse_callback_handler, pattern='^admin_abuse_'))
    
    # اضافه کردن میدلور برای بررسی خودکار اقدامات ادمین‌ها
    application.add_handler(MessageHandler(filters.ALL, check_admin_actions), group=999)  # اولویت پایین