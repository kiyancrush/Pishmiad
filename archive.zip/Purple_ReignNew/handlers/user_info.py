import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from telegram.constants import ParseMode
from database.database import Database
try:
    import jdatetime
except Exception:
    jdatetime = None
from datetime import datetime

# تنظیم لاگر
logger = logging.getLogger(__name__)

# مقداردهی اولیه دیتابیس
db = Database("group_manager.db")

async def user_info_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """نمایش اطلاعات کاربر"""
    try:
        # بررسی می‌کنیم که آیا پیام در گروه ارسال شده است
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return
        
        # بررسی می‌کنیم که آیا پیام در پاسخ به پیام دیگری است
        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً این دستور را در پاسخ به پیام کاربر مورد نظر استفاده کنید.")
            return
        
        target_user = update.message.reply_to_message.from_user
        group_id = update.effective_chat.id
        
        # دریافت اطلاعات کاربر از دیتابیس
        user_data = db.get_user_data(target_user.id)
        message_count = db.count_user_messages(target_user.id, group_id)
        warning_count = db.get_user_warnings(target_user.id, group_id)
        nickname = db.get_user_nickname(target_user.id, group_id)
        
        # تبدیل تاریخ میلادی به شمسی
        join_date = None
        if user_data and user_data.get('join_date'):
            try:
                gregorian_date = datetime.strptime(user_data['join_date'], "%Y-%m-%d %H:%M:%S")
                jalali_date = jdatetime.datetime.fromgregorian(datetime=gregorian_date)
                join_date = jalali_date.strftime("%Y/%m/%d %H:%M:%S")
            except Exception as e:
                logger.error(f"Error converting date: {str(e)}")
                join_date = user_data['join_date']
        
        # ایجاد پیام اطلاعات کاربر با طراحی زیبا
        info_message = f"""<b>📊 اطلاعات کاربر</b>

<b>👤 نام:</b> {target_user.first_name} {target_user.last_name or ''}
<b>🆔 شناسه کاربری:</b> <code>{target_user.id}</code>
<b>👑 نام کاربری:</b> {('@' + target_user.username) if target_user.username else 'تنظیم نشده'}"""
        
        if nickname:
            info_message += f"\n<b>🏷️ لقب:</b> {nickname}"
        
        info_message += f"""\n<b>📅 تاریخ عضویت:</b> {join_date or 'نامشخص'}
<b>💬 تعداد پیام‌ها:</b> {message_count or 0}
<b>⚠️ تعداد اخطارها:</b> {warning_count or 0}/{db.get_group_max_warnings(group_id)}"""
        
        # ایجاد دکمه‌های اینلاین
        keyboard = [
            [InlineKeyboardButton("📊 نمودار فعالیت", callback_data=f"user_activity_{target_user.id}")],
            [InlineKeyboardButton("⚠️ تاریخچه اخطارها", callback_data=f"user_warnings_{target_user.id}")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        # ارسال پیام
        await update.message.reply_text(
            info_message,
            parse_mode=ParseMode.HTML,
            reply_markup=reply_markup
        )
        
    except Exception as e:
        logger.error(f"Error in user_info_handler: {str(e)}")
        await update.message.reply_text(f"خطایی رخ داد: {str(e)}")

async def user_info_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """پردازش دکمه‌های اینلاین اطلاعات کاربر"""
    try:
        query = update.callback_query
        await query.answer()
        
        # استخراج نوع درخواست و شناسه کاربر
        data = query.data.split('_')
        if len(data) != 3:
            return
        
        action_type = data[1]
        user_id = int(data[2])
        group_id = update.effective_chat.id
        
        if action_type == "activity":
            # نمایش نمودار فعالیت کاربر
            message_counts = db.get_user_activity(user_id, group_id)
            
            if not message_counts:
                await query.edit_message_text(
                    "اطلاعات فعالیت کاربر موجود نیست.",
                    parse_mode=ParseMode.HTML
                )
                return
            
            # ایجاد نمودار متنی ساده
            activity_chart = "<b>📊 نمودار فعالیت کاربر</b>\n\n"
            max_count = max(message_counts.values()) if message_counts else 0
            
            for day, count in message_counts.items():
                bar_length = int((count / max_count) * 20) if max_count > 0 else 0
                bar = "█" * bar_length
                activity_chart += f"<b>{day}:</b> {bar} {count}\n"
            
            # دکمه بازگشت
            keyboard = [[InlineKeyboardButton("🔙 بازگشت", callback_data=f"user_info_{user_id}")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                activity_chart,
                parse_mode=ParseMode.HTML,
                reply_markup=reply_markup
            )
            
        elif action_type == "warnings":
            # نمایش تاریخچه اخطارها
            warnings = db.get_user_warning_history(user_id, group_id)
            
            if not warnings:
                await query.edit_message_text(
                    "کاربر تاکنون اخطاری دریافت نکرده است.",
                    parse_mode=ParseMode.HTML
                )
                return
            
            warnings_text = "<b>⚠️ تاریخچه اخطارهای کاربر</b>\n\n"
            
            for i, warning in enumerate(warnings, 1):
                # تبدیل تاریخ میلادی به شمسی
                try:
                    gregorian_date = datetime.strptime(warning['timestamp'], "%Y-%m-%d %H:%M:%S")
                    jalali_date = jdatetime.datetime.fromgregorian(datetime=gregorian_date)
                    warning_date = jalali_date.strftime("%Y/%m/%d %H:%M:%S")
                except Exception as e:
                    logger.error(f"Error converting date: {str(e)}")
                    warning_date = warning['timestamp']
                
                warnings_text += f"<b>{i}. تاریخ:</b> {warning_date}\n"
                warnings_text += f"<b>دلیل:</b> {warning['reason']}\n\n"
            
            # دکمه بازگشت
            keyboard = [[InlineKeyboardButton("🔙 بازگشت", callback_data=f"user_info_{user_id}")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                warnings_text,
                parse_mode=ParseMode.HTML,
                reply_markup=reply_markup
            )
            
        elif action_type == "info":
            # بازگشت به صفحه اصلی اطلاعات کاربر
            user = await context.bot.get_chat_member(group_id, user_id)
            target_user = user.user
            
            # دریافت اطلاعات کاربر از دیتابیس
            user_data = db.get_user_data(target_user.id)
            message_count = db.count_user_messages(target_user.id, group_id)
            warning_count = db.get_user_warnings(target_user.id, group_id)
            nickname = db.get_user_nickname(target_user.id, group_id)
            
            # تبدیل تاریخ میلادی به شمسی
            join_date = None
            if user_data and user_data.get('join_date'):
                try:
                    gregorian_date = datetime.strptime(user_data['join_date'], "%Y-%m-%d %H:%M:%S")
                    jalali_date = jdatetime.datetime.fromgregorian(datetime=gregorian_date)
                    join_date = jalali_date.strftime("%Y/%m/%d %H:%M:%S")
                except Exception as e:
                    logger.error(f"Error converting date: {str(e)}")
                    join_date = user_data['join_date']
            
            # ایجاد پیام اطلاعات کاربر با طراحی زیبا
            info_message = f"""<b>📊 اطلاعات کاربر</b>

<b>👤 نام:</b> {target_user.first_name} {target_user.last_name or ''}
<b>🆔 شناسه کاربری:</b> <code>{target_user.id}</code>
<b>👑 نام کاربری:</b> {('@' + target_user.username) if target_user.username else 'تنظیم نشده'}"""
            
            if nickname:
                info_message += f"\n<b>🏷️ لقب:</b> {nickname}"
            
            info_message += f"""\n<b>📅 تاریخ عضویت:</b> {join_date or 'نامشخص'}
<b>💬 تعداد پیام‌ها:</b> {message_count or 0}
<b>⚠️ تعداد اخطارها:</b> {warning_count or 0}/{db.get_group_max_warnings(group_id)}"""
            
            # ایجاد دکمه‌های اینلاین
            keyboard = [
                [InlineKeyboardButton("📊 نمودار فعالیت", callback_data=f"user_activity_{target_user.id}")],
                [InlineKeyboardButton("⚠️ تاریخچه اخطارها", callback_data=f"user_warnings_{target_user.id}")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await query.edit_message_text(
                info_message,
                parse_mode=ParseMode.HTML,
                reply_markup=reply_markup
            )
        
    except Exception as e:
        logger.error(f"Error in user_info_callback_handler: {str(e)}")
        await update.callback_query.message.reply_text(f"خطایی رخ داد: {str(e)}")