import logging
from telegram import Update
from telegram.ext import ContextTypes
from config import ADMIN_ID
from handlers.royal_system import user_has_permission

logger = logging.getLogger(__name__)

async def admin_broadcast_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle broadcast command for admin"""
    try:
        if not await user_has_permission(update, context, "broadcast"):
            await update.message.reply_text("فقط ادمین اصلی یا مقام دارای دسترسی می‌تواند پیام همگانی ارسال کند.")
            return
        
        # Check if message is provided
        if not context.args:
            await update.message.reply_text(
                "استفاده: /broadcast <پیام>\n\n"
                "مثال: /broadcast سلام به همه گروه‌ها!\n\n"
                "این پیام به تمام گروه‌های پرمیوم که ربات در آن‌ها ادمین است ارسال خواهد شد."
            )
            return
        
        # Import here to avoid circular imports
        from database.premium import PremiumManager
        
        # Get the message to broadcast
        broadcast_text = " ".join(context.args)
        
        # Initialize premium manager
        premium_manager = PremiumManager("group_manager.db")
        
        # Get all premium groups
        premium_groups = premium_manager.get_all_premium_groups()
        active_groups = [
            group for group in premium_groups 
            if group['is_active'] and premium_manager.is_group_premium(group['group_id'])
        ]
        
        if not active_groups:
            await update.message.reply_text("هیچ گروه پرمیوم فعالی یافت نشد.")
            return
        
        # Send broadcast message
        success_count = 0
        failed_count = 0
        failed_groups = []
        
        status_message = await update.message.reply_text(
            f"🔄 در حال ارسال پیام به {len(active_groups)} گروه پرمیوم..."
        )
        
        for group in active_groups:
            group_id = group['group_id']
            try:
                # Check if bot is admin in the group
                bot_member = await context.bot.get_chat_member(group_id, context.bot.id)
                if bot_member.status not in ['administrator', 'creator']:
                    failed_count += 1
                    failed_groups.append(f"{group_id} (ربات ادمین نیست)")
                    continue
                
                # Send the broadcast message
                await context.bot.send_message(
                    chat_id=group_id,
                    text=f"📢 پیام همگانی از ادمین:\n\n{broadcast_text}",
                    parse_mode='Markdown'
                )
                success_count += 1
                
            except Exception as e:
                failed_count += 1
                failed_groups.append(f"{group_id} ({str(e)[:50]})")
                logger.error(f"Failed to send broadcast to group {group_id}: {str(e)}")
        
        # Update status message with results
        result_text = f"✅ پیام همگانی ارسال شد!\n\n"
        result_text += f"📊 نتایج:\n"
        result_text += f"• موفق: {success_count} گروه\n"
        result_text += f"• ناموفق: {failed_count} گروه\n"
        
        if failed_groups and len(failed_groups) <= 5:
            result_text += f"\n❌ گروه‌های ناموفق:\n"
            for failed_group in failed_groups[:5]:
                result_text += f"• {failed_group}\n"
        elif failed_groups:
            result_text += f"\n❌ {len(failed_groups)} گروه ناموفق (جزئیات در لاگ)"
        
        await status_message.edit_text(result_text)
        
    except Exception as e:
        logger.error(f"Error in admin_broadcast_handler: {str(e)}")
        await update.message.reply_text(f"خطا در ارسال پیام همگانی: {str(e)}")
