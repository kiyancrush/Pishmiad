import re
import logging
from datetime import datetime
import pytz
from telegram import Update
from telegram.ext import ContextTypes

# نرخ‌های ثابت تبدیل
FIXED_USD_RATE = 87560  # تومان
FIXED_GOLD_RATE_PER_GRAM = 6985100  # تومان
FIXED_BITCOIN_RATE = 1200000000  # تومان

logger = logging.getLogger(__name__)

def persian_digits(text):
    """تبدیل اعداد انگلیسی به فارسی"""
    english_digits = '0123456789'
    persian_digits_map = '۰۱۲۳۴۵۶۷۸۹'
    
    for i, digit in enumerate(english_digits):
        text = text.replace(digit, persian_digits_map[i])
        
    return text

def get_current_persian_datetime():
    """دریافت تاریخ و زمان فعلی به فرمت فارسی"""
    tehran_tz = pytz.timezone('Asia/Tehran')
    now = datetime.now(tehran_tz)
    
    # فرمت تاریخ و زمان
    date_str = now.strftime('%Y/%m/%d')
    time_str = now.strftime('%H:%M:%S')
    
    # تبدیل به اعداد فارسی
    persian_date = persian_digits(date_str)
    persian_time = persian_digits(time_str)
    
    return persian_date, persian_time

async def handle_text_conversion(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """پردازش متن کاربر برای تشخیص درخواست‌های تبدیل ارز، طلا و ارز دیجیتال"""
    if not update.message or not update.message.text:
        return False
    
    text = update.message.text.strip()
    
    # تبدیل اعداد فارسی به انگلیسی برای پردازش
    persian_to_english_digits = str.maketrans('۰۱۲۳۴۵۶۷۸۹', '0123456789')
    text_english = text.translate(persian_to_english_digits)
    
    try:
        # الگوهای تبدیل دلار به تومان
        dollar_patterns = [
            r'تبدیل\s+(\d+(?:\.\d+)?)\s+دلار\s+به\s+تومان',
            r'تبدیل\s+(\d+(?:\.\d+)?)\s+دلار',
            r'(\d+(?:\.\d+)?)\s+دلار\s+به\s+تومان',
            r'(\d+(?:\.\d+)?)\s+دلار\s+چند\s+تومان',
            r'(\d+(?:\.\d+)?)\s+دلار'
        ]
        
        # الگوهای تبدیل طلا به تومان
        gold_patterns = [
            r'تبدیل\s+(\d+(?:\.\d+)?)\s+گرم\s+طلا\s+به\s+تومان',
            r'تبدیل\s+(\d+(?:\.\d+)?)\s+گرم\s+طلا',
            r'(\d+(?:\.\d+)?)\s+گرم\s+طلا\s+به\s+تومان',
            r'(\d+(?:\.\d+)?)\s+گرم\s+طلا\s+چند\s+تومان',
            r'(\d+(?:\.\d+)?)\s+گرم\s+طلا'
        ]
        
        # الگوهای تبدیل بیت‌کوین به تومان
        bitcoin_patterns = [
            r'تبدیل\s+(\d+(?:\.\d+)?)\s+بیت\s*کوین\s+به\s+تومان',
            r'تبدیل\s+(\d+(?:\.\d+)?)\s+بیت\s*کوین',
            r'(\d+(?:\.\d+)?)\s+بیت\s*کوین\s+به\s+تومان',
            r'(\d+(?:\.\d+)?)\s+بیت\s*کوین\s+چند\s+تومان',
            r'(\d+(?:\.\d+)?)\s+بیت\s*کوین'
        ]
        
        # بررسی الگوهای دلار
        for pattern in dollar_patterns:
            match = re.search(pattern, text_english, re.IGNORECASE)
            if match:
                amount = float(match.group(1))
                await convert_dollar_to_toman(update, amount)
                return True
        
        # بررسی الگوهای طلا
        for pattern in gold_patterns:
            match = re.search(pattern, text_english, re.IGNORECASE)
            if match:
                amount = float(match.group(1))
                await convert_gold_to_toman(update, amount)
                return True
        
        # بررسی الگوهای بیت‌کوین
        for pattern in bitcoin_patterns:
            match = re.search(pattern, text_english, re.IGNORECASE)
            if match:
                amount = float(match.group(1))
                await convert_bitcoin_to_toman(update, amount)
                return True
        
        # الگوهای تبدیل تومان به دلار
        toman_to_dollar_patterns = [
            r'تبدیل\s+(\d+(?:,\d{3})*(?:\.\d+)?)\s+تومان\s+به\s+دلار',
            r'(\d+(?:,\d{3})*(?:\.\d+)?)\s+تومان\s+به\s+دلار',
            r'(\d+(?:,\d{3})*(?:\.\d+)?)\s+تومان\s+چند\s+دلار'
        ]
        
        for pattern in toman_to_dollar_patterns:
            match = re.search(pattern, text_english, re.IGNORECASE)
            if match:
                amount_str = match.group(1).replace(',', '')
                amount = float(amount_str)
                await convert_toman_to_dollar(update, amount)
                return True
        
        return False
        
    except Exception as e:
        logger.error(f"Error in handle_text_conversion: {str(e)}")
        return False

async def convert_dollar_to_toman(update: Update, dollar_amount: float):
    """تبدیل دلار به تومان"""
    try:
        toman_amount = dollar_amount * FIXED_USD_RATE
        
        # فرمت‌بندی اعداد با ارقام فارسی و جداکننده هزارگان
        dollar_formatted = persian_digits(f"{dollar_amount:,.2f}".rstrip('0').rstrip('.'))
        toman_formatted = persian_digits(f"{toman_amount:,.0f}")
        rate_formatted = persian_digits(f"{FIXED_USD_RATE:,}")
        
        # دریافت تاریخ و زمان فعلی
        _, current_time = get_current_persian_datetime()
        
        message = f"""💱 **تبدیل دلار به تومان**

💵 **مقدار:** {dollar_formatted} دلار
💰 **معادل:** {toman_formatted} تومان

📊 **نرخ تبدیل:** ۱ دلار = {rate_formatted} تومان
🕐 **زمان محاسبه:** {current_time}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 **نکته:** این نرخ بر اساس آخرین قیمت بازار آزاد محاسبه شده است."""

        await update.message.reply_text(message, parse_mode='Markdown')
        
        logger.info(f"Dollar conversion: {dollar_amount} USD = {toman_amount} IRR for user {update.effective_user.id}")
        
    except Exception as e:
        logger.error(f"Error in convert_dollar_to_toman: {str(e)}")
        await update.message.reply_text("❌ خطایی در تبدیل دلار به تومان رخ داد.")

async def convert_gold_to_toman(update: Update, gold_grams: float):
    """تبدیل گرم طلا به تومان"""
    try:
        toman_amount = gold_grams * FIXED_GOLD_RATE_PER_GRAM
        
        # فرمت‌بندی اعداد با ارقام فارسی و جداکننده هزارگان
        gold_formatted = persian_digits(f"{gold_grams:,.2f}".rstrip('0').rstrip('.'))
        toman_formatted = persian_digits(f"{toman_amount:,.0f}")
        rate_formatted = persian_digits(f"{FIXED_GOLD_RATE_PER_GRAM:,}")
        
        # دریافت تاریخ و زمان فعلی
        _, current_time = get_current_persian_datetime()
        
        message = f"""🥇 **تبدیل طلا به تومان**

⚖️ **مقدار:** {gold_formatted} گرم طلا
💰 **معادل:** {toman_formatted} تومان

📊 **نرخ تبدیل:** ۱ گرم طلا = {rate_formatted} تومان
🕐 **زمان محاسبه:** {current_time}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 **نکته:** این نرخ بر اساس آخرین قیمت طلای ۱۸ عیار در بازار تهران محاسبه شده است."""

        await update.message.reply_text(message, parse_mode='Markdown')
        
        logger.info(f"Gold conversion: {gold_grams} grams = {toman_amount} IRR for user {update.effective_user.id}")
        
    except Exception as e:
        logger.error(f"Error in convert_gold_to_toman: {str(e)}")
        await update.message.reply_text("❌ خطایی در تبدیل طلا به تومان رخ داد.")

async def convert_bitcoin_to_toman(update: Update, bitcoin_amount: float):
    """تبدیل بیت‌کوین به تومان"""
    try:
        toman_amount = bitcoin_amount * FIXED_BITCOIN_RATE
        
        # فرمت‌بندی اعداد با ارقام فارسی و جداکننده هزارگان
        bitcoin_formatted = persian_digits(f"{bitcoin_amount:,.8f}".rstrip('0').rstrip('.'))
        toman_formatted = persian_digits(f"{toman_amount:,.0f}")
        rate_formatted = persian_digits(f"{FIXED_BITCOIN_RATE:,}")
        
        # دریافت تاریخ و زمان فعل��
        _, current_time = get_current_persian_datetime()
        
        message = f"""₿ **تبدیل بیت‌کوین به تومان**

₿ **مقدار:** {bitcoin_formatted} بیت‌کوین
💰 **معادل:** {toman_formatted} تومان

📊 **نرخ تبدیل:** ۱ بیت‌کوین = {rate_formatted} تومان
🕐 **زمان محاسبه:** {current_time}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 **نکته:** این نرخ بر اساس آخرین قیمت بازار ارزهای دیجیتال محاسبه شده است."""

        await update.message.reply_text(message, parse_mode='Markdown')
        
        logger.info(f"Bitcoin conversion: {bitcoin_amount} BTC = {toman_amount} IRR for user {update.effective_user.id}")
        
    except Exception as e:
        logger.error(f"Error in convert_bitcoin_to_toman: {str(e)}")
        await update.message.reply_text("❌ خطایی در تبدیل بیت‌کوین به تومان رخ داد.")

async def convert_toman_to_dollar(update: Update, toman_amount: float):
    """تبدیل تومان به دلار"""
    try:
        dollar_amount = toman_amount / FIXED_USD_RATE
        
        # فرمت‌بندی اعداد با ارقام فارسی و جداکننده هزارگان
        toman_formatted = persian_digits(f"{toman_amount:,.0f}")
        dollar_formatted = persian_digits(f"{dollar_amount:,.2f}")
        rate_formatted = persian_digits(f"{FIXED_USD_RATE:,}")
        
        # دریافت تاریخ و زمان فعلی
        _, current_time = get_current_persian_datetime()
        
        message = f"""💱 **تبدیل تومان به دلار**

💰 **مقدار:** {toman_formatted} تومان
💵 **معادل:** {dollar_formatted} دلار

📊 **نرخ تبدیل:** {rate_formatted} تومان = ۱ دلار
🕐 **زمان محاسبه:** {current_time}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 **نکته:** این نرخ بر اساس آخرین قیمت بازار آزاد محاسبه شده است."""

        await update.message.reply_text(message, parse_mode='Markdown')
        
        logger.info(f"Toman conversion: {toman_amount} IRR = {dollar_amount} USD for user {update.effective_user.id}")
        
    except Exception as e:
        logger.error(f"Error in convert_toman_to_dollar: {str(e)}")
        await update.message.reply_text("❌ خطایی در تبدیل تومان به دلار رخ داد.")

async def show_conversion_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """نمایش راهنمای تبدیل ارز و طلا"""
    help_text = """🔄 **راهنمای تبدیل ارز، طلا و ارز دیجیتال**

💱 **تبدیل دلار به تومان:**
• تبدیل ۱۰ دلار به تومان
• ۵ دلار به تومان
• ۱۰۰ دلار چند تومان

💰 **تبدیل تومان به دلار:**
• تبدیل ۱۰۰۰۰۰۰ تومان به دلار
• ۵۰۰۰۰۰ تومان به دلار
• ۲۰۰۰۰۰۰ تومان چند دلار

🥇 **تبدیل طلا به تومان:**
• تبدیل ۵ گرم طلا به تومان
• ۱۰ گرم طلا به تومان
• ۲.۵ گرم طلا چند تومان

₿ **تبدیل بیت‌کوین به تومان:**
• تبدیل ۱ بیت‌کوین به تومان
• ۰.۵ بیت‌کوین به تومان
• ۰.۱ بیت‌کوین چند تومان

📊 **نرخ‌های فعلی:**
• ۱ دلار = ۸۷,۵۶۰ تومان
• ۱ گرم طلا = ۶,۹۸۵,۱۰۰ تومان
• ۱ بیت‌کوین = ۱,۲۰۰,۰۰۰,۰۰۰ تومان

💡 **نکته:** می‌توانید از اعداد اعشاری نیز استفاده کنید (مثل ۲.۵ دلار)"""

    await update.message.reply_text(help_text, parse_mode='Markdown')
