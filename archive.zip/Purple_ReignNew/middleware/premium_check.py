from functools import wraps
from telegram import Update
from telegram.ext import ContextTypes
from database.premium import PremiumManager
from config import (
    SUBSCRIPTION_CONTACT_ID,
    SUBSCRIPTION_CONTACT_USERNAME,
    SUBSCRIPTION_PLANS,
    ADMIN_ID,
)
import logging

logger = logging.getLogger(__name__)


# -------------------------------------------------
# Check group premium status (used in other files)
# -------------------------------------------------
def check_group_premium_status(
    group_id: int,
    premium_cache: set,
    premium_manager: PremiumManager,
) -> bool:
    try:
        if group_id in premium_cache:
            return True

        is_premium = premium_manager.is_group_premium(group_id)

        if is_premium:
            premium_cache.add(group_id)

        return is_premium

    except Exception:
        return False


# -------------------------------------------------
# Decorator for premium-required commands
# -------------------------------------------------
def premium_required(func):
    @wraps(func)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        try:
            if not update.effective_user or not update.effective_chat:
                return

            user_id = update.effective_user.id
            chat_type = update.effective_chat.type

            # 👑 Owner bypass (همیشه اجازه دارد)
            if user_id == ADMIN_ID:
                return await func(update, context, *args, **kwargs)

            # فقط در گروه
            if chat_type == "private":
                if update.message:
                    await update.message.reply_text(
                        "این دستور فقط در گروه‌ها قابل استفاده است."
                    )
                return

            premium_manager = PremiumManager("group_manager.db")
            group_id = update.effective_chat.id

            if not premium_manager.is_group_premium(group_id):
                await send_subscription_required_message(
                    update, context, premium_manager, group_id
                )
                return

            return await func(update, context, *args, **kwargs)

        except Exception as e:
            logger.error("Premium decorator error: %s", str(e))
            if update.message:
                await update.message.reply_text(
                    "خطایی در بررسی وضعیت اشتراک رخ داد."
                )

    return wrapper


# -------------------------------------------------
# Check if user is premium buyer or sudo
# -------------------------------------------------
def is_premium_buyer(
    user_id: int,
    group_id: int,
    premium_manager: PremiumManager,
) -> bool:
    try:
        subscription_info = premium_manager.get_group_subscription_info(group_id)

        if subscription_info and subscription_info.get("buyer_id") == user_id:
            return True

        sudo_users = premium_manager.get_group_sudo_users(group_id)

        if sudo_users and user_id in sudo_users:
            return True

        return False

    except Exception:
        return False


# -------------------------------------------------
# Send subscription message
# -------------------------------------------------
async def send_subscription_required_message(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    premium_manager: PremiumManager,
    group_id: int,
):
    try:
        subscription_info = premium_manager.get_group_subscription_info(group_id)

        plans_text = ""
        for _, plan_info in SUBSCRIPTION_PLANS.items():
            plans_text += (
                f"- {plan_info['name']} | "
                f"{plan_info['price']:,} تومان | "
                f"{plan_info['days']} روز\n"
            )

        if subscription_info and not subscription_info.get("is_active"):
            message = (
                "🔒 اشتراک این گروه منقضی شده است.\n\n"
                f"تاریخ پایان: {subscription_info.get('subscription_end')}\n"
                f"خریدار قبلی: {subscription_info.get('buyer_username') or 'نامشخص'}\n\n"
                f"برای تمدید با @{SUBSCRIPTION_CONTACT_USERNAME} تماس بگیرید.\n"
                f"آیدی تماس: {SUBSCRIPTION_CONTACT_ID}\n\n"
                f"آیدی گروه: {group_id}\n\n"
                "پلن‌ها:\n"
                f"{plans_text}"
            )
        else:
            message = (
                "🔒 این گروه اشتراک فعال ندارد.\n\n"
                "برای استفاده از امکانات ربات باید اشتراک تهیه شود.\n\n"
                f"برای خرید با @{SUBSCRIPTION_CONTACT_USERNAME} تماس بگیرید.\n"
                f"آیدی تماس: {SUBSCRIPTION_CONTACT_ID}\n\n"
                f"آیدی گروه: {group_id}\n\n"
                "پلن‌ها:\n"
                f"{plans_text}"
            )

        if update.message:
            await update.message.reply_text(message)

    except Exception as e:
        logger.error("Subscription message error: %s", str(e))
        if update.message:
            await update.message.reply_text(
                "خطایی در نمایش اطلاعات اشتراک رخ داد."
            )