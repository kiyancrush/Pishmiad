import sqlite3
from datetime import datetime, timedelta
from typing import Optional, List, Dict
import logging

logger = logging.getLogger(__name__)

class PremiumManager:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.init_tables()

    def init_tables(self):
        """Initialize premium subscription tables"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Premium groups table
            cursor.execute(''' 
                CREATE TABLE IF NOT EXISTS premium_groups (
                    group_id INTEGER PRIMARY KEY,
                    subscription_start DATE NOT NULL,
                    subscription_end DATE NOT NULL,
                    buyer_id INTEGER NOT NULL,
                    buyer_username TEXT,
                    is_active BOOLEAN DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')

            # Subscription plans table
            cursor.execute(''' 
                CREATE TABLE IF NOT EXISTS subscription_plans (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    duration_days INTEGER NOT NULL,
                    price REAL NOT NULL,
                    is_active BOOLEAN DEFAULT 1
                )
            ''')

            # Insert default subscription plans
            cursor.execute(''' 
                INSERT OR IGNORE INTO subscription_plans (id, name, duration_days, price)
                VALUES 
                    (1, 'ماهانه', 30, 50000),
                    (2, 'سه ماهه', 90, 120000),
                    (3, 'شش ماهه', 180, 200000),
                    (4, 'سالانه', 365, 350000)
            ''')

            conn.commit()
            conn.close()
            logger.info("Premium database tables initialized successfully")

        except Exception as e:
            logger.error(f"Error initializing premium tables: {str(e)}")
            if conn:
                conn.close()

    def is_group_premium(self, group_id: int) -> bool:
        """Check if a group has active premium subscription"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute(''' 
                SELECT COUNT(*) FROM premium_groups 
                WHERE group_id = ? AND subscription_end > date('now') AND is_active = 1
            ''', (group_id,))
            
            result = cursor.fetchone()[0] > 0
            conn.close()
            return result

        except Exception as e:
            logger.error(f"Error checking premium status for group {group_id}: {str(e)}")
            return False

    def get_group_subscription_info(self, group_id: int) -> Optional[Dict]:
        """Get subscription information for a group"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute(''' 
                SELECT subscription_start, subscription_end, buyer_id, buyer_username, is_active
                FROM premium_groups 
                WHERE group_id = ?
                ORDER BY subscription_end DESC
                LIMIT 1
            ''', (group_id,))
            
            result = cursor.fetchone()
            conn.close()
            
            if result:
                return {
                    'subscription_start': result[0],
                    'subscription_end': result[1],
                    'buyer_id': result[2],
                    'buyer_username': result[3],
                    'is_active': result[4]
                }
            return None

        except Exception as e:
            logger.error(f"Error getting subscription info for group {group_id}: {str(e)}")
            return None

    def add_premium_subscription(self, group_id: int, buyer_id: int, buyer_username: str, duration_days: int = 30) -> bool:
        """Add premium subscription for a group"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            start_date = datetime.now().date()
            end_date = start_date + timedelta(days=duration_days)
            
            cursor.execute(''' 
                INSERT OR REPLACE INTO premium_groups 
                (group_id, subscription_start, subscription_end, buyer_id, buyer_username)
                VALUES (?, ?, ?, ?, ?)
            ''', (group_id, start_date, end_date, buyer_id, buyer_username))
            
            conn.commit()
            conn.close()
            logger.info(f"Premium subscription added for group {group_id}")
            return True

        except Exception as e:
            logger.error(f"Error adding premium subscription for group {group_id}: {str(e)}")
            return False

    def get_all_premium_groups(self) -> List[Dict]:
        """Get all premium groups"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute(''' 
                SELECT group_id, subscription_start, subscription_end, buyer_id, buyer_username, is_active
                FROM premium_groups 
                ORDER BY subscription_end DESC
            ''')
            
            results = cursor.fetchall()
            conn.close()
            
            groups = []
            for result in results:
                groups.append({
                    'group_id': result[0],
                    'subscription_start': result[1],
                    'subscription_end': result[2],
                    'buyer_id': result[3],
                    'buyer_username': result[4],
                    'is_active': result[5]
                })
            
            return groups

        except Exception as e:
            logger.error(f"Error getting all premium groups: {str(e)}")
            return []

    def deactivate_subscription(self, group_id: int) -> bool:
        """Deactivate subscription for a group"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute(''' 
                UPDATE premium_groups 
                SET is_active = 0 
                WHERE group_id = ?
            ''', (group_id,))
            
            conn.commit()
            conn.close()
            logger.info(f"Subscription deactivated for group {group_id}")
            return True

        except Exception as e:
            logger.error(f"Error deactivating subscription for group {group_id}: {str(e)}")
            return False

    def get_group_sudo_users(self, group_id: int) -> list:
        """Get list of sudo users for a group"""
        try:
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            
            # Check if table exists, if not create it
            c.execute("CREATE TABLE IF NOT EXISTS sudo_users (group_id INTEGER, user_id INTEGER, added_by INTEGER, added_date TEXT, PRIMARY KEY (group_id, user_id))")
            
            c.execute("SELECT user_id FROM sudo_users WHERE group_id = ?", (group_id,))
            results = c.fetchall()
            conn.close()
            
            if results:
                return [user_id[0] for user_id in results]
            return []
        except Exception as e:
            logger.error(f"Error getting sudo users for group {group_id}: {str(e)}")
            return []
    
    def add_sudo_user(self, group_id: int, user_id: int, added_by: int) -> bool:
        """Add a sudo user to a group"""
        try:
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            
            # Check if table exists, if not create it
            c.execute("CREATE TABLE IF NOT EXISTS sudo_users (group_id INTEGER, user_id INTEGER, added_by INTEGER, added_date TEXT, PRIMARY KEY (group_id, user_id))")
            
            # Check if user is already a sudo user
            c.execute("SELECT user_id FROM sudo_users WHERE group_id = ? AND user_id = ?", (group_id, user_id))
            if c.fetchone():
                conn.close()
                return False  # User is already a sudo user
            
            # Add user as sudo
            current_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            c.execute("INSERT INTO sudo_users (group_id, user_id, added_by, added_date) VALUES (?, ?, ?, ?)", 
                     (group_id, user_id, added_by, current_date))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error adding sudo user {user_id} to group {group_id}: {str(e)}")
            return False
    
    def remove_sudo_user(self, group_id: int, user_id: int) -> bool:
        """Remove a sudo user from a group"""
        try:
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            
            # Check if table exists
            c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='sudo_users'")
            if not c.fetchone():
                conn.close()
                return False
            
            c.execute("DELETE FROM sudo_users WHERE group_id = ? AND user_id = ?", (group_id, user_id))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            logger.error(f"Error removing sudo user {user_id} from group {group_id}: {str(e)}")
            return False
