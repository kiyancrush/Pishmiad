import sqlite3
from datetime import datetime, timedelta
try:
    import jdatetime
except Exception:
    jdatetime = None

class Database:
    def __init__(self, db_name):
        self.db_name = db_name
        self.init_db()

    def init_db(self):
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        
        # Create users table
        c.execute('''CREATE TABLE IF NOT EXISTS users
                    (user_id INTEGER PRIMARY KEY,
                     username TEXT,
                     first_name TEXT,
                     last_name TEXT,
                     warnings INTEGER DEFAULT 0,
                     is_banned BOOLEAN DEFAULT 0,
                     join_date TEXT,
                     last_active TEXT)''')
        
        # Create groups table with more settings
        c.execute('''CREATE TABLE IF NOT EXISTS groups
                    (group_id INTEGER PRIMARY KEY,
                     title TEXT,
                     welcome_enabled BOOLEAN DEFAULT 1,
                     welcome_message TEXT,
                     rules_message TEXT,
                     anti_spam BOOLEAN DEFAULT 1,
                     anti_link BOOLEAN DEFAULT 1,
                     anti_profanity BOOLEAN DEFAULT 1,
                     max_warnings INTEGER DEFAULT 3,
                     is_premium BOOLEAN DEFAULT 0,
                     added_by INTEGER,
                     added_date TEXT,
                     delete_new_members BOOLEAN DEFAULT 0,
                     delete_join_messages BOOLEAN DEFAULT 0,
                     delete_pin_messages BOOLEAN DEFAULT 0,
                     delete_video_chat_messages BOOLEAN DEFAULT 0)''')
        
        # Check and add missing columns to existing tables
        self._update_database_schema()
        self._ensure_royal_role_tables()
        
        # Create messages table for analytics
        c.execute('''CREATE TABLE IF NOT EXISTS messages
                    (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     message_id INTEGER,
                     group_id INTEGER,
                     user_id INTEGER,
                     timestamp TEXT,
                     FOREIGN KEY (group_id) REFERENCES groups (group_id),
                     FOREIGN KEY (user_id) REFERENCES users (user_id))''')
        
        # Create warnings table for detailed warning logs
        c.execute('''CREATE TABLE IF NOT EXISTS warnings
                    (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     user_id INTEGER,
                     group_id INTEGER,
                     reason TEXT,
                     warned_by INTEGER,
                     timestamp TEXT,
                     FOREIGN KEY (user_id) REFERENCES users (user_id),
                     FOREIGN KEY (group_id) REFERENCES groups (group_id))''')
        
        # Create custom buttons table for welcome messages
        c.execute('''CREATE TABLE IF NOT EXISTS custom_buttons
                    (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     group_id INTEGER,
                     button_text TEXT,
                     button_url TEXT,
                     button_order INTEGER,
                     FOREIGN KEY (group_id) REFERENCES groups (group_id))''')
        
        # ایجاد جدول گزارش‌های کاربران
        c.execute('''CREATE TABLE IF NOT EXISTS user_reports
                    (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     group_id INTEGER,
                     reported_user_id INTEGER,
                     reporter_user_id INTEGER,
                     message_id INTEGER,
                     report_text TEXT,
                     status TEXT DEFAULT 'pending',
                     admin_response TEXT,
                     responded_by INTEGER,
                     report_time TEXT,
                     response_time TEXT,
                     FOREIGN KEY (group_id) REFERENCES groups (group_id),
                     FOREIGN KEY (reported_user_id) REFERENCES users (user_id),
                     FOREIGN KEY (reporter_user_id) REFERENCES users (user_id))''')
        
        # ایجاد جدول لقب‌های کاربران
        c.execute('''CREATE TABLE IF NOT EXISTS user_nicknames
                    (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     user_id INTEGER,
                     group_id INTEGER,
                     nickname TEXT,
                     set_by INTEGER,
                     set_date TEXT,
                     FOREIGN KEY (user_id) REFERENCES users (user_id),
                     FOREIGN KEY (group_id) REFERENCES groups (group_id))''')
        
        conn.commit()
        conn.close()

    def _update_database_schema(self):
        """به‌روزرسانی ساختار دیتابیس و اضافه کردن ستون‌های جدید"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        
        # Check if max_warnings column exists in groups table
        c.execute("PRAGMA table_info(groups)")
        columns = [column[1] for column in c.fetchall()]
        
        if 'max_warnings' not in columns:
            c.execute("ALTER TABLE groups ADD COLUMN max_warnings INTEGER DEFAULT 3")
        
        if 'delete_new_members' not in columns:
            c.execute("ALTER TABLE groups ADD COLUMN delete_new_members BOOLEAN DEFAULT 0")
            
        if 'delete_join_messages' not in columns:
            c.execute("ALTER TABLE groups ADD COLUMN delete_join_messages BOOLEAN DEFAULT 0")
            
        if 'delete_pin_messages' not in columns:
            c.execute("ALTER TABLE groups ADD COLUMN delete_pin_messages BOOLEAN DEFAULT 0")
            
        if 'delete_video_chat_messages' not in columns:
            c.execute("ALTER TABLE groups ADD COLUMN delete_video_chat_messages BOOLEAN DEFAULT 0")
        
        conn.commit()
        conn.close()

    def add_user(self, user_id, username):
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        c.execute("INSERT OR IGNORE INTO users (user_id, username, join_date) VALUES (?, ?, ?)",
                 (user_id, username, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        conn.commit()
        conn.close()

    def add_group(self, group_id, title, added_by=None):
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        if added_by:
            c.execute("""INSERT OR IGNORE INTO groups 
                        (group_id, title, added_by, added_date) 
                        VALUES (?, ?, ?, ?)""",
                     (group_id, title, added_by, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        else:
            c.execute("INSERT OR IGNORE INTO groups (group_id, title) VALUES (?, ?)",
                     (group_id, title))
        conn.commit()
        conn.close()

    def set_group_premium(self, group_id, is_premium):
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        c.execute("UPDATE groups SET is_premium = ? WHERE group_id = ?", (is_premium, group_id))
        conn.commit()
        conn.close()

    def is_group_premium(self, group_id):
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        c.execute("SELECT is_premium FROM groups WHERE group_id = ?", (group_id,))
        result = c.fetchone()
        conn.close()
        return bool(result[0]) if result else False

    def get_premium_groups(self):
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        c.execute("SELECT group_id, title, added_by, added_date FROM groups WHERE is_premium = 1")
        result = c.fetchall()
        conn.close()
        return result

    def get_user_data(self, user_id):
        """دریافت اطلاعات کاربر"""
        conn = sqlite3.connect(self.db_name)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        
        c.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        result = c.fetchone()
        
        conn.close()
        
        if result:
            return {key: result[key] for key in result.keys()}
        return None

    def count_user_messages(self, user_id, group_id):
        """شمارش تعداد پیام‌های کاربر در گروه"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        
        c.execute("SELECT COUNT(*) FROM messages WHERE user_id = ? AND group_id = ?", (user_id, group_id))
        count = c.fetchone()[0]
        
        conn.close()
        return count

    def count_group_messages(self, group_id):
        """شمارش تعداد پیام‌های یک گروه"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()

        c.execute("SELECT COUNT(*) FROM messages WHERE group_id = ?", (group_id,))
        count = c.fetchone()[0]

        conn.close()
        return count


    def get_user_warnings(self, user_id, group_id):
        """دریافت تعداد اخطارهای کاربر در گروه"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        
        c.execute("SELECT COUNT(*) FROM warnings WHERE user_id = ? AND group_id = ?", (user_id, group_id))
        count = c.fetchone()[0]
        
        conn.close()
        return count

    def get_group_max_warnings(self, group_id):
        """دریافت حداکثر تعداد اخطارهای مجاز در گروه"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        
        c.execute("SELECT max_warnings FROM groups WHERE group_id = ?", (group_id,))
        result = c.fetchone()
        
        conn.close()
        return result[0] if result else 3  # مقدار پیش‌فرض 3

    def get_user_warning_history(self, user_id, group_id):
        """دریافت تاریخچه اخطارهای کاربر در گروه"""
        conn = sqlite3.connect(self.db_name)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        
        c.execute("SELECT * FROM warnings WHERE user_id = ? AND group_id = ? ORDER BY timestamp DESC", (user_id, group_id))
        results = c.fetchall()
        
        conn.close()
        
        if results:
            return [{key: row[key] for key in row.keys()} for row in results]
        return []

    def get_user_activity(self, user_id, group_id):
        """دریافت آمار فعالیت کاربر در 7 روز گذشته"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        
        # محاسبه تاریخ 7 روز قبل
        seven_days_ago = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
        
        # دریافت تعداد پیام‌ها به تفکیک روز
        c.execute("""
            SELECT strftime('%Y-%m-%d', timestamp) as day, COUNT(*) as count
            FROM messages
            WHERE user_id = ? AND group_id = ? AND timestamp >= ?
            GROUP BY day
            ORDER BY day
        """, (user_id, group_id, seven_days_ago))
        
        results = c.fetchall()
        conn.close()
        
        # تبدیل نتایجات به دیکشنری
        activity = {}
        for row in results:
            # تبدیل تاریخ میلادی به شمسی
            try:
                gregorian_date = datetime.strptime(row[0], "%Y-%m-%d")
                if jdatetime is not None:
                    jalali_date = jdatetime.datetime.fromgregorian(datetime=gregorian_date)
                    day = jalali_date.strftime("%Y/%m/%d")
                else:
                    day = gregorian_date.strftime("%Y/%m/%d")
            except Exception as e:
                day = row[0]
            
            activity[day] = row[1]
        
        return activity

    def get_group_settings(self, group_id):
        """Get all settings for a group"""
        conn = sqlite3.connect(self.db_name)
        conn.row_factory = sqlite3.Row  # This enables column access by name
        c = conn.cursor()
        c.execute("SELECT * FROM groups WHERE group_id = ?", (group_id,))
        result = c.fetchone()
        conn.close()
        
        if result:
            # Convert sqlite3.Row to dict
            return {key: result[key] for key in result.keys()}
        return None

    def add_message(self, message_id, group_id, user_id):
        """ثبت پیام در دیتابیس برای آمار و تگ کردن"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        c.execute("INSERT INTO messages (message_id, group_id, user_id, timestamp) VALUES (?, ?, ?, ?)",
                 (message_id, group_id, user_id, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        conn.commit()
        conn.close()

    def add_user_report(self, group_id, reported_user_id, reporter_user_id, message_id, report_text):
        """ثبت گزارش کاربر"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        c.execute("INSERT INTO user_reports (group_id, reported_user_id, reporter_user_id, message_id, report_text, report_time) VALUES (?, ?, ?, ?, ?, ?)",
                 (group_id, reported_user_id, reporter_user_id, message_id, report_text, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        report_id = c.lastrowid
        conn.commit()
        conn.close()
        return report_id
        
    def update_report_status(self, report_id, status, admin_response, admin_id):
        """به‌روزرسانی وضعیت گزارش"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        c.execute("UPDATE user_reports SET status = ?, admin_response = ?, responded_by = ?, response_time = ? WHERE id = ?",
                 (status, admin_response, admin_id, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), report_id))
        conn.commit()
        conn.close()
        
    def get_report_details(self, report_id):
        """دریافت جزئیات گزارش"""
        conn = sqlite3.connect(self.db_name)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT * FROM user_reports WHERE id = ?", (report_id,))
        result = c.fetchone()
        conn.close()
        
        if result:
            return {key: result[key] for key in result.keys()}
        return None

    def init_admin_abuse_tables(self):
        """ایجاد جداول مربوط به تخلف ادمین‌ها"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        
        # جدول گزارش‌های تخلف ادمین
        c.execute('''CREATE TABLE IF NOT EXISTS admin_abuse_reports
                    (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     group_id INTEGER,
                     admin_id INTEGER,
                     reporter_id INTEGER,
                     message_id INTEGER,
                     report_text TEXT,
                     status TEXT DEFAULT 'pending',
                     admin_response TEXT,
                     responded_by INTEGER,
                     report_time TEXT,
                     response_time TEXT,
                     FOREIGN KEY (group_id) REFERENCES groups (group_id),
                     FOREIGN KEY (admin_id) REFERENCES users (user_id),
                     FOREIGN KEY (reporter_id) REFERENCES users (user_id))''')
        
        # جدول اقدامات ادمین‌ها
        c.execute('''CREATE TABLE IF NOT EXISTS admin_actions
                    (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     admin_id INTEGER,
                     group_id INTEGER,
                     action_type TEXT,
                     timestamp TEXT,
                     FOREIGN KEY (admin_id) REFERENCES users (user_id),
                     FOREIGN KEY (group_id) REFERENCES groups (group_id))''')
        
        conn.commit()
        conn.close()
    
    def add_admin_abuse_report(self, group_id, admin_id, reporter_id, message_id, report_text):
        """ثبت گزارش تخلف ادمین"""
        # ابتدا اطمینان حاصل کنیم که جداول وجود دارند
        self.init_admin_abuse_tables()
        
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        c.execute("INSERT INTO admin_abuse_reports (group_id, admin_id, reporter_id, message_id, report_text, report_time) VALUES (?, ?, ?, ?, ?, ?)",
                 (group_id, admin_id, reporter_id, message_id, report_text, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        report_id = c.lastrowid
        conn.commit()
        conn.close()
        return report_id
    
    def update_admin_abuse_report_status(self, report_id, status, admin_response, responded_by):
        """به‌روزرسانی وضعیت گزارش تخلف ادمین"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        c.execute("UPDATE admin_abuse_reports SET status = ?, admin_response = ?, responded_by = ?, response_time = ? WHERE id = ?",
                 (status, admin_response, responded_by, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), report_id))
        conn.commit()
        conn.close()
    
    def get_admin_abuse_report(self, report_id):
        """دریافت جزئیات گزارش تخلف ادمین"""
        conn = sqlite3.connect(self.db_name)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT * FROM admin_abuse_reports WHERE id = ?", (report_id,))
        result = c.fetchone()
        conn.close()
        
        if result:
            return {key: result[key] for key in result.keys()}
        return None
    
    def add_admin_action(self, admin_id, group_id, action_type):
        """ثبت اقدام ادمین"""
        # ابتدا اطمینان حاصل کنیم که جداول وجود دارند
        self.init_admin_abuse_tables()
        
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        c.execute("INSERT INTO admin_actions (admin_id, group_id, action_type, timestamp) VALUES (?, ?, ?, ?)",
                 (admin_id, group_id, action_type, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        conn.commit()
        conn.close()
    
    def count_admin_actions(self, admin_id, group_id, action_type, time_window_seconds):
        """شمارش تعداد اقدامات ادمین در بازه زمانی مشخصص"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        
        # محاسبه زمان شروع بازه
        time_threshold = (datetime.now() - timedelta(seconds=time_window_seconds)).strftime("%Y-%m-%d %H:%M:%S")
        
        c.execute("""SELECT COUNT(*) FROM admin_actions 
                   WHERE admin_id = ? AND group_id = ? AND action_type = ? AND timestamp > ?""",
                 (admin_id, group_id, action_type, time_threshold))
        count = c.fetchone()[0]
        conn.close()
        return count
    
    def get_admin_recent_actions(self, admin_id, group_id):
        """دریافت آمار اقدامات اخیر ادمین"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        
        # محاسبه زمان 30 دقیقه قبل
        time_threshold = (datetime.now() - timedelta(minutes=30)).strftime("%Y-%m-%d %H:%M:%S")
        
        # دریافت تعداد هر نوع اقدام
        actions = {}
        
        for action_type in ["ban", "kick", "mute", "delete"]:
            c.execute("""SELECT COUNT(*) FROM admin_actions 
                       WHERE admin_id = ? AND group_id = ? AND action_type = ? AND timestamp > ?""",
                     (admin_id, group_id, action_type, time_threshold))
            count = c.fetchone()[0]
            actions[f"{action_type}_count"] = count
        
        conn.close()
        return actions

    def set_user_nickname(self, user_id, group_id, nickname, set_by):
        """تنظیم لقب برای کاربر در گروه"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        
        # ابتدا بررسی می‌کنیم آیا قبلاً لقبی برای این کاربر در این گروه تنظیم شده است
        c.execute("SELECT id FROM user_nicknames WHERE user_id = ? AND group_id = ?", (user_id, group_id))
        existing = c.fetchone()
        
        if existing:
            # اگر لقب قبلاً وجود داشته، آن را به‌روزرسانی می‌کنیم
            c.execute("UPDATE user_nicknames SET nickname = ?, set_by = ?, set_date = ? WHERE user_id = ? AND group_id = ?",
                     (nickname, set_by, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), user_id, group_id))
        else:
            # اگر لقب وجود نداشته، یک رکورد جدید اضافه می‌کنیم
            c.execute("INSERT INTO user_nicknames (user_id, group_id, nickname, set_by, set_date) VALUES (?, ?, ?, ?, ?)",
                     (user_id, group_id, nickname, set_by, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        
        conn.commit()
        conn.close()
        return True

    def get_user_nickname(self, user_id, group_id):
        """دریافت لقب کاربر در گروه"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        
        c.execute("SELECT nickname FROM user_nicknames WHERE user_id = ? AND group_id = ?", (user_id, group_id))
        result = c.fetchone()
        
        conn.close()
        return result[0] if result else None

    def remove_user_nickname(self, user_id, group_id):
        """حذف لقب کاربر در گروه"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        
        c.execute("DELETE FROM user_nicknames WHERE user_id = ? AND group_id = ?", (user_id, group_id))
        
        conn.commit()
        conn.close()
        return True

    def add_warning(self, user_id, group_id=None, reason="نقض قوانین گروه", warned_by=None):
        """اضافه کردن اخطار به کاربر"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        
        # اگر group_id ارسال نشده، فقط warnings counter را به‌روزرسانی می‌کنیم
        if group_id is None:
            # Legacy support - فقط counter را افزایش می‌دهیم
            c.execute("UPDATE users SET warnings = warnings + 1 WHERE user_id = ?", (user_id,))
        else:
            # ثبت اخطار در جدول warnings
            c.execute("INSERT INTO warnings (user_id, group_id, reason, warned_by, timestamp) VALUES (?, ?, ?, ?, ?)",
                     (user_id, group_id, reason, warned_by, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            
            # به‌روزرسانی counter کلی کاربر
            c.execute("UPDATE users SET warnings = warnings + 1 WHERE user_id = ?", (user_id,))
        
        conn.commit()
        conn.close()

    def remove_warning(self, user_id, group_id=None):
        """حذف یک اخطار از کاربر"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        
        if group_id is None:
            # Legacy support - فقط counter را کاهش می‌دهیم
            c.execute("UPDATE users SET warnings = MAX(0, warnings - 1) WHERE user_id = ?", (user_id,))
        else:
            # ابتدا آخرین اخطار را پیدا می‌کنیم
            c.execute("SELECT id FROM warnings WHERE user_id = ? AND group_id = ? ORDER BY timestamp DESC LIMIT 1", 
                     (user_id, group_id))
            result = c.fetchone()
            
            if result:
                # حذف آخرین اخطار
                c.execute("DELETE FROM warnings WHERE id = ?", (result[0],))
                # به‌روزرسانی counter کلی کاربر
                c.execute("UPDATE users SET warnings = MAX(0, warnings - 1) WHERE user_id = ?", (user_id,))
        
        conn.commit()
        conn.close()

    def clear_user_warnings(self, user_id, group_id=None):
        """پاک کردن تمام اخطارهای کاربر"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        
        if group_id is None:
            # پاک کردن تمام اخطارها از همه گروه‌ها
            c.execute("DELETE FROM warnings WHERE user_id = ?", (user_id,))
            c.execute("UPDATE users SET warnings = 0 WHERE user_id = ?", (user_id,))
        else:
            # پاک کردن اخطارهای مربوط به گروه خاص
            c.execute("DELETE FROM warnings WHERE user_id = ? AND group_id = ?", (user_id, group_id))
            
            # بازشماری اخطارهای باقیمانده
            c.execute("SELECT COUNT(*) FROM warnings WHERE user_id = ?", (user_id,))
            remaining_warnings = c.fetchone()[0]
            c.execute("UPDATE users SET warnings = ? WHERE user_id = ?", (remaining_warnings, user_id))
        
        conn.commit()
        conn.close()

    def ban_user(self, user_id):
        """مسدود کردن کاربر"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        
        c.execute("UPDATE users SET is_banned = 1 WHERE user_id = ?", (user_id,))
        
        conn.commit()
        conn.close()

    def unban_user(self, user_id):
        """رفع مسدودیت کاربر"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        
        c.execute("UPDATE users SET is_banned = 0 WHERE user_id = ?", (user_id,))
        
        conn.commit()
        conn.close()

    def is_user_banned(self, user_id):
        """بررسی مسدود بودن کاربر"""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        
        c.execute("SELECT is_banned FROM users WHERE user_id = ?", (user_id,))
        result = c.fetchone()
        
        conn.close()
        return bool(result[0]) if result else False


    def get_connection(self):
        """Return a SQLite connection configured with Row factory."""
        conn = sqlite3.connect(self.db_name)
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_royal_role_tables(self):
        """Create tables used by the bot-side royal role system."""
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()

        c.execute("""CREATE TABLE IF NOT EXISTS royal_roles
                    (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     group_id INTEGER NOT NULL,
                     user_id INTEGER NOT NULL,
                     role_name TEXT NOT NULL,
                     set_by INTEGER,
                     set_date TEXT,
                     UNIQUE(group_id, user_id))""")

        conn.commit()
        conn.close()

    def set_royal_role(self, group_id, user_id, role_name, set_by):
        """Assign a bot-side royal role to a user in a group."""
        self._ensure_royal_role_tables()
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        c.execute(
            "INSERT OR REPLACE INTO royal_roles (group_id, user_id, role_name, set_by, set_date) VALUES (?, ?, ?, ?, ?)",
            (group_id, user_id, role_name, set_by, datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        )
        conn.commit()
        conn.close()
        return True

    def get_royal_role(self, group_id, user_id):
        """Fetch the bot-side royal role for a user."""
        self._ensure_royal_role_tables()
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        c.execute(
            "SELECT role_name FROM royal_roles WHERE group_id = ? AND user_id = ?",
            (group_id, user_id)
        )
        result = c.fetchone()
        conn.close()
        return result[0] if result else None

    def remove_royal_role(self, group_id, user_id):
        """Remove any bot-side royal role from a user."""
        self._ensure_royal_role_tables()
        conn = sqlite3.connect(self.db_name)
        c = conn.cursor()
        c.execute("DELETE FROM royal_roles WHERE group_id = ? AND user_id = ?", (group_id, user_id))
        conn.commit()
        conn.close()
        return True

    def list_royal_roles(self, group_id):
        """Return all bot-side royal roles in a group."""
        self._ensure_royal_role_tables()
        conn = sqlite3.connect(self.db_name)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("""
            SELECT r.user_id, r.role_name, r.set_by, r.set_date,
                   u.username, u.first_name, u.last_name
            FROM royal_roles r
            LEFT JOIN users u ON u.user_id = r.user_id
            WHERE r.group_id = ?
            ORDER BY r.id ASC
        """, (group_id,))
        rows = c.fetchall()
        conn.close()
        return [dict(row) for row in rows]
