import logging
from logging.handlers import RotatingFileHandler
import os
import asyncio
import re
import pytz
try:
    import jdatetime
except Exception:
    jdatetime = None
from types import SimpleNamespace
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ChatPermissions
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters, ContextTypes
from telegram.constants import ParseMode
from config import BOT_TOKEN, ADMIN_ID, SUBSCRIPTION_CONTACT_ID, SUBSCRIPTION_CONTACT_USERNAME, PREMIUM_FEATURES
from handlers.admin import admin_panel, admin_callback
from handlers.group import welcome_new_member, warn_user, unwarn_user, check_message
from handlers.subscription import subscription_status, add_premium_group, list_premium_groups
from handlers.auto_permissions import get_auto_permission_manager
from handlers.advanced_features import (
    lock_time_messages, unlock_time_messages, set_force_join,
    unset_force_join, check_force_join_compliance
)
from handlers.moderation import mute_user_handler, promote_user_handler, demote_user_handler, special_user_handler
from handlers.broadcast import admin_broadcast_handler
from handlers.user_reports import report_command, report_callback_handler
from handlers.reports import group_activity_report, reports_callback_handler
from handlers.admin_abuse import report_admin_abuse, admin_abuse_callback_handler, setup_handlers as setup_admin_abuse_handlers
from handlers.nickname import set_nickname_handler, show_nickname_handler, remove_nickname_handler
from handlers.user_info import user_info_handler, user_info_callback_handler
from handlers.weather import weather_handler
from handlers.glass_links import (
    glass_command, glass_callback_handler, handle_glass_message,
    handle_glass_photo, handle_glass_start_parameter
)
from handlers.royal_system import (
    handle_royal_text_message,
    royal_ping_command, royal_roles_command, royal_set_role_command,
    seven_command, seven_join_command, seven_start_command, seven_play_command, seven_draw_command, seven_status_command,
    hokm_command, hokm_join_command, hokm_start_command, hokm_choose_command, hokm_play_command, hokm_status_command,
    games_command, games_callback_handler
)
from middleware.premium_check import premium_required, check_group_premium_status
from database.database import Database
from database.premium import PremiumManager
import requests
from currency_api import CurrencyAPI as FullCurrencyAPI

# Define payment-related variables directly in main.py
PAYMENT_CARD_NUMBER = "1234-5678-9012-3456"  # شماره کارت بانکی (اینجا نمونه است، با شماره واقعی جایگزین کنید)
PAYMENT_INSTRUCTIONS = """
<b>لطفاً برای خرید اشتراک با ادمین تماس بگیرید:</b>
<a href="tg://user?id={SUBSCRIPTION_CONTACT_ID}">@{username}</a>
<b>🆔 آیدی گروه:</b> {group_id}
<b>💳 شماره کارت:</b> {card_number}
<b>💳 مبلغ قابل پرداخت:</b> {price:,} تومان
"""

# Create logs directory if not exists
if not os.path.exists('logs'):
    os.makedirs('logs')

# Set up file handler
file_handler = RotatingFileHandler(
    'logs/bot.log',
    maxBytes=10485760,  # 10MB
    backupCount=5,
    encoding='utf-8'
)

# Set up console handler
console_handler = logging.StreamHandler()

# Set up logging format
log_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(log_format)
console_handler.setFormatter(log_format)

# Configure root logger
logging.basicConfig(
    level=logging.INFO,
    handlers=[file_handler, console_handler]
)

logger = logging.getLogger(__name__)

# Initialize database
db = Database("group_manager.db")
premium_manager = PremiumManager("group_manager.db")

# Initialize auto permission manager
auto_permission_manager = get_auto_permission_manager(premium_manager)

# Premium groups list (will be loaded from database)
premium_groups_cache = set()

# Persian command mapping (without slash)
PERSIAN_COMMANDS = {
    'شروع': 'start',
    'راهنما': 'help',
    'پنل': 'admin',
    'کمک': 'help',
    'اشتراک': 'subscription',
    'اخطار': 'warn',
    'حذف_اخطار': 'unwarn',
    'ادمین': 'admin',
    'قفل_زمانی': 'locktime',
    'باز_کردن_قفل': 'unlocktime',
    'جوین_اجباری': 'forcejoin',
    'حذف_جوین_اجباری': 'unforcejoin',
    'بن': 'ban',
    'رفع_بن': 'unban',  # اضافه کردن دستور رفع بن
    'اخراج': 'kick',
    'حذف': 'delete',
    'سکوت': 'mute',
    'رفع_سکوت': 'unmute',
    'لیست_ساکت': 'mutelist',
    'پیام_همگانی': 'broadcast',
    'ساعت': 'time',
    'تاریخ': 'time',
    'زمان': 'time',
    'شروع_ویس': 'startvoice',
    'قطع_ویس': 'stopvoice',
    'پین': 'pin',
    'حذف_پین': 'unpin',
    'خرید_اشتراک': 'buypremium',
    'ارتقا': 'promote',  # اضافه کردن دستور ارتقا
    'عزل': 'demote',     # اضافه کردن دستور عزل
    'ویژه': 'special',   # اضافه کردن دستور ویژه
    'گزارش': 'report',     # اضافه کردن دستور گزارش
    'گزارش_ادمین': 'reportadmin',  # اضافه کردن دستور گزارش ادمین
    'آب و هوا': 'weather',  # اضافه کردن دستور آب و هوا
    'لقب': 'nickname',      # اضافه کردن دستور نمایش لقب
    'تنظیم لقب': 'setnickname',  # اضافه کردن دستور تنظیم لقب
    'حذف لقب': 'removenickname',  # اضافه کردن دستور حذف لقب
    'اطلاعات': 'userinfo',   # اضافه کردن دستور اطلاعات کاربر
    'آمار کاربر': 'userinfo',  # اضافه کردن دستور آمار کاربر
    'اکو': 'echo',  # اضافه کردن دستور اکو
    'لینک شیشه‌ای': 'glass',  # اضافه کردن دستور لینک شیشه‌ای
    'شیشه': 'glass',  # اضافه کردن دستور کوتاه شیشه
    'پنل': 'panel',  # اضافه کردن دستور پنل
    'سودو': 'sudo',   # اضافه کردن دستور سودو
    'آمار': 'stats',  # اضافه کردن دستور آمار
    'آمار_مدیران': 'stats',  # اضافه کردن دستور آمار مدیران
    'دسترسی_مدیران': 'stats',  # اضافه کردن دستور دسترسی مدیران
    'آمار_محتوا': 'stats',  # اضافه کردن دستور آمار محتوا
    'آمار_چت': 'stats',  # اضافه کردن دستور آمار چت
    'آمار_ادد': 'stats',  # اضافه کردن دستور آمار ادد
    'آمار_امروز': 'stats',  # اضافه کردن دستور آمار امروز
}

# Muted users dictionary: {(chat_id, user_id): {'unmute_time': datetime, 'muted_by': user_id}}
muted_users = {}

# Subscription plans
SUBSCRIPTION_PLANS = {
    'monthly': {'name': 'ماهانه', 'price': 50000, 'days': 30},
    'quarterly': {'name': 'سه ماهه', 'price': 121000, 'days': 90},
    'semiannual': {'name': 'شش ماهه', 'price': 211000, 'days': 180},
    'annual': {'name': 'سالانه', 'price': 351000, 'days': 365}
}

def load_premium_groups():
    """Load premium groups from database into cache"""
    global premium_groups_cache
    try:
        groups = premium_manager.get_all_premium_groups()
        premium_groups_cache = {
            group['group_id'] for group in groups
            if group['is_active'] and premium_manager.is_group_premium(group['group_id'])
        }
        logger.info(f"Loaded {len(premium_groups_cache)} premium groups into cache")
    except Exception as e:
        logger.error(f"Error loading premium groups: {str(e)}")

async def send_premium_required_message(update: Update, context: ContextTypes.DEFAULT_TYPE = None, feature_name: str = "این قابلیت"):
    """Send premium required message for any feature"""
    group_id = update.effective_chat.id

    message = f"""🔒 {feature_name} نیاز به اشتراک پرمیوم دارد!\n\n💎 برای استفاده از امکانات ربات، نیاز به خرید اشتراک دارید.\n\n👨‍💼 برای خرید اشتراک با ادمین تماس بگیرید:\n@{SUBSCRIPTION_CONTACT_USERNAME}\n🆔 آیدی خریدار: `{SUBSCRIPTION_CONTACT_ID}`\n\n📋 پلن‌های اشتراک:\n• ماهانه: ۵۰,۰۰۰ تومان (۳۰ روز)\n• سه ماهه: ۱۲۱,۰۰۰ تومان (۹۰ روز)\n• شش ماهه: ۲۱۱,۰۰۰ تومان (۱۸۰ روز)\n• سالانه: ۳۵۱,۰۰۰ تومان (۳۶۵ روز)\n\n🆔 آیدی گروه برای خرید: `{group_id}`\n\n✨ امکانات اشتراک پرمیوم:\n• سیستم اخطار خودکار\n• ضد لینک و ضد فحش\n• خوش‌آمدگویی خودکار\n• قفل تایم‌دار پیام همگانی\n• جوین اجباری چنل\n• پیام همگانی در تمام گروه‌ها\n• مدیریت کامل گروه\n• پشتیبانی ۲۴ ساعته"""
    try:
        await update.message.reply_text(message, parse_mode='Markdown')
    except Exception as e:
        logger.error(f"Error in send_premium_required_message: {str(e)}")
        try:
            # Try to send a new message instead of replying
            if context and context.bot:
                await context.bot.send_message(chat_id=group_id, text=message, parse_mode='Markdown')
        except Exception as inner_e:
            logger.error(f"Failed to send alternative premium message: {str(inner_e)}")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send a message when the command /start is issued."""
    try:
        # Check for glass link parameter
        if context.args and context.args[0].startswith('glass_'):
            handled = await handle_glass_start_parameter(update, context)
            if handled:
                return

        message = (
            "سلام! من ربات مدیریت گروه هستم.\n"
            "برای دیدن دستورات از /help استفاده کنید.\n"
            "برای بررسی وضعیت اشتراک از /subscription استفاده کنید."
        )

        if update.effective_chat.type == "private":
            if update.effective_user.id == ADMIN_ID:
                keyboard = [
                    [InlineKeyboardButton("🔧 پنل مدیریت", callback_data='admin_panel')],
                    [InlineKeyboardButton("📊 آمار ربات", callback_data='bot_stats')],
                    [InlineKeyboardButton("💎 مدیریت اشتراک‌ها", callback_data='manage_subscriptions')],
                    [InlineKeyboardButton("💎 خرید اشتراک", callback_data='buy_premium')],
                    [InlineKeyboardButton("📚 راهنما", callback_data='help')]
                ]
            else:
                keyboard = [
                    [InlineKeyboardButton("➕ افزودن به گروه", url=f"https://t.me/{context.bot.username}?startgroup=true")],
                    [InlineKeyboardButton("💎 خرید اشتراک", callback_data='buy_premium')],
                    [InlineKeyboardButton("📚 راهنما", callback_data='help')]
                ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await update.message.reply_text(message, reply_markup=reply_markup, parse_mode='Markdown')
        else:
            keyboard = [
                [InlineKeyboardButton("💎 خرید اشتراک", callback_data='buy_premium')],
                [InlineKeyboardButton("📚 راهنما", callback_data='help')],
                [InlineKeyboardButton("📋 بررسی اشتراک", callback_data='check_subscription')]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            await update.message.reply_text(message, reply_markup=reply_markup, parse_mode='Markdown')

        logger.info(f"Start command executed by user {update.effective_user.id} in chat {update.effective_chat.id}")

    except Exception as e:
        logger.error(f"Error in start command: {str(e)}")
        await update.message.reply_text("خطایی رخ داد. لطفاً دوباره تلاش کنید.")

async def buy_premium(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle the /buypremium command to initiate subscription purchase"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است. لطفاً ربات را به گروه خود اضافه کنید و این دستور را در گروه اجرا کنید.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند اشتراک خریداری کنند.")
            return

        # Check if group already has an active premium subscription
        group_id = update.effective_chat.id
        if premium_manager.is_group_premium(group_id):
            subscription_info = premium_manager.get_group_subscription_info(group_id)
            expiry_date_str = subscription_info['subscription_end'] if subscription_info else "نامشخص"
            await update.message.reply_text(
                f"این گروه در حال حاضر اشتراک پرمیوم فعال دارد.\n"
                f"📅 تاریخ انقضا: {expiry_date_str}\n"
                f"برای تمدید یا تغییر پلن، با ادمین تماس بگیرید: @{SUBSCRIPTION_CONTACT_USERNAME}"
            )
            return

        # Create inline keyboard with subscription plans
        keyboard = [
            [InlineKeyboardButton(f"{plan['name']}: {plan['price']:,} تومان ({plan['days']} روز)",
                                callback_data=f"select_plan:{plan_id}")]
            for plan_id, plan in SUBSCRIPTION_PLANS.items()
        ]
        keyboard.append([InlineKeyboardButton("لغو", callback_data='cancel_buy_premium')])
        reply_settings = InlineKeyboardMarkup(keyboard)

        await update.message.reply_text(
            "📋 لطفاً یکی از پلن‌های اشتراک را انتخاب کنید:",
            reply_markup=reply_settings
        )
        logger.info(f"User {update.effective_user.id} initiated subscription purchase in chat {group_id}")

    except Exception as e:
        logger.error(f"Error in buy_premium: {str(e)}")
        await update.message.reply_text(f"خطا در خرید اشتراک: {str(e)}")

async def handle_subscription_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle callback queries for subscription purchase and other inline buttons"""
    query = update.callback_query
    await query.answer()  # Acknowledge the callback query

    try:
        data = query.data
        user_id = query.from_user.id
        chat_id = query.message.chat.id if query.message.chat.type != "private" else None

        logger.info(f"Callback received: {data} from user {user_id} in chat {chat_id}")

        if data == 'help':
            await help_command(query, context)
            return

        if data == 'cancel_buy_premium':
            await query.message.delete()
            if chat_id:
                await context.bot.send_message(chat_id, "خرید اشتراک لغو شد.")
            logger.info(f"User {user_id} cancelled subscription purchase")
            return

        if data == 'check_subscription':
            group_id = query.message.chat.id
            if premium_manager.is_group_premium(group_id):
                subscription_info = premium_manager.get_group_subscription_info(group_id)
                expiry_date_str = subscription_info['subscription_end'] if subscription_info else "نامشخص"
                await query.message.reply_text(
                    f"📊 وضعیت اشتراک گروه:\n"
                    f"💎 اشتراک پرمیوم فعال است\n"
                    f"📅 تاریخ انقضا: {expiry_date_str}"
                )
            else:
                await query.message.reply_text(
                    "❌ این گروه اشتراک پرمیوم فعالی ندارد.\n"
                    "برای خرید اشتراک از /buypremium استفاده کنید."
                )
            return

        if data == 'buy_premium':
            if query.message.chat.type == "private":
                await query.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است. لطفاً ربات را به گروه خود اضافه کنید و این دستور را در گروه اجرا کنید.")
                return

            # Check if user is admin
            chat_member = await context.bot.get_chat_member(query.message.chat.id, user_id)
            if chat_member.status not in ['administrator', 'creator'] and user_id != ADMIN_ID:
                await query.message.reply_text("فقط ادمین‌های گروه می‌توانند اشتراک خریداری کنند.")
                return

            # Check if group already has an active premium subscription
            group_id = query.message.chat.id
            if premium_manager.is_group_premium(group_id):
                subscription_info = premium_manager.get_group_subscription_info(group_id)
                expiry_date_str = subscription_info['subscription_end'] if subscription_info else "نامشخص"
                await query.message.reply_text(
                    f"این گروه در حال حاضر اشتراک پرمیوم فعال دارد.\n"
                    f"📅 تاریخ انقضا: {expiry_date_str}\n"
                    f"برای تمدید یا تغییر پلن، با ادمین تماس بگیرید: @{SUBSCRIPTION_CONTACT_USERNAME}"
                )
                return

            # Create inline keyboard with subscription plans
            keyboard = [
                [InlineKeyboardButton(f"{plan['name']}: {plan['price']:,} تومان ({plan['days']} روز)",
                                    callback_data=f"select_plan:{plan_id}")]
                for plan_id, plan in SUBSCRIPTION_PLANS.items()
            ]
            keyboard.append([InlineKeyboardButton("لغو", callback_data='cancel_buy_premium')])
            reply_settings = InlineKeyboardMarkup(keyboard)

            await query.message.reply_text(
                "📋 لطفاً یکی از پلن‌های اشتراک را انتخاب کنید:",
                reply_markup=reply_settings
            )
            logger.info(f"User {user_id} initiated subscription purchase via callback in chat {group_id}")
            return

        if data.startswith('select_plan:'):
            plan_id = data.split(':')[1]
            if plan_id not in SUBSCRIPTION_PLANS:
                await query.message.reply_text("پلن انتخاب‌شده معتبر نیست.")
                return

            plan = SUBSCRIPTION_PLANS[plan_id]

            # Send payment instructions in private chat
            instructions = PAYMENT_INSTRUCTIONS.format(
                SUBSCRIPTION_CONTACT_ID=SUBSCRIPTION_CONTACT_ID,
                username=SUBSCRIPTION_CONTACT_USERNAME,
                group_id=chat_id,
                card_number=PAYMENT_CARD_NUMBER,
                price=plan['price']
            )

            await context.bot.send_message(
                chat_id=user_id,
                text=instructions,
                parse_mode='HTML'
            )

            # Delete the plan selection message in group
            await query.message.delete()

            # Notify group
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"✅ <b>درخواست اشتراک ثبت شد</b>\n\n"
                     f"👤 درخواست کننده: {query.from_user.first_name}\n"
                     f"📋 پلن انتخابی: <b>{plan['name']}</b>\n"
                     f"💰 مبلغ: <b>{plan['price']:,} تومان</b>\n\n"
                     f"📞 برای تکمیل خرید با @{SUBSCRIPTION_CONTACT_USERNAME} تماس بگیرید.\n"
                     f"💡 اطلاعات پرداخت به صورت خصوصی ارسال شد.",
                parse_mode='HTML'
            )

            # Get group info for admin notification
            try:
                chat_info = await context.bot.get_chat(chat_id)
                group_title = chat_info.title
                group_members_count = await context.bot.get_chat_member_count(chat_id)
            except:
                group_title = "نامشخص"
                group_members_count = "نامشخص"

            # Create admin notification with action buttons
            admin_message = (
                f"🛒 <b>درخواست خرید اشتراک جدید</b>\n\n"
                f"👤 <b>مشتری:</b> {query.from_user.first_name}\n"
                f"🆔 <b>آیدی کاربر:</b> <code>{user_id}</code>\n"
                f"👑 <b>نام کاربری:</b> @{query.from_user.username or 'ندارد'}\n\n"
                f"🏢 <b>اطلاعات گروه:</b>\n"
                f"📝 نام: {group_title}\n"
                f"🆔 آیدی گروه: <code>{chat_id}</code>\n"
                f"👥 تعداد اعضا: {group_members_count}\n\n"
                f"💎 <b>جزئیات اشتراک:</b>\n"
                f"📋 پلن: <b>{plan['name']}</b>\n"
                f"💰 مبلغ: <b>{plan['price']:,} تومان</b>\n"
                f"📅 مدت: <b>{plan['days']} روز</b>\n\n"
                f"🕐 <b>زمان درخواست:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                f"📱 <b>وضعیت:</b> در انتظار تأیید"
            )

            # Create inline keyboard for admin actions
            admin_keyboard = [
                [
                    InlineKeyboardButton("✅ تأیید و فعال‌سازی", callback_data=f"approve_sub_{chat_id}_{plan_id}"),
                    InlineKeyboardButton("❌ رد درخواست", callback_data=f"reject_sub_{chat_id}_{user_id}")
                ],
                [
                    InlineKeyboardButton("📞 تماس با مشتری", url=f"tg://user?id={user_id}"),
                    InlineKeyboardButton("🏢 مشاهده گروه", url=f"https://t.me/c/{str(chat_id)[4:]}/1" if str(chat_id).startswith('-100') else f"tg://resolve?domain={chat_id}")
                ],
                [
                    InlineKeyboardButton("📊 آمار گروه", callback_data=f"group_stats_{chat_id}"),
                    InlineKeyboardButton("📋 تاریخچه اشتراک", callback_data=f"sub_history_{chat_id}")
                ]
            ]
            admin_reply_markup = InlineKeyboardMarkup(admin_keyboard)

            # Notify admin
            await context.bot.send_message(
                chat_id=ADMIN_ID,
                text=admin_message,
                parse_mode='HTML',
                reply_markup=admin_reply_markup
            )

            logger.info(f"User {user_id} selected plan {plan_id} for chat {chat_id}")
            return

        # Handle admin actions for subscription requests
        if data.startswith('approve_sub_'):
            # Only allow admin to approve
            if query.from_user.id != ADMIN_ID:
                await query.answer("⛔️ فقط ادمین اصلی می‌تواند اشتراک‌ها را تأیید کند!", show_alert=True)
                return

            parts = data.split('_')
            if len(parts) >= 4:
                target_chat_id = int(parts[2])
                plan_id = parts[3]

                # Add group to premium
                success = premium_manager.add_premium_subscription(
                    group_id=target_chat_id,
                    buyer_id=user_id,
                    buyer_username=query.from_user.username or "نامشخص",
                    duration_days=SUBSCRIPTION_PLANS[plan_id]['days']
                )

                if success:
                    # Update premium groups cache
                    load_premium_groups()

                    await query.edit_message_text(
                        f"✅ <b>اشتراک فعال شد!</b>\n\n"
                        f"🏢 گروه: <code>{target_chat_id}</code>\n"
                        f"📋 پلن: {SUBSCRIPTION_PLANS[plan_id]['name']}\n"
                        f"✅ وضعیت: فعال\n"
                        f"🕐 تاریخ تأیید: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                        parse_mode='HTML'
                    )

                    # Notify the group
                    try:
                        await context.bot.send_message(
                            chat_id=target_chat_id,
                            text=f"🎉 <b>اشتراک پرمیوم فعال شد!</b>\n\n"
                                 f"💎 پلن: <b>{SUBSCRIPTION_PLANS[plan_id]['name']}</b>\n"
                                 f"📅 مدت: <b>{SUBSCRIPTION_PLANS[plan_id]['days']} روز</b>\n"
                                 f"✨ تمام قابلیت‌های پرمیوم اکنون در دسترس است!",
                            parse_mode='HTML'
                        )
                    except:
                        pass
                else:
                    await query.answer("❌ خطا در فعال‌سازی اشتراک!", show_alert=True)
            return

        if data.startswith('reject_sub_'):
            # Only allow admin to reject
            if query.from_user.id != ADMIN_ID:
                await query.answer("⛔️ فقط ادمین اصلی می‌تواند درخواست‌ها را رد کند!", show_alert=True)
                return

            parts = data.split('_')
            if len(parts) >= 4:
                target_chat_id = int(parts[2])
                target_user_id = int(parts[3])

                await query.edit_message_text(
                    f"❌ <b>درخواست رد شد</b>\n\n"
                    f"🏢 گروه: <code>{target_chat_id}</code>\n"
                    f"👤 کاربر: <code>{target_user_id}</code>\n"
                    f"🕐 تاریخ رد: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                    parse_mode='HTML'
                )

                # Notify the user
                try:
                    await context.bot.send_message(
                        chat_id=target_user_id,
                        text="❌ متأسفانه درخواست اشتراک شما رد شد.\n"
                             "برای اطلاعات بیشتر با ادمین تماس بگیرید.",
                    )
                except:
                    pass
            return

        if data.startswith('group_stats_'):
            # Only allow admin to view stats
            if query.from_user.id != ADMIN_ID:
                await query.answer("⛔️ فقط ادمین اصلی می‌تواند آمار گروه‌ها را مشاهده کند!", show_alert=True)
                return

            target_chat_id = int(data.split('_')[2])

            try:
                chat_info = await context.bot.get_chat(target_chat_id)
                member_count = await context.bot.get_chat_member_count(target_chat_id)

                # Get more stats from database
                total_messages = db.count_user_messages(None, target_chat_id) if hasattr(db, 'count_group_messages') else "نامشخص"

                stats_msg = (
                    f"📊 <b>آمار گروه</b>\n\n"
                    f"📝 نام: {chat_info.title}\n"
                    f"🆔 آیدی: <code>{target_chat_id}</code>\n"
                    f"👥 تعداد اعضا: {member_count}\n"
                    f"💬 تعداد پیام‌ها: {total_messages}\n"
                    f"🎯 نوع گروه: {chat_info.type}\n"
                    f"📅 تاریخ بررسی: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                )

                await query.answer()
                await context.bot.send_message(
                    chat_id=query.message.chat.id,
                    text=stats_msg,
                    parse_mode='HTML'
                )
            except Exception as e:
                await query.answer(f"❌ خطا در دریافت آمار: {str(e)}", show_alert=True)
            return

        if data.startswith('sub_history_'):
            # Only allow admin to view history
            if query.from_user.id != ADMIN_ID:
                await query.answer("⛔️ فقط ادمین اصلی می‌تواند تاریخچه اشتراک را مشاهده کند!", show_alert=True)
                return

            target_chat_id = int(data.split('_')[2])

            # Get subscription history (if available)
            is_premium = premium_manager.is_group_premium(target_chat_id)

            history_msg = (
                f"📋 <b>تاریخچه اشتراک گروه</b>\n\n"
                f"🆔 آیدی گروه: <code>{target_chat_id}</code>\n"
                f"💎 وضعیت فعلی: {'✅ پرمیوم' if is_premium else '❌ رایگان'}\n"
                f"📅 تاریخ بررسی: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                f"💡 برای اطلاعات بیشتر از پنل مدیریت استفاده کنید."
            )

            await query.answer()
            await context.bot.send_message(
                chat_id=query.message.chat.id,
                text=history_msg,
                parse_mode='HTML'
            )
            return

    except Exception as e:
        logger.error(f"Error in handle_subscription_callback: {str(e)}")
        await query.message.reply_text(f"خطا در پردازش درخواست: {str(e)}")

async def premium_check_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Check message with premium verification for anti-link and anti-profanity"""
    if update.effective_chat.type == "private":
        return

    group_id = update.effective_chat.id

    # Check if group is premium for anti-link and anti-profanity features
    if not check_group_premium_status(group_id, premium_groups_cache, premium_manager):
        message_text = update.message.text or update.message.caption or ""

        # Simple link detection
        link_keywords = ['http', 'https', 'www.', 't.me', 'telegram.me', '@']
        if any(keyword in message_text.lower() for keyword in link_keywords):
            if PREMIUM_FEATURES.get("anti_link", False):
                await send_premium_required_message(update, context, "قابلیت ضد لینک")
                return

        # Simple profanity detection
        profanity_words = ['کیر', 'کس', 'جنده', 'فاحشه', 'کونی', 'سگ']
        if any(word in message_text for word in profanity_words):
            if PREMIUM_FEATURES.get("anti_profanity", False):
                await send_premium_required_message(update, context, "قابلیت ضد فحش")
                return

    # If premium or no restricted content, execute normal check
    return await check_message(update, context)

# List of responses for the bot when someone mentions "ربات"
BOT_RESPONSES = ["چیه؟", "ها؟", "جونم؟", "چیه بزبزقندی؟", "بله؟", "در خدمتم", "جان دلم؟", "بفرمایید", "امر کنید", "چی شده؟", "اینجام", "گوش به فرمانم"]

# Counter to track which response to use
bot_response_counter = 0

async def handle_bot_mention(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle when someone mentions the word 'ربات' in a message"""
    global bot_response_counter

    if not update.message or not update.message.text:
        return False

    text = update.message.text.strip()

    # Check if the message contains only the word "ربات"
    if text == "ربات":
        # Get the next response from the list
        response = BOT_RESPONSES[bot_response_counter % len(BOT_RESPONSES)]

        # Increment the counter for next time
        bot_response_counter += 1

        # Reply to the message
        await update.message.reply_text(response)
        return True

    return False

async def premium_check_message_advanced(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Enhanced message checking with all premium features"""
    if update.effective_chat.type == "private":
        return

    group_id = update.effective_chat.id

    # First check if this is a royal text command
    if update.message and update.message.text:
        royal_result = await handle_royal_text_message(update, context)
        if royal_result:
            return

    # First check if this is a Persian command
    if update.message and update.message.text:
        command_result = await handle_persian_commands(update, context)
        if command_result:
            return

    # Check if someone mentioned the bot
    if update.message and update.message.text:
        bot_mentioned = await handle_bot_mention(update, context)
        if bot_mentioned:
            return

    # Handle glass links messages in group
    if update.message.text:
        glass_handled = await handle_glass_message(update, context)
        if glass_handled:
            return
    elif update.message.photo:
        glass_handled = await handle_glass_photo(update, context)
        if glass_handled:
            return

    # Continue with existing premium checks
    await premium_check_message(update, context)

async def premium_welcome_new_member(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Welcome new member with premium check"""
    if update.effective_chat.type == "private":
        return

    group_id = update.effective_chat.id

    # Check if group is premium
    if not check_group_premium_status(group_id, premium_groups_cache, premium_manager):
        if PREMIUM_FEATURES.get("welcome_message", False):
            try:
                await send_premium_required_message(update, context, "پیام خوش‌آمدگویی")
            except Exception as e:
                # Handle case where message might not exist or can't be replied to
                logger.error(f"Error sending premium required message: {str(e)}")
                try:
                    # Try to send a new message instead of replying
                    message = f"""🔒 پیام خوش‌آمدگویی نیاز به اشتراک پرمیوم دارد!\n\n💎 برای استفاده از امکانات ربات، نیاز به خرید اشتراک دارید.\n\n👨‍💼 برای خرید اشتراک با ادمین تماس بگیرید:\n@{SUBSCRIPTION_CONTACT_USERNAME}\n🆔 آیدی خریدار: `{SUBSCRIPTION_CONTACT_ID}`\n\n📋 پلن‌های اشتراک:\n• ماهانه: ۵۰,۰۰۰ تومان (۳۰ روز)\n• سه ماهه: ۱۲۱,۰۰۰ تومان (۹۰ روز)\n• شش ماهه: ۲۱۱,۰۰۰ تومان (۱۸۰ روز)\n• سالانه: ۳۵۱,۰۰۰ تومان (۳۶۵ روز)\n\n🆔 آیدی گروه برای خرید: `{group_id}`\n\n✨ امکانات اشتراک پرمیوم:\n• سیستم اخطار خودکار\n• ضد لینک و ضد فحش\n• خوش‌آمدگویی خودکار\n• قفل تایم‌دار پیام همگانی\n• جوین اجباری چنل\n• پیام همگانی در تمام گروه‌ها\n• مدیریت کامل گروه\n• پشتیبانی ۲۴ ساعته"""
                    await context.bot.send_message(chat_id=group_id, text=message, parse_mode='Markdown')
                except Exception as inner_e:
                    logger.error(f"Error sending alternative premium message: {str(inner_e)}")
            return

    # If premium or feature not restricted, execute welcome
    try:
        return await welcome_new_member(update, context)
    except Exception as e:
        logger.error(f"Error in welcome_new_member: {str(e)}")
        # Don't try to send error message as it might cause another error

@premium_required
async def premium_warn_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Warn user with premium check"""
    return await warn_user(update, context)

@premium_required
async def premium_unwarn_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unwarn user with premium check"""
    return await unwarn_user(update, context)

@premium_required
async def premium_admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Admin panel with premium check"""
    return await admin_panel(update, context)

@premium_required
async def premium_lock_time_messages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Lock time messages with premium check"""
    return await lock_time_messages(update, context)

@premium_required
async def premium_unlock_time_messages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unlock time messages with premium check"""
    return await unlock_time_messages(update, context)

@premium_required
async def premium_set_force_join(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Set force join with premium check"""
    return await set_force_join(update, context)

@premium_required
async def premium_unset_force_join(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unset force join with premium check"""
    return await unset_force_join(update, context)

async def ban_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ban user from the group"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند از این دستور استفاده کنند.")
            return

        # Check if message is a reply
        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً این دستور را در پاسخ به پیام کاربر مورد نظر استفاده کنید.")
            return

        user_to_ban = update.message.reply_to_message.from_user

        # Don't ban admins
        target_member = await context.bot.get_chat_member(update.effective_chat.id, user_to_ban.id)
        if target_member.status in ['administrator', 'creator']:
            await update.message.reply_text("نمی‌توان ادمین‌ها را مسدود کرد.")
            return

        # Ban the user
        await context.bot.ban_chat_member(update.effective_chat.id, user_to_ban.id)

        await update.message.reply_text(f"کاربر {user_to_ban.first_name} از گروه مسدود شد.")

    except Exception as e:
        logger.error(f"Error in ban_user: {str(e)}")
        await update.message.reply_text(f"خطا در مسدود کردن کاربر: {str(e)}")

async def unban_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unban a user from the group"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند از این دستور استفاده کنند.")
            return

        # Check if message is a reply
        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً این دستور را در پاسخ به پیام کاربر مورد نظر استفاده کنید.")
            return

        user_to_unban = update.message.reply_to_message.from_user

        # Unban the user
        await context.bot.unban_chat_member(update.effective_chat.id, user_to_unban.id, only_if_banned=True)

        await update.message.reply_text(f"کاربر {user_to_unban.first_name} از لیست افراد مسدود شده خارج شد.")

    except Exception as e:
        logger.error(f"Error in unban_user: {str(e)}")
        await update.message.reply_text(f"خطا در رفع مسدودیت کاربر: {str(e)}")

@premium_required
async def premium_ban_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Ban user with premium check"""
    return await ban_user(update, context)

@premium_required
async def premium_unban_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unban user with premium check"""
    return await unban_user(update, context)
async def premium_kick_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Kick user with premium check"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند از این دستور استفاده کنید.")
            return

        # Check if message is a reply
        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً این دستور را در پاسخ به پیام کاربر مورد نظر استفاده کنید.")
            return

        user_to_kick = update.message.reply_to_message.from_user

        # Don't kick admins
        target_member = await context.bot.get_chat_member(update.effective_chat.id, user_to_kick.id)
        if target_member.status in ['administrator', 'creator']:
            await update.message.reply_text("نمی‌توان ادمین‌ها را اخراج کرد.")
            return

        # Kick the user (ban and then unban)
        await context.bot.ban_chat_member(update.effective_chat.id, user_to_kick.id)
        await context.bot.unban_chat_member(update.effective_chat.id, user_to_kick.id)

        await update.message.reply_text(f"کاربر {user_to_kick.first_name} از گروه اخراج شد.")

    except Exception as e:
        logger.error(f"Error in kick_user: {str(e)}")
        await update.message.reply_text(f"خطا در اخراج کاربر: {str(e)}")

@premium_required
async def premium_mute_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Mute user with premium check and optional time duration"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند از این دستور استفاده کنند.")
            return

        # Check if message is a reply
        if not update.message.reply_to_message:
            await update.message.reply_text(
                "لطفاً این دستور را در پاسخ به پیام کاربر مورد نظر استفاده کنید.\n\n"
                "مثال:\n"
                "• سکوت (سکوت دائمی)\n"
                "• سکوت 1h (سکوت برای ۱ ساعت)\n"
                "• سکوت 30m (سکوت برای ۳۰ دقیقه)\n"
                "• سکوت 2d (سکوت برای ۲ روز)\n"
                "• سکوت 1h30m (سکوت برای ۱ ساعت و ۳۰ دقیقه)"
            )
            return

        user_to_mute = update.message.reply_to_message.from_user
        chat_id = update.effective_chat.id
        muter_id = update.effective_user.id

        # Don't mute admins
        target_member = await context.bot.get_chat_member(chat_id, user_to_mute.id)
        if target_member.status in ['administrator', 'creator']:
            await update.message.reply_text("نمی‌توان ادمین‌ها را ساکت کرد.")
            return

        # Parse time duration from command arguments
        duration = None
        duration_text = "دائمی"
        unmute_time = None

        if context.args:
            time_str = context.args[0]
            duration = parse_time_duration(time_str)
            if duration:
                unmute_time = datetime.now() + duration
                duration_text = format_time_duration(duration)
            else:
                await update.message.reply_text(
                    "فرمت زمان نادرست است.\n\n"
                    "فرمت صحیح: 1d2h30m (۱ روز، ۲ ساعت، ۳۰ دقیقه)\n"
                    "مثال‌ها: 1h, 30m, 2d, 1h30m"
                )
                return

        # Check if user is already muted
        mute_key = (chat_id, user_to_mute.id)
        if mute_key in muted_users:
            existing_unmute_time = muted_users[mute_key].get('unmute_time')
            if existing_unmute_time and existing_unmute_time > datetime.now():
                remaining = existing_unmute_time - datetime.now()
                await update.message.reply_text(
                    f"کاربر {user_to_mute.first_name} در حال حاضر ساکت است.\n"
                    f"زمان باقیمانده: {format_time_duration(remaining)}"
                )
                return

        # Mute the user by restricting their permissions
        mute_permissions = ChatPermissions(
            can_send_messages=False,
            can_send_polls=False,
            can_send_other_messages=False,
            can_add_web_page_previews=False,
            can_change_info=False,
            can_invite_users=False,
            can_pin_messages=False,
            can_send_audios=False,
            can_send_documents=False,
            can_send_photos=False,
            can_send_videos=False,
            can_send_video_notes=False,
            can_send_voice_notes=False
        )

        await context.bot.restrict_chat_member(
            chat_id=chat_id,
            user_id=user_to_mute.id,
            permissions=mute_permissions
        )

        # Store mute information
        muted_users[mute_key] = {
            'unmute_time': unmute_time,
            'muted_by': muter_id,
            'muted_at': datetime.now(),
            'chat_id': chat_id,
            'user_id': user_to_mute.id,
            'user_name': user_to_mute.first_name
        }

        # Send confirmation message
        mute_message = f"🔇 کاربر {user_to_mute.first_name} ساکت شد."
        if duration:
            mute_message += f"\n⏰ مدت زمان: {duration_text}"
            mute_message += f"\n📅 تا تاریخ: {unmute_time.strftime('%Y-%m-%d %H:%M:%S')}"
        else:
            mute_message += "\n⏰ مدت زمان: دائمی"

        await update.message.reply_text(mute_message)

        logger.info(f"User {user_to_mute.id} muted in chat {chat_id} by {muter_id} for {duration_text}")

    except Exception as e:
        logger.error(f"Error in mute_user: {str(e)}")
        await update.message.reply_text(f"خطا در ساکت کردن کاربر: {str(e)}")

async def auto_unmute_user(chat_id, user_id, bot):
    """Automatically unmute user when time expires"""
    try:
        mute_key = (chat_id, user_id)
        if mute_key not in muted_users:
            return

        mute_info = muted_users[mute_key]
        user_name = mute_info.get('user_name', 'کاربر')

        # Restore normal permissions
        normal_permissions = ChatPermissions(
            can_send_messages=True,
            can_send_polls=True,
            can_send_other_messages=True,
            can_add_web_page_previews=True,
            can_change_info=False,
            can_invite_users=True,
            can_pin_messages=False,
            can_send_audios=True,
            can_send_documents=True,
            can_send_photos=True,
            can_send_videos=True,
            can_send_video_notes=True,
            can_send_voice_notes=True
        )

        await bot.restrict_chat_member(
            chat_id=chat_id,
            user_id=user_id,
            permissions=normal_permissions
        )

        # Remove from muted users
        del muted_users[mute_key]

        # Send notification message
        await bot.send_message(
            chat_id=chat_id,
            text=f"🔊 سکوت کاربر {user_name} به صورت خودکار برداشته شد."
        )

        logger.info(f"User {user_id} automatically unmuted in chat {chat_id}")

    except Exception as e:
        logger.error(f"Error in auto_unmute_user: {str(e)}")
        # Remove from muted users even if unmute failed to prevent stuck entries
        mute_key = (chat_id, user_id)
        if mute_key in muted_users:
            del muted_users[mute_key]

async def check_muted_users(bot):
    """Background task to check and unmute users whose mute time has expired"""
    while True:
        try:
            current_time = datetime.now()
            expired_mutes = []

            for mute_key, mute_info in muted_users.items():
                unmute_time = mute_info.get('unmute_time')
                if unmute_time and unmute_time <= current_time:
                    expired_mutes.append(mute_key)

            # Process expired mutes
            for mute_key in expired_mutes:
                chat_id, user_id = mute_key
                await auto_unmute_user(chat_id, user_id, bot)

            # Wait 30 seconds before next check
            await asyncio.sleep(30)

        except Exception as e:
            logger.error(f"Error in check_muted_users: {str(e)}")
            await asyncio.sleep(60)  # Wait longer on error

async def cleanup_expired_mutes(bot):
    """Clean up expired mutes on bot startup"""
    try:
        current_time = datetime.now()
        expired_mutes = []

        for mute_key, mute_info in muted_users.items():
            unmute_time = mute_info.get('unmute_time')
            if unmute_time and unmute_time <= current_time:
                expired_mutes.append(mute_key)

        # Clean up expired mutes
        for mute_key in expired_mutes:
            chat_id, user_id = mute_key
            try:
                # Try to unmute the user
                normal_permissions = ChatPermissions(
                    can_send_messages=True,
                    can_send_polls=True,
                    can_send_other_messages=True,
                    can_add_web_page_previews=True,
                    can_change_info=False,
                    can_invite_users=True,
                    can_pin_messages=False,
                    can_send_audios=True,
                    can_send_documents=True,
                    can_send_photos=True,
                    can_send_videos=True,
                    can_send_video_notes=True,
                    can_send_voice_notes=True
                )

                await bot.restrict_chat_member(
                    chat_id=chat_id,
                    user_id=user_id,
                    permissions=normal_permissions
                )

                logger.info(f"Cleaned up expired mute for user {user_id} in chat {chat_id}")
            except Exception as e:
                logger.warning(f"Could not unmute user {user_id} in chat {chat_id}: {str(e)}")

            # Remove from muted users regardless of unmute success
            del muted_users[mute_key]

        if expired_mutes:
            logger.info(f"Cleaned up {len(expired_mutes)} expired mutes on startup")

    except Exception as e:
        logger.error(f"Error in cleanup_expired_mutes: {str(e)}")

@premium_required
async def premium_unmute_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unmute user with premium check"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند از این دستور استفاده کنند.")
            return

        # Check if message is a reply
        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً این دستور را در پاسخ به پیام کاربر مورد نظر استفاده کنید.")
            return

        user_to_unmute = update.message.reply_to_message.from_user
        chat_id = update.effective_chat.id
        mute_key = (chat_id, user_to_unmute.id)

        # Check if user is actually muted
        if mute_key not in muted_users:
            await update.message.reply_text(f"کاربر {user_to_unmute.first_name} ساکت نیست.")
            return

        # Get mute information
        mute_info = muted_users[mute_key]
        muted_at = mute_info.get('muted_at')
        unmute_time = mute_info.get('unmute_time')

        # Calculate mute duration
        if muted_at:
            mute_duration = datetime.now() - muted_at
            duration_text = format_time_duration(mute_duration)
        else:
            duration_text = "نامشخص"

        # Restore normal permissions
        normal_permissions = ChatPermissions(
            can_send_messages=True,
            can_send_polls=True,
            can_send_other_messages=True,
            can_add_web_page_previews=True,
            can_change_info=False,
            can_invite_users=True,
            can_pin_messages=False,
            can_send_audios=True,
            can_send_documents=True,
            can_send_photos=True,
            can_send_videos=True,
            can_send_video_notes=True,
            can_send_voice_notes=True
        )

        await context.bot.restrict_chat_member(
            chat_id=chat_id,
            user_id=user_to_unmute.id,
            permissions=normal_permissions
        )

        # Remove from muted users
        del muted_users[mute_key]

        # Send confirmation message
        unmute_message = f"🔊 سکوت کاربر {user_to_unmute.first_name} برداشته شد."
        unmute_message += f"\n⏰ مدت سکوت: {duration_text}"

        if unmute_time and unmute_time > datetime.now():
            remaining = unmute_time - datetime.now()
            unmute_message += f"\n📅 زمان باقیمانده بود: {format_time_duration(remaining)}"

        await update.message.reply_text(unmute_message)

        logger.info(f"User {user_to_unmute.id} manually unmuted in chat {chat_id} by {update.effective_user.id}")

    except Exception as e:
        logger.error(f"Error in unmute_user: {str(e)}")
        await update.message.reply_text(f"خطا در برداشتن سکوت کاربر: {str(e)}")

@premium_required
async def list_muted_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """List all muted users in the current chat"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند از این دستور استفاده کنند.")
            return

        chat_id = update.effective_chat.id
        current_time = datetime.now()

        # Find muted users in this chat
        chat_muted_users = []
        for mute_key, mute_info in muted_users.items():
            if mute_key[0] == chat_id:  # Same chat
                chat_muted_users.append((mute_key, mute_info))

        if not chat_muted_users:
            await update.message.reply_text("هیچ کاربری در این گروه ساکت نیست.")
            return

        # Build message
        message = "📋 لیست کاربران ساکت:\n\n"

        for i, (mute_key, mute_info) in enumerate(chat_muted_users, 1):
            user_name = mute_info.get('user_name', 'نامشخص')
            user_id = mute_info.get('user_id')
            muted_at = mute_info.get('muted_at')
            unmute_time = mute_info.get('unmute_time')

            message += f"{i}. {user_name} (ID: {user_id})\n"

            if muted_at:
                mute_duration = current_time - muted_at
                message += f"   ⏰ مدت سکوت: {format_time_duration(mute_duration)}\n"

            if unmute_time:
                if unmute_time > current_time:
                    remaining = unmute_time - current_time
                    message += f"   📅 زمان باقیمانده: {format_time_duration(remaining)}\n"
                else:
                    message += f"   ⚠️ زمان سکوت منقضی شده (در انتظار بروزرسانی)\n"
            else:
                message += f"   ♾️ سکوت دائمی\n"

            message += "\n"

        await update.message.reply_text(message)

    except Exception as e:
        logger.error(f"Error in list_muted_users: {str(e)}")
        await update.message.reply_text(f"خطا در نمایش لیست کاربران ساکت: {str(e)}")

@premium_required
async def start_voice_chat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Enable voice chat in the group with premium check"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند چت صوتی را فعال کنند.")
            return

        # Check if bot has admin permissions
        bot_member = await context.bot.get_chat_member(update.effective_chat.id, context.bot.id)
        if not bot_member.can_restrict_members:
            await update.message.reply_text("ربات دسترسی لازم برای تغییر تنظیمات گروه را ندارد.")
            return

        # Enable voice chat by setting permissions
        voice_permissions = ChatPermissions(
            can_send_messages=True,
            can_send_polls=True,
            can_send_other_messages=True,
            can_add_web_page_previews=True,
            can_change_info=False,
            can_invite_users=True,
            can_pin_messages=True,
            can_send_audios=True,
            can_send_documents=True,
            can_send_photos=True,
            can_send_videos=True,
            can_send_video_notes=True,
            can_send_voice_notes=True
        )

        await context.bot.set_chat_permissions(
            chat_id=update.effective_chat.id,
            permissions=voice_permissions
        )

        await update.message.reply_text("🎙️ چت صوتی گروه با موفقیت فعال شد.")
        logger.info(f"Voice chat enabled in chat {update.effective_chat.id} by {update.effective_user.id}")

    except Exception as e:
        logger.error(f"Error in start_voice_chat: {str(e)}")
        await update.message.reply_text(f"خطا در فعال‌سازی چت صوتی: {str(e)}")

@premium_required
async def stop_voice_chat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Disable voice chat in the group with premium check"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند چت صوتی را غیرفعال کنند.")
            return

        # Check if bot has admin permissions
        bot_member = await context.bot.get_chat_member(update.effective_chat.id, context.bot.id)
        if not bot_member.can_restrict_members:
            await update.message.reply_text("ربات دسترسی لازم برای تغییر تنظیمات گروه را ندارد.")
            return

        # Disable voice chat by restricting voice-related permissions
        restricted_permissions = ChatPermissions(
            can_send_messages=True,
            can_send_polls=True,
            can_send_other_messages=False,
            can_add_web_page_previews=True,
            can_change_info=False,
            can_invite_users=True,
            can_pin_messages=True,
            can_send_audios=False,
            can_send_documents=True,
            can_send_photos=True,
            can_send_videos=True,
            can_send_video_notes=False,
            can_send_voice_notes=False
        )

        await context.bot.set_chat_permissions(
            chat_id=update.effective_chat.id,
            permissions=restricted_permissions
        )

        await update.message.reply_text("🎙️ چت صوتی گروه با موفقیت غیرفعال شد.")
        logger.info(f"Voice chat disabled in chat {update.effective_chat.id} by {update.effective_user.id}")

    except Exception as e:
        logger.error(f"Error in stop_voice_chat: {str(e)}")
        await update.message.reply_text(f"خطا در غیرفعال‌سازی چت صوتی: {str(e)}")

@premium_required
async def pin_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Pin a message in the group with premium check"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند پیام را پین کنند.")
            return

        # Check if message is a reply
        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً این دستور را در پاسخ به پیام مورد نظر استفاده کنید.")
            return

        # Check if bot has admin permissions to pin messages
        bot_member = await context.bot.get_chat_member(update.effective_chat.id, context.bot.id)
        if not bot_member.can_pin_messages:
            await update.message.reply_text("ربات دسترسی لازم برای پین کردن پیام‌ها را ندارد.")
            return

        # Pin the replied message
        await context.bot.pin_chat_message(
            chat_id=update.effective_chat.id,
            message_id=update.message.reply_to_message.message_id,
            disable_notification=False
        )

        await update.message.reply_text("📌 پیام با موفقیت پین شد.")
        logger.info(f"Message {update.message.reply_to_message.message_id} pinned in chat {update.effective_chat.id} by {update.effective_user.id}")

    except Exception as e:
        logger.error(f"Error in pin_message: {str(e)}")
        await update.message.reply_text(f"خطا در پین کردن پیام: {str(e)}")

@premium_required
async def unpin_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unpin a message or all messages in the group with premium check"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند پین پیام را حذف کنند.")
            return

        # Check if bot has admin permissions to pin messages
        bot_member = await context.bot.get_chat_member(update.effective_chat.id, context.bot.id)
        if not bot_member.can_pin_messages:
            await update.message.reply_text("ربات دسترسی لازم برای حذف پین پیام‌ها را ندارد.")
            return

        # Check if specific message or all pins
        if update.message.reply_to_message:
            # Unpin specific message
            await context.bot.unpin_chat_message(
                chat_id=update.effective_chat.id,
                message_id=update.message.reply_to_message.message_id
            )
            await update.message.reply_text("📌 پین پیام با موفقیت حذف شد.")
            logger.info(f"Message {update.message.reply_to_message.message_id} unpinned in chat {update.effective_chat.id} by {update.effective_user.id}")
        else:
            # Unpin all messages
            await context.bot.unpin_all_chat_messages(chat_id=update.effective_chat.id)
            await update.message.reply_text("📌 تمام پیام‌های پین‌شده با موفقیت حذف شدند.")
            logger.info(f"All messages unpinned in chat {update.effective_chat.id} by {update.effective_user.id}")

    except Exception as e:
        logger.error(f"Error in unpin_message: {str(e)}")
        await update.message.reply_text(f"خطا در حذف پین پیام: {str(e)}")

@premium_required
async def delete_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Delete a message in the group with premium check"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند پیام حذف کنند.")
            return

        # Check if message is a reply
        if not update.message.reply_to_message:
            await update.message.reply_text("لطفاً این دستور را در پاسخ به پیام مورد نظر استفاده کنید.")
            return

        # Check if bot has permission to delete messages
        bot_member = await context.bot.get_chat_member(update.effective_chat.id, context.bot.id)
        if not bot_member.can_delete_messages:
            await update.message.reply_text("ربات دسترسی لازم برای حذف پیام‌ها را ندارد.")
            return

        # Delete the replied message
        await context.bot.delete_message(
            chat_id=update.effective_chat.id,
            message_id=update.message.reply_to_message.message_id
        )

        await update.message.reply_text("🗑️ پیام با موفقیت حذف شد.")
        logger.info(f"Message {update.message.reply_to_message.message_id} deleted in chat {update.effective_chat.id} by {update.effective_user.id}")

    except Exception as e:
        logger.error(f"Error in delete_message: {str(e)}")
        await update.message.reply_text(f"خطا در حذف پیام: {str(e)}")

def parse_time_duration(time_str):
    """Parse time duration string and return timedelta object"""
    if not time_str:
        return None

    # Pattern to match time format like: 1h, 30m, 2d, 1h30m, etc.
    pattern = r'(?:(\d+)d)?(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?'
    match = re.match(pattern, time_str.lower())

    if not match:
        return None

    days, hours, minutes, seconds = match.groups()

    total_seconds = 0
    if days:
        total_seconds += int(days) * 24 * 3600
    if hours:
        total_seconds += int(hours) * 3600
    if minutes:
        total_seconds += int(minutes) * 60
    if seconds:
        total_seconds += int(seconds)

    if total_seconds == 0:
        return None

    return timedelta(seconds=total_seconds)

def format_time_duration(td):
    """Format timedelta to readable Persian text"""
    if not td:
        return "نامحدود"

    total_seconds = int(td.total_seconds())
    days = total_seconds // (24 * 3600)
    hours = (total_seconds % (24 * 3600)) // 3600
    minutes = (total_seconds % 3600) // 60
    seconds = total_seconds % 60

    parts = []
    if days > 0:
        parts.append(f"{days} روز")
    if hours > 0:
        parts.append(f"{hours} ساعت")
    if minutes > 0:
        parts.append(f"{minutes} دقیقه")
    if seconds > 0:
        parts.append(f"{seconds} ثانیه")

    return " و ".join(parts) if parts else "کمتر از یک ثانیه"

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send a message when the command /help is issued."""
    try:
        # Help content divided into pages
        help_pages = [
            # Page 1
            """
<b>🤖 دستورات ربات مدیریت گروه</b>

<b>👤 کاربران عادی:</b>
• /start یا شروع - شروع کار با ربات
• /help یا راهنما/کمک - نمایش این راهنما
• /subscription یا اشتراک - بررسی وضعیت اشتراک گروه
• /buypremium یا خرید_اشتراک - خرید اشتراک پرمیوم
• /time یا ساعت/تاریخ/زمان - نمایش ساعت و تاریخ فعلی
• /convert - تبدیل ارز به تومان
""",
            # Page 2
            """
<b>👮‍♂️ دستورات ادمین‌ها (نیاز به اشتراک):</b>

• /warn یا اخطار - اخطار به کاربر (با ریپلای)
• /unwarn یا حذف_اخطار - حذف اخطار کاربر (با ریپلای)
• /admin یا ادمین - پنل مدیریت (فقط برای ادمین اصلی)
• /locktime یا قفل_زمانی - قفل تایم‌دار گروه
• /unlocktime یا باز_کردن_قفل - باز کردن قفل گروه
• /forcejoin یا جوین_اجباری - تنظیم جوین اجباری چنل
• /unforcejoin یا حذف_جوین_اجباری - حذف جوین اجباری
""",
            # Page 3
"""
<b>👮‍♂️ دستورات مدیریتی (ادامه):</b>

• /ban یا بن - مسدود کردن کاربر (با ریپلای)
• /unban یا رفع_بن - رفع مسدودیت کاربر (با ریپلای)
• /kick یا اخراج - اخراج کاربر (با ریپلای)
• /mute یا سکوت - ساکت کردن کاربر (با ریپلای)
• /unmute یا رفع_سکوت - برداشتن سکوت کاربر (با ریپلای)
• /mutelist یا لیست_ساکت - نمایش لیست کاربران ساکت
• /delete یا حذف - حذف پیام (با ریپلای)
""",
            # Page 4
            """
<b>👮‍♂️ دستورات مدیریتی (ادامه):</b>

• /startvoice یا شروع_ویس - فعال کردن چت صوتی گروه
• /stopvoice یا قطع_ویس - غیرفعال کردن چت صوتی
• /pin یا پین - پین کردن پیام (با ریپلای)
• /unpin یا حذف_پین - حذف پین پیام
• /broadcast یا پیام_همگانی - ارسال پیام همگانی
• /promote یا ارتقا - ارتقای کاربر به ادمین (با ریپلای)
• /demote یا عزل - عزل کاربر از ادمینی (با ریپلای)
""",
            # Page 5
            """
<b>🔍 دستورات اطلاعاتی و گزارش:</b>

• /special یا ویژه - دادن دسترسی ویژه به کاربر
• /sudo یا سودو - افزودن یا حذف کاربر سودو
• /report یا گزارش - گزارش پیام به ادمین‌ها
• /reportadmin یا گزارش_ادمین - گزارش ادمین‌ها
• /weather یا آب و هوا - دریافت اطلاعات آب و هوا
• /userinfo یا اطلاعات - نمایش اطلاعات کاربر
• /echo یا اکو - ارسال پیام از طرف ربات (ادمین فقط)
""",
            # Page 6
            """
<b>👤 دستورات مدیریت کاربران:</b>

• /nickname یا لقب - نمایش یا تنظیم لقب کاربر
• /setnickname یا تنظیم لقب - تنظیم لقب کاربر
• /removenickname یا حذف لقب - حذف لقب کاربر
• /glass یا شیشه - ساخت لینک شیشه‌ای زیبا و یکبار مصرف

برای اطلاعات بیشتر با ادمین تماس بگیرید.
"""
        ]

        # Style the help message with glass-like appearance
        page_index = 0
        if not isinstance(update, Update):  # Called from callback
            page_index = int(update.data.split('_')[-1]) - 1

        # Get the content for the current page
        content = help_pages[page_index]

        # Create styled message with glass effect
        styled_message = create_glass_help_message(content, page_index + 1, len(help_pages))

        # Create keyboard for pagination
        keyboard = get_help_page_keyboard(page_index + 1, len(help_pages))

        # Send the styled message
        if isinstance(update, Update):
            await update.message.reply_text(
                styled_message,
                parse_mode=ParseMode.HTML,
                reply_markup=keyboard
            )
        else:
            # Handle callback query updates
            await update.edit_message_text(
                styled_message,
                parse_mode=ParseMode.HTML,
                reply_markup=keyboard
            )

        logger.info(f"Help command executed by user {update.effective_user.id if isinstance(update, Update) else update.from_user.id} in chat {update.effective_chat.id if isinstance(update, Update) else update.message.chat.id}")
    except Exception as e:
        logger.error(f"Error in help_command: {str(e)}")
        error_message = "خطایی در نمایش راهنما رخ داد. لطفاً دوباره تلاش کنید یا با ادمین تماس بگیرید."
        if isinstance(update, Update):
            await update.message.reply_text(error_message)
        else:
            await update.message.reply_text(error_message)

def create_glass_help_message(content, current_page, total_pages):
    """Create a styled glass-like help message"""
    # Add glass-like border and styling
    header = "╭┈┈┈┈┈┈┈「 📚 راهنمای دستورات 」┈┈┈┈┈┈┈╮\n"
    footer = f"\n╰┈┈┈┈┈┈┈「 صفحه {current_page} از {total_pages} 」┈┈┈┈┈┈┈╯"

    # Add glass effect decorations
    top_pattern = "┊  ✧  ✧  ✧  ✧  ✧  ✧  ✧  ✧  ✧  ✧  ✧  ┊\n"
    bottom_pattern = "\n┊  ✧  ✧  ✧  ✧  ✧  ✧  ✧  ✧  ✧  ✧  ✧  ┊"

    # Add side borders to content
    lines = content.split('\n')
    bordered_content = ""
    for line in lines:
        if line.strip():  # Only add borders to non-empty lines
            bordered_content += f"┊ {line} ┊\n"
        else:
            bordered_content += f"┊{line}┊\n"

    # Remove trailing newline
    if bordered_content.endswith('\n'):
        bordered_content = bordered_content[:-1]

    # Combine all parts with glass effect
    styled_message = f"{header}{top_pattern}{bordered_content}{bottom_pattern}{footer}"

    return styled_message

def get_help_page_keyboard(current_page, total_pages):
    """Generate keyboard for help pagination"""
    keyboard = []

    # Add navigation buttons
    row = []
    if current_page > 1:
        row.append(InlineKeyboardButton("➡️ صفحه قبل", callback_data=f"help_page_{current_page-1}"))

    if current_page < total_pages:
        row.append(InlineKeyboardButton("صفحه بعد ⬅️", callback_data=f"help_page_{current_page+1}"))

    keyboard.append(row)

    # Add page indicator and home button in second row
    row2 = []
    if current_page > 1:
        row2.append(InlineKeyboardButton("🏠 صفحه اصلی", callback_data="help_page_1"))

    # Add page indicator
    page_indicator = f"📄 صفحه {current_page} از {total_pages}"
    row2.append(InlineKeyboardButton(page_indicator, callback_data="help_noop"))

    keyboard.append(row2)

    return InlineKeyboardMarkup(keyboard)

async def handle_persian_commands(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle Persian text commands without slash"""
    if not update.message or not update.message.text:
        return False

    text = update.message.text.strip()

    # Special handling for "آمار" commands
    if text == "آمار" or text.startswith("آمار ") or text.startswith("آمار_"):
        await stats_command(update, context)
        return True

    # Check if text is a Persian command
    command = None
    args = []

    # First check for multi-word commands (check longest matches first)
    multi_word_commands = [
        'تنظیم لقب', 'حذف لقب', 'آب و هوا', 'آمار کاربر',
        'حذف_اخطار', 'باز_کردن_قفل', 'جوین_اجباری', 'حذف_جوین_اجباری',
        'رفع_بن', 'رفع_سکوت', 'لیست_ساکت', 'پیام_همگانی', 'شروع_ویس',
        'قطع_ویس', 'حذف_پین', 'خرید_اشتراک', 'گزارش_ادمین',
        'اکو', 'لینک شیشه‌ای', 'شیشه', 'پنل', 'سودو'
    ]

    # Check for multi-word commands first
    for multi_cmd in multi_word_commands:
        if text.startswith(multi_cmd):
            if multi_cmd in PERSIAN_COMMANDS:
                command = PERSIAN_COMMANDS[multi_cmd]
                # Extract arguments after the multi-word command
                remaining_text = text[len(multi_cmd):].strip()
                args = remaining_text.split() if remaining_text else []
                break

    # If no multi-word command found, check single word commands
    if not command:
        parts = text.split()
        if parts and parts[0] in PERSIAN_COMMANDS:
            command = PERSIAN_COMMANDS[parts[0]]
            args = parts[1:]

    if not command:
        return False

    # Store args in context
    context.args = args

    # Handle different commands
    try:
        if command == 'start':
            await start(update, context)
        elif command == 'help':
            await help_command(update, context)
        elif command == 'subscription':
            await subscription_status(update, context)
        elif command == 'warn':
            await premium_warn_user(update, context)
        elif command == 'unwarn':
            await premium_unwarn_user(update, context)
        elif command == 'admin':
            await premium_admin_panel(update, context)
        elif command == 'locktime':
            await premium_lock_time_messages(update, context)
        elif command == 'unlocktime':
            await premium_unlock_time_messages(update, context)
        elif command == 'forcejoin':
            await premium_set_force_join(update, context)
        elif command == 'unforcejoin':
            await premium_unset_force_join(update, context)
        elif command == 'ban':
            await premium_ban_user(update, context)
        elif command == 'kick':
            await premium_kick_user(update, context)
        elif command == 'mute':
            await premium_mute_user(update, context)
        elif command == 'unmute':
            await premium_unmute_user(update, context)
        elif command == 'mutelist':
            await list_muted_users(update, context)
        elif command == 'delete':
            await delete_message(update, context)
        elif command == 'startvoice':
            await start_voice_chat(update, context)
        elif command == 'stopvoice':
            await stop_voice_chat(update, context)
        elif command == 'pin':
            await pin_message(update, context)
        elif command == 'unpin':
            await unpin_message(update, context)
        elif command == 'broadcast':
            await admin_broadcast_handler(update, context)
        elif command == 'buypremium':
            await buy_premium(update, context)
        elif command == 'time':
            await show_current_time(update, context)
        elif command == 'promote':
            await premium_promote_user(update, context)
        elif command == 'demote':
            await premium_demote_user(update, context)
        elif command == 'special':
            await premium_special_user(update, context)
        elif command == 'sudo':
            await sudo_user_handler(update, context)
        elif command == 'reportadmin':
            await report_admin_abuse(update, context)
        elif command == 'weather':
            await weather_handler(update, context)
        elif command == 'nickname':
            await show_nickname_handler(update, context)
        elif command == 'setnickname':
            await set_nickname_handler(update, context)
        elif command == 'removenickname':
            await remove_nickname_handler(update, context)
        elif command == 'userinfo':
            await user_info_handler(update, context)
        elif command == 'echo':
            await echo_command(update, context)
        elif command == 'glass':
            await glass_command(update, context)
        elif command == 'panel':
            await admin_panel(update, context)
        elif command == 'stats':
            await stats_command(update, context)
        else:
            return False

        return True
    except Exception as e:
        logger.error(f"Error handling Persian command {command}: {str(e)}")
        return False

async def post_init(application):
    """Post initialization function to start background tasks"""
    try:
        # Clean up expired mutes on startup
        await cleanup_expired_mutes(application.bot)

        # Start background task for checking muted users
        asyncio.create_task(check_muted_users(application.bot))

        logger.info("Background tasks started successfully")
    except Exception as e:
        logger.error(f"Error in post_init: {str(e)}")

def get_persian_weekday(weekday):
    """Convert weekday number to Persian weekday name"""
    persian_weekdays = {
        0: 'دوشنبه',
        1: 'سه‌شنبه',
        2: 'چهارشنبه',
        3: 'پنج‌شنبه',
        4: 'جمعه',
        5: 'شنبه',
        6: 'یکشنبه'
    }
    return persian_weekdays.get(weekday, 'نامشخص')

def get_persian_month(month):
    """Convert month number to Persian month name"""
    persian_months = {
        1: 'فروردین', 2: 'اردیبهشت', 3: 'خرداد',
        4: 'تیر', 5: 'مرداد', 6: 'شهریور',
        7: 'مهر', 8: 'آبان', 9: 'آذر',
        10: 'دی', 11: 'بهمن', 12: 'اسفند'
    }
    return persian_months.get(month, 'نامشخص')

def persian_digits(text):
    """Convert English digits to Persian digits"""
    english_digits = '0123456789'
    persian_digits_map = '۰۱۲۳۴۵۶۷۸۹'

    for i, digit in enumerate(english_digits):
        text = text.replace(digit, persian_digits_map[i])

    return text

async def show_current_time(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show current time and date in Tehran timezone with Persian format"""
    try:
        # Get Tehran timezone
        tehran_tz = pytz.timezone('Asia/Tehran')

        # Get current time in Tehran
        now_tehran = datetime.now(tehran_tz)

        # Format time (24-hour format)
        time_str = now_tehran.strftime('%H:%M:%S')
        time_persian = persian_digits(time_str)

        # Format date
        day = now_tehran.day
        month = now_tehran.month
        year = now_tehran.year
        weekday = now_tehran.weekday()

        # Get Persian names
        persian_weekday = get_persian_weekday(weekday)
        persian_month = get_persian_month(month)

        # Format Persian date
        date_str = f"{persian_weekday}، {persian_digits(str(day))} {persian_month} {persian_digits(str(year))}"

        # Create beautiful message
        message = f"""🕐 **ساعت فعلی تهران:**\n`{time_persian}`\n\n📅 **تاریخ امروز:**\n`{date_str}`\n\n🌍 **منطقه زمانی:** آسیا/تهران (UTC+3:30)\n⏰ **به‌روزرسانی شده در:** {time_persian}\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n💡 **نکته:** این اطلاعات بر اساس ساعت رسمی ایران محاسبه شده است."""

        await update.message.reply_text(message, parse_mode='Markdown')

        logger.info(f"Time command used by user {update.effective_user.id} in chat {update.effective_chat.id}")

    except Exception as e:
        logger.error(f"Error in show_current_time: {str(e)}")
        await update.message.reply_text(
            "❌ خطایی در نمایش ساعت و تاریخ رخ داد.\n"
            "لطفاً دوباره تلاش کنید."
        )

class CurrencyAPI:
    def __init__(self):
        self.last_update = datetime.now()
        self.cache_duration = 900
        self.cached_data = None
        self.usd_to_toman_rate = 83535
        self.api_sources = {
            "currencies": "https://open.er-api.com/v6/latest/USD",
            "crypto": "https://api.coingecko.com/api/v3/simple/price",
            "gold": "https://api.metals.live/v1/spot"
        }

    def _get_iran_datetime(self):
        tehran_tz = pytz.timezone('Asia/Tehran')
        now = datetime.now(tehran_tz)
        j_date = jdatetime.datetime.fromgregorian(datetime=now)
        return j_date.strftime("%A %d %B %Y"), now.strftime("%H:%M")

    def _fetch_usd_to_toman_rate(self):
        try:
            r = requests.get("https://api.nobitex.ir/market/stats", timeout=5)
            r.raise_for_status()
            data = r.json()
            usdt_to_irr = float(data['stats']['USDT_IRR']['latest'])
            return int(usdt_to_irr / 10)
        except Exception as e:
            logger.error(f"Failed to fetch USD to Toman rate: {str(e)}")
            return self.usd_to_toman_rate

    def _fetch_currency_rates(self):
        try:
            self.usd_to_toman_rate = self._fetch_usd_to_toman_rate()
            data = requests.get(self.api_sources["currencies"]).json()
            return {
                "USD": {"name": "دلار آمریکا", "price": f"{self.usd_to_toman_rate:,}"},
                "EUR": {"name": "یورو", "price": f"{int(self.usd_to_toman_rate / data['rates']['EUR']):,}"},
                "GBP": {"name": "پوند", "price": f"{int(self.usd_to_toman_rate / data['rates']['GBP']):,}"}
            }
        except:
            return {
                "USD": {"name": "دلار آمریکا", "price": "83,535"},
                "EUR": {"name": "یورو", "price": "97,000"},
                "GBP": {"name": "پوند", "price": "113,000"}
            }

    def _fetch_crypto_prices(self):
        try:
            params = {'ids': 'bitcoin,ethereum,tether', 'vs_currencies': 'usd'}
            data = requests.get(self.api_sources["crypto"], params=params).json()
            return {
                "USDT": {"name": "تتر", "price": f"{self.usd_to_toman_rate:,}"},
                "BTC": {"name": "بیت کوین", "price": f"{data['bitcoin']['usd']:,.0f}"},
                "ETH": {"name": "اتریوم", "price": f"{data['ethereum']['usd']:,.0f}"}
            }
        except:
            return {
                "USDT": {"name": "تتر", "price": "83,535"},
                "BTC": {"name": "بیت کوین", "price": "105,000"},
                "ETH": {"name": "اتریوم", "price": "2,500"}
            }

    def _fetch_gold_prices(self):
        try:
            data = requests.get(self.api_sources["gold"]).json()
            gold_price_usd = next((i for i in data if "gold" in i), {"price": 2000})["price"]
            gold_price_toman = gold_price_usd * self.usd_to_toman_rate
            gold_gram = gold_price_toman / 31.1
            return {
                "Gram": {"name": "هر گرم", "price": f"{int(gold_gram):,}"},
                "Ounce": {"name": "انس طلا", "price": f"{gold_price_usd:,} $"}
            }
        except:
            return {
                "Gram": {"name": "هر گرم", "price": "7,000,000"},
                "Ounce": {"name": "انس طلا", "price": "2,000 $"}
            }

    def get_current_rates(self):
        now = datetime.now()
        if self.cached_data and (now - self.last_update).total_seconds() < self.cache_duration:
            return self.cached_data
        date, time_now = self._get_iran_datetime()
        rates = {
            "date": date,
            "time": time_now,
            "currencies": self._fetch_currency_rates(),
            "crypto": self._fetch_crypto_prices(),
            "gold": self._fetch_gold_prices()
        }
        self.cached_data = rates
        self.last_update = now
        return rates

    def convert_usd_to_toman(self, amount_usd):
        self.usd_to_toman_rate = self._fetch_usd_to_toman_rate()
        return amount_usd * self.usd_to_toman_rate

currency_api = CurrencyAPI()
full_currency_api = FullCurrencyAPI()

async def currency_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rates = currency_api.get_current_rates()
    message = f"💱 *نرخ ارز:*\n📅 {rates['date']} | 🕒 {rates['time']}\n\n"
    for c in rates['currencies'].values():
        message += f"• {c['name']}: {c['price']} تومان\n"
    await update.message.reply_text(message, parse_mode=ParseMode.MARKDOWN)

async def crypto_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rates = currency_api.get_current_rates()
    message = f"💰 *قیمت کریپتو:*\n📅 {rates['date']} | 🕒 {rates['time']}\n\n"
    for c in rates['crypto'].values():
        if c['name'] == "تتر":
            message += f"• {c['name']}: {c['price']} تومان\n"
        else:
            message += f"• {c['name']}: {c['price']} $\n"
    await update.message.reply_text(message, parse_mode=ParseMode.MARKDOWN)

async def gold_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rates = currency_api.get_current_rates()
    message = f"🏆 *قیمت طلا:*\n📅 {rates['date']} | 🕒 {rates['time']}\n\n"
    for g in rates['gold'].values():
        message += f"• {g['name']}: {g['price']}\n"
    await update.message.reply_text(message, parse_mode=ParseMode.MARKDOWN)

async def convert_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Convert between different currencies and assets with a nice design"""
    try:
        # Check if any arguments were provided
        if not context.args or len(context.args) < 2:
            # Show help message with a nice design
            help_message = """
╭───────「 💱 راهنمای تبدیل ارز 」───────╮
│                                        │
│  📌 <b>نحوه استفاده:</b>                 │
│  /convert [مقدار] [نوع ارز]            │
│                                        │
│  📋 <b>مثال‌ها:</b>                      │
│  /convert 100 usd  ➜  تبدیل ۱۰۰ دلار    │
│  /convert 50 eur   ➜  تبدیل ۵۰ یورو     │
│  /convert 10 btc   ➜  تبدیل ۱۰ بیت‌کوین │
│  /convert 1000 trx ➜  تبدیل ۱۰۰۰ ترون   │
│  /convert 1 gold   ➜  تبدیل ۱ گرم طلا   │
│                                        │
│  💰 <b>ارزهای پشتیبانی شده:</b>          │
│  USD, EUR, GBP, TRX, BTC, ETH, BNB     │
│  USDT, DOGE, XRP, LTC, GOLD            │
╰────────────────────────────────────────╯
"""
            await update.message.reply_text(help_message, parse_mode='HTML')
            return

        try:
            # Parse amount and currency
            amount = float(context.args[0])
            currency = context.args[1].upper()
        except ValueError:
            await update.message.reply_text("❌ لطفاً یک مقدار عددی معتبر وارد کنید.")
            return

        # Get current rates
        rates = currency_api.get_current_rates()

        # Get current date and time in Persian format
        date_persian = rates['date']
        time_persian = rates['time']

        # Initialize result variables
        result_toman = 0
        result_usd = 0
        currency_name = ""

        # Convert based on currency type
        if currency in ["USD", "USDT", "DOLLAR", "دلار"]:
            result_toman = currency_api.convert_usd_to_toman(amount)
            result_usd = amount
            currency_name = "دلار"

        elif currency in ["EUR", "EURO", "یورو"]:
            # Convert EUR to USD first
            usd_rate = float(rates['currencies']['USD']['price'].replace(',', ''))
            eur_rate = float(rates['currencies']['EUR']['price'].replace(',', ''))
            result_toman = amount * eur_rate
            result_usd = amount * (eur_rate / usd_rate)
            currency_name = "یورو"

        elif currency in ["GBP", "POUND", "پوند"]:
            # Convert GBP to USD first
            usd_rate = float(rates['currencies']['USD']['price'].replace(',', ''))
            gbp_rate = float(rates['currencies']['GBP']['price'].replace(',', ''))
            result_toman = amount * gbp_rate
            result_usd = amount * (gbp_rate / usd_rate)
            currency_name = "پوند"

        elif currency in ["BTC", "BITCOIN", "بیتکوین", "بیت‌کوین"]:
            # Get BTC price in USD
            btc_usd_rate = float(rates['crypto']['BTC']['price'].replace(',', ''))
            usd_toman_rate = float(rates['currencies']['USD']['price'].replace(',', ''))
            result_usd = amount * btc_usd_rate
            result_toman = result_usd * usd_toman_rate
            currency_name = "بیت‌کوین"

        elif currency in ["ETH", "ETHEREUM", "اتریوم"]:
            # Get ETH price in USD
            eth_usd_rate = float(rates['crypto']['ETH']['price'].replace(',', ''))
            usd_toman_rate = float(rates['currencies']['USD']['price'].replace(',', ''))
            result_usd = amount * eth_usd_rate
            result_toman = result_usd * usd_toman_rate
            currency_name = "اتریوم"

        elif currency in ["TRX", "TRON", "ترون"]:
            # Get TRX price in USD (approximately 0.12 USD)
            trx_usd_rate = 0.12  # This should be fetched from API in production
            usd_toman_rate = float(rates['currencies']['USD']['price'].replace(',', ''))
            result_usd = amount * trx_usd_rate
            result_toman = result_usd * usd_toman_rate
            currency_name = "ترون"

        elif currency in ["BNB", "BINANCE", "بایننس"]:
            # Get BNB price in USD (approximately 600 USD)
            bnb_usd_rate = 600  # This should be fetched from API in production
            usd_toman_rate = float(rates['currencies']['USD']['price'].replace(',', ''))
            result_usd = amount * bnb_usd_rate
            result_toman = result_usd * usd_toman_rate
            currency_name = "بایننس کوین"

        elif currency in ["DOGE", "DOGECOIN", "دوج", "دوج‌کوین"]:
            # Get DOGE price in USD (approximately 0.1 USD)
            doge_usd_rate = 0.1  # This should be fetched from API in production
            usd_toman_rate = float(rates['currencies']['USD']['price'].replace(',', ''))
            result_usd = amount * doge_usd_rate
            result_toman = result_usd * usd_toman_rate
            currency_name = "دوج‌کوین"

        elif currency in ["XRP", "RIPPLE", "ریپل"]:
            # Get XRP price in USD (approximately 0.6 USD)
            xrp_usd_rate = 0.6  # This should be fetched from API in production
            usd_toman_rate = float(rates['currencies']['USD']['price'].replace(',', ''))
            result_usd = amount * xrp_usd_rate
            result_toman = result_usd * usd_toman_rate
            currency_name = "ریپل"

        elif currency in ["LTC", "LITECOIN", "لایت‌کوین"]:
            # Get LTC price in USD (approximately 70 USD)
            ltc_usd_rate = 70  # This should be fetched from API in production
            usd_toman_rate = float(rates['currencies']['USD']['price'].replace(',', ''))
            result_usd = amount * ltc_usd_rate
            result_toman = result_usd * usd_toman_rate
            currency_name = "لایت‌کوین"

        elif currency in ["GOLD", "طلا", "GRAM", "گرم"]:
            # Get gold price per gram in toman
            gold_gram_rate = float(rates['gold']['Gram']['price'].replace(',', ''))
            usd_toman_rate = float(rates['currencies']['USD']['price'].replace(',', ''))
            result_toman = amount * gold_gram_rate
            result_usd = result_toman / usd_toman_rate
            currency_name = "گرم طلا"

        else:
            await update.message.reply_text(f"❌ ارز {currency} پشتیبانی نمی‌شود. برای دیدن لیست ارزهای پشتیبانی شده، دستور /convert را بدون پارامتر وارد کنید.")
            return

        # Format the results with commas for better readability
        formatted_toman = f"{int(result_toman):,}"
        formatted_usd = f"{result_usd:,.2f}"

        # Create a beautiful response message
        response_message = f"""
╭───────「 💱 نتیجه تبدیل ارز 」───────╮
│                                      │
│  🔢 <b>مقدار اولیه:</b> {amount:,} {currency_name}
│                                      │
│  💰 <b>معادل به تومان:</b>             │
│  {formatted_toman} تومان
│                                      │
│  💵 <b>معادل به دلار:</b>              │
│  {formatted_usd} دلار
│                                      │
│  📅 <b>تاریخ به‌روزرسانی:</b> {date_persian}  │
│  🕒 <b>ساعت به‌روزرسانی:</b> {time_persian}   │
╰────────────────────────────────────────╯
"""

        # Send the response
        await update.message.reply_text(response_message, parse_mode='HTML')
        logger.info(f"Currency conversion: {amount} {currency} by user {update.effective_user.id}")

    except Exception as e:
        logger.error(f"Error in convert_command: {str(e)}")
        await update.message.reply_text("❌ خطا در تبدیل ارز. لطفاً دوباره تلاش کنید!")

async def market_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Display complete market information including currencies, gold, and cryptocurrencies"""
    try:
        message = full_currency_api.format_currency_message()
        await update.message.reply_text(message)
        logger.info(f"Market information displayed for user {update.effective_user.id}")
    except Exception as e:
        logger.error(f"Error in market_command: {str(e)}")
        await update.message.reply_text("❌ خطایی در دریافت اطلاعات بازار رخ داد.\nلطفاً دوباره تلاش کنید.")

async def delete_service_messages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Delete service messages like member joined/left"""
    try:
        chat_id = update.effective_chat.id
        # بررسی تنظیمات گروه
        settings = db.get_group_settings(chat_id)

        # حذف پیام‌های ورود و خروج اعضا
        if update.message.new_chat_members or update.message.left_chat_member:
            await update.message.delete()
            logger.info(f"Deleted a service message in {chat_id}")

        # حذف پیام‌های ورود اعضا با لینک
        elif update.message.new_chat_members and settings.get("delete_join_link_messages", False):
            if hasattr(update.message, "invite_link") and update.message.invite_link:
                await update.message.delete()
                logger.info(f"Deleted a join by link message in {chat_id}")

        # حذف پیام‌های اد شدن
        elif update.message.new_chat_members and settings.get("delete_join_messages", False):
            await update.message.delete()
            logger.info(f"Deleted a join message in {chat_id}")

        # حذف پیام‌های پین
        elif update.message.pinned_message and settings.get("delete_pin_messages", False):
            await update.message.delete()
            logger.info(f"Deleted a pin message in {chat_id}")

        # حذف پیام‌های ویدیو چت
        elif (update.message.video_chat_started or update.message.video_chat_ended or
              update.message.video_chat_participants_invited) and settings.get("delete_video_chat_messages", False):
            await update.message.delete()
            logger.info(f"Deleted a video chat message in {chat_id}")
    except Exception as e:
        logger.warning(f"Could not delete service message: {str(e)}")

async def new_member_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle new member messages"""
    await premium_welcome_new_member(update, context)

@premium_required
async def premium_promote_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Promote user with premium check"""
    return await promote_user_handler(update, context)

@premium_required
async def premium_demote_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Demote user with premium check"""
    return await demote_user_handler(update, context)

@premium_required
async def premium_special_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Make user special with premium check"""
    return await special_user_handler(update, context)

@premium_required
async def sudo_user_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Add or remove sudo users for the group"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Initialize premium manager
        premium_manager = PremiumManager("group_manager.db")
        group_id = update.effective_chat.id
        user_id = update.effective_user.id

        # Check if user is the buyer or admin
        subscription_info = premium_manager.get_group_subscription_info(group_id)
        is_buyer = subscription_info and subscription_info['buyer_id'] == user_id
        is_admin = user_id == ADMIN_ID

        if not (is_buyer or is_admin):
            await update.message.reply_text("فقط خریدار اشتراک یا ادمین اصلی می‌تواند سودو تعیین کند.")
            return

        # Check if message is a reply
        if not update.message.reply_to_message:
            # Show list of sudo users
            sudo_users = premium_manager.get_group_sudo_users(group_id)

            if not sudo_users:
                await update.message.reply_text(
                    "📋 لیست کاربران سودو خالی است.\n\n"
                    "💡 برای افزودن یا حذف کاربر سودو، روی پیام کاربر ریپلای کرده و دستور /sudo را بنویسید.\n"
                    "🔹 سودو می‌تواند به پنل مدیریت گروه دسترسی داشته باشد."
                )
                return

            # Get user info for each sudo user
            sudo_info = []
            for sudo_id in sudo_users:
                try:
                    user = await context.bot.get_chat_member(group_id, sudo_id)
                    name = user.user.first_name
                    username = user.user.username or "بدون نام کاربری"
                    sudo_info.append(f"👤 {name} (@{username}) - ID: {sudo_id}")
                except:
                    sudo_info.append(f"👤 کاربر ناشناس - ID: {sudo_id}")

            sudo_list = "\n".join(sudo_info)
            await update.message.reply_text(
                f"📋 لیست کاربران سودو:\n\n{sudo_list}\n\n"
                "💡 برای افزودن یا حذف کاربر سودو، روی پیام کاربر ریپلای کرده و دستور /sudo را بنویسید."
            )
            return

        # Get the user to add/remove as sudo
        target_user = update.message.reply_to_message.from_user
        target_id = target_user.id

        # Check if target is already a sudo
        sudo_users = premium_manager.get_group_sudo_users(group_id)
        is_sudo = target_id in sudo_users

        if is_sudo:
            # Remove from sudo
            success = premium_manager.remove_sudo_user(group_id, target_id)
            if success:
                await update.message.reply_text(f"✅ کاربر {target_user.first_name} از لیست سودو حذف شد.")
            else:
                await update.message.reply_text("❌ خطا در حذف کاربر از لیست سودو.")
        else:
            # Add as sudo
            success = premium_manager.add_sudo_user(group_id, target_id, user_id)
            if success:
                await update.message.reply_text(
                    f"✅ کاربر {target_user.first_name} به لیست سودو اضافه شد.\n"
                    "🔹 این کاربر اکنون می‌تواند به پنل مدیریت گروه دسترسی داشته باشد."
                )
            else:
                await update.message.reply_text("❌ خطا در افزودن کاربر به لیست سودو.")

    except Exception as e:
        logger.error(f"Error in sudo_user_handler: {str(e)}")
        await update.message.reply_text(f"خطا در مدیریت کاربران سودو: {str(e)}")

async def echo_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Echo command - Bot repeats the message and deletes the original"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin or has special permissions
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند از دستور اکو استفاده کنند.")
            return

        # Check if bot has permission to delete messages
        bot_member = await context.bot.get_chat_member(update.effective_chat.id, context.bot.id)
        if not bot_member.can_delete_messages:
            await update.message.reply_text("ربات دسترسی لازم برای حذف پیام‌ها را ندارد.")
            return

        # Extract the message text after "اکو"
        if not context.args:
            await update.message.reply_text(
                "لطفاً متن مورد نظر را بعد از کلمه اکو بنویسید.\n\n"
                "مثال: اکو سلام به همه دوستان!"
            )
            return

        # Join all arguments to form the complete message
        echo_text = " ".join(context.args)

        # Store original message info for potential reply
        original_message = update.message
        reply_to_message = original_message.reply_to_message

        # Delete the original command message
        try:
            await context.bot.delete_message(
                chat_id=update.effective_chat.id,
                message_id=original_message.message_id
            )
        except Exception as e:
            logger.warning(f"Could not delete original echo message: {str(e)}")

        # Send the echo message
        if reply_to_message:
            # If original was a reply, reply to the same message
            await reply_to_message.reply_text(echo_text)
        else:
            # Otherwise send as a normal message
            await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text=echo_text
            )

        logger.info(f"Echo command used by admin {update.effective_user.id} in chat {update.effective_chat.id}")

    except Exception as e:
        logger.error(f"Error in echo_command: {str(e)}")
        await update.message.reply_text(f"خطا در اجرای دستور اکو: {str(e)}")

async def help_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle help pagination callbacks"""
    try:
        query = update.callback_query
        await query.answer()

        if query.data == "help_noop":
            # No operation for page indicator button
            return

        if query.data.startswith("help_page_"):
            # Handle page navigation
            await help_command(query, context)

        logger.info(f"Help callback handled: {query.data} by user {query.from_user.id}")
    except Exception as e:
        logger.error(f"Error in help_callback_handler: {str(e)}")
        await query.message.reply_text("خطایی در پردازش دکمه‌ها رخ داد. لطفاً دوباره تلاش کنید.")

async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show general group statistics with a nice design"""
    try:
        if update.effective_chat.type == "private":
            await update.message.reply_text("این دستور فقط در گروه‌ها قابل استفاده است.")
            return

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
        if chat_member.status not in ['administrator', 'creator'] and update.effective_user.id != ADMIN_ID:
            await update.message.reply_text("فقط ادمین‌های گروه می‌توانند آمار گروه را مشاهده کنند.")
            return

        # Check if command has parameters for direct access to specific stats
        command_text = update.message.text.strip()

        # Handle Persian commands with parameters
        if ' ' in command_text or '_' in command_text:
            # Extract the parameter
            param = None

            if command_text.startswith('آمار_'):
                param = command_text.split('_', 1)[1] if '_' in command_text else ''
            elif command_text.startswith('آمار '):
                param = command_text.split(' ', 1)[1] if ' ' in command_text else ''
            elif command_text.startswith('/stats '):
                param = command_text.split(' ', 1)[1] if ' ' in command_text else ''

            # Map parameters to callback data
            param_mapping = {
                'مدیران': 'stats_admins',
                'دسترسی': 'stats_admin_permissions',
                'دسترسی_مدیران': 'stats_admin_permissions',
                'دسترسی مدیران': 'stats_admin_permissions',
                'محتوا': 'stats_content',
                'چت': 'stats_chat',
                'ادد': 'stats_adds',
                'امروز': 'stats_today',
                'admins': 'stats_admins',
                'permissions': 'stats_admin_permissions',
                'admin_permissions': 'stats_admin_permissions',
                'content': 'stats_content',
                'chat': 'stats_chat',
                'adds': 'stats_adds',
                'today': 'stats_today'
            }

            # Check if parameter is valid
            if param and param in param_mapping:
                # Create a fake callback update to reuse existing handler
                fake_query = SimpleNamespace()
                fake_query.data = param_mapping[param]
                fake_query.message = update.message
                fake_query.from_user = update.effective_user
                fake_query.answer = lambda *args, **kwargs: None
                fake_query.edit_message_text = update.message.reply_text

                fake_update = SimpleNamespace(callback_query=fake_query)

                # Call the appropriate stats handler
                await stats_callback_handler(fake_update, context)
                return

        # Get group info
        chat_id = update.effective_chat.id
        chat_info = await context.bot.get_chat(chat_id)

        # Get member count
        member_count = await context.bot.get_chat_member_count(chat_id)

        # Get message count from database (if available)
        total_messages = db.count_group_messages(chat_id) if hasattr(db, 'count_group_messages') else db.count_user_messages(None, chat_id)

        # Get admin count
        admins = await context.bot.get_chat_administrators(chat_id)
        admin_count = len(admins)

        # Get current date and time in Persian format
        tehran_tz = pytz.timezone('Asia/Tehran')
        now_tehran = datetime.now(tehran_tz)
        j_date = jdatetime.datetime.fromgregorian(datetime=now_tehran)
        date_persian = j_date.strftime("%A %d %B %Y")
        time_persian = now_tehran.strftime("%H:%M:%S")

        # Get group creation date if available
        creation_date = "نامشخص"
        if hasattr(chat_info, 'date'):
            creation_date = chat_info.date.strftime("%Y-%m-%d")

        # Check if group is premium
        is_premium = premium_manager.is_group_premium(chat_id)
        premium_status = "✅ فعال" if is_premium else "❌ غیرفعال"

        # Create a beautiful response message
        stats_message = f"""
╭─────「 📊 آمار گروه 」─────╮
│                           │
│  📝 <b>نام گروه:</b>        │
│  {chat_info.title}
│                           │
│  👥 <b>تعداد اعضا:</b> {member_count:,} نفر │
│  👮‍♂️ <b>تعداد ادمین‌ها:</b> {admin_count} نفر │
│  💬 <b>تعداد پیام‌ها:</b> {total_messages:,} پیام │
│                           │
│  🆔 <b>شناسه گروه:</b>       │
│  <code>{chat_id}</code>    │
│                           │
│  📅 <b>تاریخ ایجاد:</b> {creation_date} │
│  💎 <b>وضعیت اشتراک:</b> {premium_status} │
│                           │
│  🕒 <b>زمان بررسی:</b> {time_persian} │
│  📆 <b>تاریخ بررسی:</b> {date_persian} │
╰───────────────────────────╯
"""

        # Create keyboard for more stats
        keyboard = [
            [
                InlineKeyboardButton("📊 آمار مدیران", callback_data="stats_admins"),
                InlineKeyboardButton("👮‍♂️ دسترسی مدیران", callback_data="stats_admin_permissions")
            ],
            [
                InlineKeyboardButton("📝 آمار محتوا", callback_data="stats_content"),
                InlineKeyboardButton("💬 آمار چت", callback_data="stats_chat")
            ],
            [
                InlineKeyboardButton("➕ آمار ادد", callback_data="stats_adds"),
                InlineKeyboardButton("📅 آمار امروز", callback_data="stats_today")
            ],
            [
                InlineKeyboardButton("🔙 بازگشت", callback_data="stats_main")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)

        # Send the message
        await update.message.reply_text(stats_message, parse_mode='HTML', reply_markup=reply_markup)
        logger.info(f"Stats command executed by user {update.effective_user.id} in chat {chat_id}")

    except Exception as e:
        logger.error(f"Error in stats_command: {str(e)}")
        await update.message.reply_text("❌ خطا در دریافت آمار گروه. لطفاً دوباره تلاش کنید.")

async def stats_callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle stats callback queries"""
    try:
        query = update.callback_query
        await query.answer()

        chat_id = query.message.chat.id
        user_id = query.from_user.id

        # Check if user is admin
        chat_member = await context.bot.get_chat_member(chat_id, user_id)
        if chat_member.status not in ['administrator', 'creator'] and user_id != ADMIN_ID:
            await query.answer("فقط ادمین‌های گروه می‌توانند آمار گروه را مشاهده کنند.", show_alert=True)
            return

        # Get current date and time in Persian format
        tehran_tz = pytz.timezone('Asia/Tehran')
        now_tehran = datetime.now(tehran_tz)
        j_date = jdatetime.datetime.fromgregorian(datetime=now_tehran)
        date_persian = j_date.strftime("%A %d %B %Y")
        time_persian = now_tehran.strftime("%H:%M:%S")

        # Handle different stats types
        if query.data == "stats_main":
            # Return to main stats
            # Get group info
            chat_info = await context.bot.get_chat(chat_id)

            # Get member count
            member_count = await context.bot.get_chat_member_count(chat_id)

            # Get message count from database (if available)
            total_messages = db.count_group_messages(chat_id) if hasattr(db, 'count_group_messages') else db.count_user_messages(None, chat_id)

            # Get admin count
            admins = await context.bot.get_chat_administrators(chat_id)
            admin_count = len(admins)

            # Get group creation date if available
            creation_date = "نامشخص"
            if hasattr(chat_info, 'date'):
                creation_date = chat_info.date.strftime("%Y-%m-%d")

            # Check if group is premium
            is_premium = premium_manager.is_group_premium(chat_id)
            premium_status = "✅ فعال" if is_premium else "❌ غیرفعال"

            # Create a beautiful response message
            stats_message = f"""
╭─────「 📊 آمار گروه 」─────╮
│                           │
│  📝 <b>نام گروه:</b>        │
│  {chat_info.title}
│                           │
│  👥 <b>تعداد اعضا:</b> {member_count:,} نفر │
│  👮‍♂️ <b>تعداد ادمین‌ها:</b> {admin_count} نفر │
│  💬 <b>تعداد پیام‌ها:</b> {total_messages:,} پیام │
│                           │
│  🆔 <b>شناسه گروه:</b>       │
│  <code>{chat_id}</code>    │
│                           │
│  📅 <b>تاریخ ایجاد:</b> {creation_date} │
│  💎 <b>وضعیت اشتراک:</b> {premium_status} │
│                           │
│  🕒 <b>زمان بررسی:</b> {time_persian} │
│  📆 <b>تاریخ بررسی:</b> {date_persian} │
╰───────────────────────────╯
"""

            # Create keyboard for more stats
            keyboard = [
                [
                    InlineKeyboardButton("📊 آمار مدیران", callback_data="stats_admins"),
                    InlineKeyboardButton("👮‍♂️ دسترسی مدیران", callback_data="stats_admin_permissions")
                ],
                [
                    InlineKeyboardButton("📝 آمار محتوا", callback_data="stats_content"),
                    InlineKeyboardButton("💬 آمار چت", callback_data="stats_chat")
                ],
                [
                    InlineKeyboardButton("➕ آمار ادد", callback_data="stats_adds"),
                    InlineKeyboardButton("📅 آمار امروز", callback_data="stats_today")
                ],
                [
                    InlineKeyboardButton("🔙 بازگشت", callback_data="stats_main")
                ]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)

            # Update the message
            await query.edit_message_text(stats_message, parse_mode='HTML', reply_markup=reply_markup)
            return

        elif query.data == "stats_admins":
            # Get admins info
            admins = await context.bot.get_chat_administrators(chat_id)

            # Create admin list
            admin_list = ""
            for i, admin in enumerate(admins, 1):
                user = admin.user
                status = "👑 سازنده" if admin.status == "creator" else "👮‍♂️ ادمین"
                username = f"@{user.username}" if user.username else "بدون نام کاربری"
                admin_list += f"{i}. {status}: <b>{user.first_name}</b> ({username})\n"

            # Create a beautiful response message
            stats_message = f"""
╭─────「 👮‍♂️ آمار مدیران 」─────╮
│                              │
│  👥 <b>تعداد کل مدیران:</b> {len(admins)} نفر │
│                              │
│  📋 <b>لیست مدیران:</b>         │
{admin_list}│                              │
│  🕒 <b>زمان بررسی:</b> {time_persian} │
│  📆 <b>تاریخ بررسی:</b> {date_persian} │
╰──────────────────────────────╯
"""

        elif query.data == "stats_admin_permissions":
            # Get admins with their permissions
            admins = await context.bot.get_chat_administrators(chat_id)

            # Create admin permissions list
            admin_perms = ""
            for i, admin in enumerate(admins, 1):
                user = admin.user
                status = "👑 سازنده" if admin.status == "creator" else "👮‍♂️ ادمین"
                username = f"@{user.username}" if user.username else "بدون نام کاربری"

                # Get permissions
                perms = []
                if admin.can_change_info:
                    perms.append("تغییر اطلاعات")
                if admin.can_delete_messages:
                    perms.append("حذف پیام")
                if admin.can_invite_users:
                    perms.append("دعوت کاربر")
                if admin.can_restrict_members:
                    perms.append("محدود کردن")
                if admin.can_pin_messages:
                    perms.append("پین پیام")
                if admin.can_promote_members:
                    perms.append("ارتقاء")

                perm_text = ", ".join(perms) if perms else "بدون دسترسی"
                admin_perms += f"{i}. <b>{user.first_name}</b> ({status}):\n   {perm_text}\n\n"

            # Create a beautiful response message
            stats_message = f"""
╭────「 🔐 دسترسی مدیران 」────╮
│                             │
│  👥 <b>تعداد کل مدیران:</b> {len(admins)} نفر │
│                             │
│  📋 <b>دسترسی‌ها:</b>           │
{admin_perms}│                             │
│  🕒 <b>زمان بررسی:</b> {time_persian} │
│  📆 <b>تاریخ بررسی:</b> {date_persian} │
╰─────────────────────────────╯
"""

        elif query.data == "stats_content":
            # Get content statistics (placeholder - should be implemented with actual database queries)
            total_messages = db.count_group_messages(chat_id) if hasattr(db, 'count_group_messages') else db.count_user_messages(None, chat_id)
            text_messages = int(total_messages * 0.7)  # Placeholder - should be from database
            photo_messages = int(total_messages * 0.15)  # Placeholder
            video_messages = int(total_messages * 0.1)  # Placeholder
            voice_messages = int(total_messages * 0.03)  # Placeholder
            document_messages = int(total_messages * 0.02)  # Placeholder

            # Create a beautiful response message
            stats_message = f"""
╭────「 📝 آمار محتوا 」────╮
│                         │
│  💬 <b>کل پیام‌ها:</b> {total_messages:,} │
│  📝 <b>متن:</b> {text_messages:,} │
│  🖼 <b>عکس:</b> {photo_messages:,} │
│  🎬 <b>ویدیو:</b> {video_messages:,} │
│  🎤 <b>صدا:</b> {voice_messages:,} │
│  📁 <b>فایل:</b> {document_messages:,} │
│                         │
│  🕒 <b>زمان بررسی:</b> {time_persian} │
│  📆 <b>تاریخ بررسی:</b> {date_persian} │
╰─────────────────────────╯
"""

        elif query.data == "stats_chat":
            # Get chat activity statistics (placeholder)
            total_messages = db.count_group_messages(chat_id) if hasattr(db, 'count_group_messages') else db.count_user_messages(None, chat_id)

            # Placeholder data - should be from database
            today_messages = int(total_messages * 0.05)
            week_messages = int(total_messages * 0.3)
            month_messages = int(total_messages * 0.65)

            avg_daily = int(total_messages / 30)  # Placeholder
            most_active_hour = "18:00 - 20:00"  # Placeholder

            # Create a beautiful response message
            stats_message = f"""
╭────「 💬 آمار چت 」────╮
│                       │
│  💬 <b>کل پیام‌ها:</b> {total_messages:,} │
│  📅 <b>امروز:</b> {today_messages:,} │
│  📆 <b>هفته اخیر:</b> {week_messages:,} │
│  🗓 <b>ماه اخیر:</b> {month_messages:,} │
│                       │
│  📊 <b>میانگین روزانه:</b> {avg_daily:,} │
│  🕒 <b>ساعت فعال:</b> {most_active_hour} │
│                       │
│  🕒 <b>زمان بررسی:</b> {time_persian} │
│  📆 <b>تاریخ بررسی:</b> {date_persian} │
╰───────────────────────╯
"""

        elif query.data == "stats_adds":
            # Get member add statistics (placeholder)
            member_count = await context.bot.get_chat_member_count(chat_id)

            # Placeholder data - should be from database
            today_adds = int(member_count * 0.02)
            week_adds = int(member_count * 0.1)
            month_adds = int(member_count * 0.25)

            # Placeholder data for left members
            today_left = int(today_adds * 0.3)
            week_left = int(week_adds * 0.3)
            month_left = int(month_adds * 0.3)

            # Create a beautiful response message
            stats_message = f"""
╭────「 ➕ آمار ادد 」────╮
│                       │
│  👥 <b>کل اعضا:</b> {member_count:,} │
│                       │
│  ➕ <b>اضافه شده امروز:</b> {today_adds} │
│  ➕ <b>اضافه شده هفته:</b> {week_adds} │
│  ➕ <b>اضافه شده ماه:</b> {month_adds} │
│                       │
│  ➖ <b>خارج شده امروز:</b> {today_left} │
│  ➖ <b>خارج شده هفته:</b> {week_left} │
│  ➖ <b>خارج شده ماه:</b> {month_left} │
│                       │
│  🕒 <b>زمان بررسی:</b> {time_persian} │
│  📆 <b>تاریخ بررسی:</b> {date_persian} │
╰───────────────────────╯
"""

        elif query.data == "stats_today":
            # Get today's statistics (placeholder)

            # Placeholder data - should be from database
            today_messages = 250
            today_members = 5
            today_left = 2
            today_warns = 3
            today_mutes = 2
            today_pins = 1

            # Create a beautiful response message
            stats_message = f"""
╭────「 📅 آمار امروز 」────╮
│                         │
│  📆 <b>تاریخ:</b> {date_persian} │
│                         │
│  💬 <b>پیام‌های امروز:</b> {today_messages:,} │
│  ➕ <b>اعضای جدید:</b> {today_members} │
│  ➖ <b>اعضای خارج شده:</b> {today_left} │
│  ⚠️ <b>اخطارها:</b> {today_warns} │
│  🔇 <b>سکوت‌ها:</b> {today_mutes} │
│  📌 <b>پین‌ها:</b> {today_pins} │
│                         │
│  🕒 <b>زمان بررسی:</b> {time_persian} │
╰─────────────────────────╯
"""

        else:
            await query.edit_message_text("دستور نامعتبر است.")
            return

        # Create keyboard for navigation
        keyboard = [
            [
                InlineKeyboardButton("📊 آمار مدیران", callback_data="stats_admins"),
                InlineKeyboardButton("👮‍♂️ دسترسی مدیران", callback_data="stats_admin_permissions")
            ],
            [
                InlineKeyboardButton("📝 آمار محتوا", callback_data="stats_content"),
                InlineKeyboardButton("💬 آمار چت", callback_data="stats_chat")
            ],
            [
                InlineKeyboardButton("➕ آمار ادد", callback_data="stats_adds"),
                InlineKeyboardButton("📅 آمار امروز", callback_data="stats_today")
            ],
            [
                InlineKeyboardButton("🔄 بازگشت به آمار اصلی", callback_data="stats_main")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)

        # Update the message
        await query.edit_message_text(stats_message, parse_mode='HTML', reply_markup=reply_markup)

    except Exception as e:
        logger.error(f"Error in stats_callback_handler: {str(e)}")
        await query.edit_message_text("❌ خطا در دریافت آمار. لطفاً دوباره تلاش کنید.")

def main():
    """Main function to run the bot"""
    try:
        # Load premium groups cache on startup
        load_premium_groups()

        # Create application
        application = Application.builder().token(BOT_TOKEN).build()

        # Set post init callback
        application.post_init = post_init

        # Register handlers from moderation.py
        from handlers.moderation import register_handlers
        register_handlers(application)

        # Add basic handlers (no premium required)
        application.add_handler(CommandHandler("start", start))
        application.add_handler(CommandHandler("help", help_command))
        application.add_handler(CommandHandler("subscription", subscription_status))
        application.add_handler(CommandHandler("buypremium", buy_premium))
        application.add_handler(CommandHandler("currency", currency_command))
        application.add_handler(CommandHandler("crypto", crypto_command))
        application.add_handler(CommandHandler("gold", gold_command))
        application.add_handler(CommandHandler("convert", convert_command))
        application.add_handler(CommandHandler("market", market_command))
        application.add_handler(CommandHandler("time", show_current_time))
        application.add_handler(CommandHandler("stats", stats_command))  # Add stats command
        application.add_handler(CommandHandler("royal", royal_ping_command))
        application.add_handler(CommandHandler("roles", royal_roles_command))
        application.add_handler(CommandHandler("setrole", royal_set_role_command))
        application.add_handler(CommandHandler("games", games_command))

        application.add_handler(CommandHandler("seven", seven_command))
        application.add_handler(CommandHandler("sevenjoin", seven_join_command))
        application.add_handler(CommandHandler("sevenstart", seven_start_command))
        application.add_handler(CommandHandler("sevenplay", seven_play_command))
        application.add_handler(CommandHandler("sevendraw", seven_draw_command))
        application.add_handler(CommandHandler("sevenstatus", seven_status_command))

        application.add_handler(CommandHandler("hokm", hokm_command))
        application.add_handler(CommandHandler("hokmjoin", hokm_join_command))
        application.add_handler(CommandHandler("hokmstart", hokm_start_command))
        application.add_handler(CommandHandler("hokmchoose", hokm_choose_command))
        application.add_handler(CommandHandler("hokmplay", hokm_play_command))
        application.add_handler(CommandHandler("hokmstatus", hokm_status_command))

        # Add callback handlers
        application.add_handler(CallbackQueryHandler(help_callback_handler, pattern='^help_'))
        application.add_handler(CallbackQueryHandler(stats_callback_handler, pattern='^stats_'))  # Add stats callback handler
        application.add_handler(CallbackQueryHandler(handle_subscription_callback, pattern='^sub_'))
        application.add_handler(CallbackQueryHandler(admin_callback, pattern='^admin_'))
        application.add_handler(CallbackQueryHandler(glass_callback_handler, pattern='^glass_'))
        application.add_handler(CallbackQueryHandler(report_callback_handler, pattern='^report_'))
        application.add_handler(CallbackQueryHandler(reports_callback_handler, pattern='^reports_'))
        application.add_handler(CallbackQueryHandler(admin_abuse_callback_handler, pattern='^abuse_'))
        application.add_handler(CallbackQueryHandler(user_info_callback_handler, pattern='^userinfo_'))

        # Add premium-required handlers
        application.add_handler(CommandHandler("warn", premium_warn_user))
        application.add_handler(CommandHandler("unwarn", premium_unwarn_user))
        application.add_handler(CommandHandler("admin", premium_admin_panel))
        application.add_handler(CommandHandler("locktime", premium_lock_time_messages))
        application.add_handler(CommandHandler("unlocktime", premium_unlock_time_messages))
        application.add_handler(CommandHandler("forcejoin", premium_set_force_join))
        application.add_handler(CommandHandler("unforcejoin", premium_unset_force_join))
        application.add_handler(CommandHandler("ban", premium_ban_user))
        application.add_handler(CommandHandler("unban", premium_unban_user))  # اضافه کردن دستور رفع بن
        application.add_handler(CommandHandler("kick", premium_kick_user))
        application.add_handler(CommandHandler("mute", premium_mute_user))
        application.add_handler(CommandHandler("unmute", premium_unmute_user))
        application.add_handler(CommandHandler("mutelist", list_muted_users))
        application.add_handler(CommandHandler("delete", delete_message))
        application.add_handler(CommandHandler("startvoice", start_voice_chat))
        application.add_handler(CommandHandler("stopvoice", stop_voice_chat))
        application.add_handler(CommandHandler("pin", pin_message))
        application.add_handler(CommandHandler("unpin", unpin_message))
        application.add_handler(CommandHandler("promote", premium_promote_user))
        application.add_handler(CommandHandler("demote", premium_demote_user))
        application.add_handler(CommandHandler("special", premium_special_user))
        application.add_handler(CommandHandler("sudo", sudo_user_handler))
        application.add_handler(CommandHandler("echo", echo_command))

        # Add glass links handlers
        application.add_handler(CommandHandler("glass", glass_command))

        # Add admin-only subscription management handlers
        application.add_handler(CommandHandler("addpremium", add_premium_group))
        application.add_handler(CommandHandler("listpremium", list_premium_groups))
        application.add_handler(CommandHandler("refreshcache", load_premium_groups))

        # Add broadcast handler (admin only)
        application.add_handler(CommandHandler("broadcast", admin_broadcast_handler))

        # Add report handler
        application.add_handler(CommandHandler("report", report_command))
        application.add_handler(CommandHandler("reportadmin", report_admin_abuse))

        # Add callback query handler for admin panel and subscription
        application.add_handler(CallbackQueryHandler(admin_callback, pattern='^(admin_panel|bot_stats|manage_subscriptions|stats|warned_users|banned_users|welcome_settings|premium_groups|add_premium|remove_premium|back_to_main|welcome_on|welcome_off|broadcast|refresh_cache|buyer_stats|buyer_warned_users|buyer_banned_users|buyer_welcome_settings|buyer_telegram_service_lock|telegram_service_lock|lock_photo|lock_video|lock_document|lock_animation|unlock_all|lock_voice|lock_sticker|lock_contact|lock_location|lock_poll|lock_game|lock_text|lock_forward|lock_url|lock_all|lock_new_members|lock_join_messages|lock_pin_messages|lock_video_chat_messages)$'))
        application.add_handler(CallbackQueryHandler(handle_subscription_callback, pattern='^(buy_premium|select_plan:.*|cancel_buy_premium|check_subscription|help|approve_sub_.*|reject_sub_.*|group_stats_.*|sub_history_.*)$'))
        application.add_handler(CallbackQueryHandler(report_callback_handler, pattern='^report_'))
        application.add_handler(CallbackQueryHandler(admin_abuse_callback_handler, pattern='^admin_abuse_'))

        # Add weather callback handler
        from handlers.weather import weather_callback_handler
        application.add_handler(CallbackQueryHandler(weather_callback_handler, pattern='^weather_'))

        # Add glass links callback handler
        application.add_handler(CallbackQueryHandler(glass_callback_handler, pattern='^glass_'))

        # Add message handler for Persian commands and premium checks
        application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, premium_check_message_advanced))

        # Add handler for new member messages
        application.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, new_member_message))

        # Add handler for service messages
        application.add_handler(MessageHandler(
            filters.StatusUpdate.NEW_CHAT_MEMBERS | filters.StatusUpdate.LEFT_CHAT_MEMBER |
            filters.StatusUpdate.PINNED_MESSAGE |
            filters.StatusUpdate.VIDEO_CHAT_STARTED | filters.StatusUpdate.VIDEO_CHAT_ENDED |
            filters.StatusUpdate.VIDEO_CHAT_PARTICIPANTS_INVITED,
            delete_service_messages
        ))

        # Setup admin abuse handlers
        setup_admin_abuse_handlers(application)

        # Persian commands are now handled by handle_persian_commands function
        # Remove duplicate regex handlers to avoid conflicts
        # application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND & filters.Regex(r'^تنظیم لقب'), set_nickname_handler))
        # application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND & filters.Regex(r'^لقب$'), show_nickname_handler))
        # application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND & filters.Regex(r'^حذف لقب$'), remove_nickname_handler))

        # Persian commands are now handled by handle_persian_commands function
        # Remove duplicate regex handlers to avoid conflicts
        # application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND & filters.Regex(r'^(اطلاعات|آمار کاربر)$'), user_info_handler))
        application.add_handler(CallbackQueryHandler(user_info_callback_handler, pattern='^user_(activity|warnings|info)_'))
        application.add_handler(CallbackQueryHandler(games_callback_handler, pattern='^games_'))

        # Persian commands are now handled by handle_persian_commands function
        # Remove duplicate regex handlers to avoid conflicts
        # application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND & filters.Regex(r'^آب و هوا'), weather_handler))

        # Run the bot
        logger.info("Starting bot...")
        application.run_polling(allowed_updates=Update.ALL_TYPES)

    except Exception as e:
        logger.error(f"Error starting bot: {str(e)}")
        raise

if __name__ == '__main__':
    main()