"""
Market data configuration settings
"""

# API Configuration
MARKET_CONFIG = {
    # Currency API settings
    'currency_api': {
        'base_url': 'https://api.exchangerate-api.com/v4/latest/USD',
        'timeout': 30,
        'retry_attempts': 3
    },
    
    # Cryptocurrency API settings
    'crypto_api': {
        'base_url': 'https://api.coingecko.com/api/v3/simple/price',
        'timeout': 30,
        'retry_attempts': 3
    },
    
    # Gold price API settings
    'gold_api': {
        'primary_url': 'https://api.metals.live/v1/spot/gold',
        'fallback_url': 'https://api.coingecko.com/api/v3/simple/price?ids=gold&vs_currencies=usd',
        'timeout': 30,
        'retry_attempts': 3
    },
    
    # Default USD to IRR rate (can be updated dynamically)
    'usd_to_irr_rate': 50000,
    
    # Market report schedule settings
    'schedule': {
        'daily_report_time': '09:00',  # Tehran time
        'periodic_interval_hours': 6,
        'startup_delay_minutes': 5
    },
    
    # Rate limiting settings
    'rate_limiting': {
        'requests_per_minute': 60,
        'delay_between_groups': 1  # seconds
    }
}

# Feature flags for market data
MARKET_FEATURES = {
    'currency_rates': True,
    'crypto_prices': True,
    'gold_prices': True,
    'scheduled_reports': True,
    'persian_formatting': True,
    'auto_updates': True
}

# Supported currencies (can be extended)
SUPPORTED_CURRENCIES = [
    'USD', 'EUR', 'GBP', 'JPY', 'CAD', 
    'AUD', 'CHF', 'CNY', 'AED', 'TRY'
]

# Supported cryptocurrencies (can be extended)
SUPPORTED_CRYPTOCURRENCIES = [
    'bitcoin', 'ethereum', 'binancecoin', 'cardano',
    'solana', 'dogecoin', 'polkadot', 'chainlink'
]
